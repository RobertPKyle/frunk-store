#pragma once
#ifdef __EMSCRIPTEN__
#include <GLES3/gl3.h>
#define GLAPIENTRY
#else
#include <glad/glad.h>
#endif

GLuint generateTextures(long long seed);
