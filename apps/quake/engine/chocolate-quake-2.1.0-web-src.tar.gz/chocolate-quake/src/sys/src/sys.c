/*
 * Copyright (C) 1996-1997 Id Software, Inc.
 * Copyright (C) Henrique Barateli, <henriquejb194@gmail.com>, et al.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


#include "sys.h"
#include "client.h"
#include "cmd.h"
#include "config.h"
#include "end_screen.h"
#include "input.h"
#include "keys.h"
#include "menu.h"
#include <SDL_events.h>
#include <SDL_hints.h>
#include <SDL_stdinc.h>
#include <SDL_timer.h>
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <string.h>

#ifdef HAVE_SIGNAL_H
#include <signal.h>
#endif
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif


qboolean isDedicated;

/*
===============================================================================

FILE IO

===============================================================================
*/

#define MAX_HANDLES 10
FILE* sys_handles[MAX_HANDLES];

i32 findhandle(void) {
    i32 i;

    for (i = 1; i < MAX_HANDLES; i++)
        if (!sys_handles[i])
            return i;
    Sys_Error("out of handles");
    return -1;
}

/*
================
filelength
================
*/
i32 filelength(FILE* f) {
    i32 pos;
    i32 end;

    pos = ftell(f);
    fseek(f, 0, SEEK_END);
    end = ftell(f);
    fseek(f, pos, SEEK_SET);

    return end;
}

i32 Sys_FileOpenRead(char* path, i32* hndl) {
    FILE* f;
    i32 i;

    i = findhandle();

    f = fopen(path, "rb");
    if (!f) {
        *hndl = -1;
        return -1;
    }
    sys_handles[i] = f;
    *hndl = i;

    return filelength(f);
}

i32 Sys_FileOpenWrite(char* path) {
    FILE* f;
    i32 i;

    i = findhandle();

    f = fopen(path, "wb");
    if (!f)
        Sys_Error("Error opening %s: %s", path, strerror(errno));
    sys_handles[i] = f;

    return i;
}

void Sys_FileClose(i32 handle) {
    fclose(sys_handles[handle]);
    sys_handles[handle] = NULL;
}

void Sys_FileSeek(i32 handle, i32 position) {
    fseek(sys_handles[handle], position, SEEK_SET);
}

size_t Sys_FileRead(i32 handle, void* dest, i32 count) {
    return fread(dest, 1, count, sys_handles[handle]);
}

size_t Sys_FileWrite(i32 handle, void* data, i32 count) {
    return fwrite(data, 1, count, sys_handles[handle]);
}

i32 Sys_FileTime(char* path) {
    FILE* f;

    f = fopen(path, "rb");
    if (f) {
        fclose(f);
        return 1;
    }

    return -1;
}

void Sys_mkdir(char* path) {
}


/*
===============================================================================

SYSTEM IO

===============================================================================
*/

void Sys_Error(char* error, ...) {
    va_list argptr;
    printf("Sys_Error: ");
    va_start(argptr, error);
    vprintf(error, argptr);
    va_end(argptr);
    printf("\n");

#ifdef __EMSCRIPTEN__
    // [frunk] The page says what happened and goes back to its list.
    {
        char message[1024];
        va_start(argptr, error);
        vsnprintf(message, sizeof(message), error, argptr);
        va_end(argptr);
        EM_ASM({ Module.onError && Module.onError(UTF8ToString($0)); }, message);
        emscripten_force_exit(1);
    }
#endif
    Host_Shutdown();

    exit(1);
}

void Sys_Printf(char* fmt, ...) {
    va_list argptr;

    va_start(argptr, fmt);
    vprintf(fmt, argptr);
    va_end(argptr);
}

void Sys_Quit(void) {
    Host_Shutdown();
#ifdef __EMSCRIPTEN__
    // [frunk] Quit from the menu: settings are written, and the page goes
    // back to its list.
    EM_ASM({ Module.onQuit && Module.onQuit(); });
    emscripten_force_exit(0);
#endif
    ES_DisplayScreen();
    exit(0);
}

double Sys_FloatTime() {
    static double frequency = 0.0;
    static u64 start_time = 0;

    if (start_time == 0) {
        frequency = (double) SDL_GetPerformanceFrequency();
        start_time = SDL_GetPerformanceCounter();
        return (double) start_time / frequency;
    }
    u64 now = SDL_GetPerformanceCounter();
    double time_diff = (double) (now - start_time);
    return time_diff / frequency;
}

char* Sys_ConsoleInput(void) {
    return NULL;
}


/*
================================================================================

SYSTEM EVENT POLLING

================================================================================
*/

static void Sys_QuitEvent(void) {
    if (M_IsInQuitScreen()) {
        // Confirm quit.
        Key_Event('Y', true);
        return;
    }
    // Bring up the quit confirmation screen.
    Cmd_ExecuteString("quit", src_command);
}

void Sys_SendKeyEvents() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_KEYDOWN:
            case SDL_KEYUP:
                IN_KeyboardEvent(&event);
                break;
            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
            case SDL_MOUSEWHEEL:
                IN_MouseEvent(&event);
                break;
            case SDL_CONTROLLERDEVICEADDED:
            case SDL_CONTROLLERDEVICEREMOVED:
            case SDL_CONTROLLERBUTTONDOWN:
            case SDL_CONTROLLERBUTTONUP:
            case SDL_CONTROLLERAXISMOTION:
                IN_GamepadEvent(&event);
                break;
            case SDL_QUIT:
                Sys_QuitEvent();
                break;
            default:
                break;
        }
    }
}

//==============================================================================


void Sys_HighFPPrecision(void) {
}

void Sys_LowFPPrecision(void) {
}

//=============================================================================


/*
================================================================================

SIGNAL HANDLING

================================================================================
*/

#ifdef HAVE_SIGNAL_H
static void Sys_SigHandler(int sig) {
    CL_Disconnect();
    Host_ShutdownServer(false);
    Sys_Quit();
}

#ifdef HAVE_SIGACTION
static void Sys_SigHook(int sig) {
    struct sigaction action;
    sigaction(sig, NULL, &action);
    action.sa_handler = Sys_SigHandler;
    sigaction(sig, &action, NULL);
}
#else
static void Sys_SigHook(int sig) {
    signal(sig, Sys_SigHandler);
}
#endif

static void Sys_SigInit(void) {
    // Disable SDL default signal handlers
    SDL_SetHint(SDL_HINT_NO_SIGNAL_HANDLERS, "1");
    Sys_SigHook(SIGINT);
    Sys_SigHook(SIGTERM);
}
#endif /* HAVE_SIGNAL_H */

//=============================================================================


#ifdef __EMSCRIPTEN__
// [frunk] Plenty for the free and the original games, on a car's computer.
#define DEFAULT_MEMORY (64 * 1024 * 1024)
#else
#define DEFAULT_MEMORY (256 * 1024 * 1024)
#endif

static char* Sys_GetDefaultBaseDir(void) {
#ifdef _WIN32
    return ".";
#else
    static char base_dir[MAX_OSPATH] = {0};
    if (base_dir[0]) {
        return base_dir;
    }
    char* path = SDL_GetPrefPath("", PACKAGE_TARNAME);
    Q_strncpy(base_dir, path, MAX_OSPATH);
    SDL_free(path);
    return base_dir;
#endif
}

static quakeparms_t* Sys_InitParms(i32 argc, char** argv) {
    static quakeparms_t parms;

    parms.memsize = DEFAULT_MEMORY;
    parms.membase = Q_malloc(parms.memsize);
    parms.basedir = Sys_GetDefaultBaseDir();

    COM_InitArgv(argc, argv);
    parms.argc = com_argc;
    parms.argv = com_argv;

    return &parms;
}

quakeparms_t* Sys_Init(i32 argc, char* argv[]) {
#ifdef HAVE_SIGNAL_H
    Sys_SigInit();
#endif
    return Sys_InitParms(argc, argv);
}
