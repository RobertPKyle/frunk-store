/*
 * Copyright (C) 2026 frunk.store
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 */
// bgmusic_web.c -- background music in a browser (frunk.store Quake), in
// place of bgmusic.c and the codecs. The page plays music/trackNN.ogg
// itself, so the browser decodes it away from the game; Quake only says
// which track, and when to stop, pause or change the volume.

#include <emscripten.h>
#include "bgmusic.h"
#include "client.h"
#include "cmd.h"
#include "console.h"
#include "sound.h"

static qboolean enabled = true;
static qboolean playing = false;
static qboolean paused = false;
static qboolean looping = false;
static byte play_track;
static float volume = -1;
static byte remap[100];

void BGMusic_Play(byte track, qboolean loop) {
    track = remap[track];
    if (!enabled || track < 1) {
        return;
    }
    if (playing && play_track == track) {
        return;
    }
    play_track = track;
    looping = loop;
    playing = true;
    paused = false;
    EM_ASM({ Module.onMusic && Module.onMusic($0, $1); }, track, loop);
}

void BGMusic_Stop(void) {
    if (!playing) {
        return;
    }
    playing = false;
    paused = false;
    EM_ASM({ Module.onMusic && Module.onMusic(0, 0); });
}

void BGMusic_Pause(void) {
    if (!playing || paused) {
        return;
    }
    paused = true;
    EM_ASM({ Module.onMusicPause && Module.onMusicPause(1); });
}

void BGMusic_Resume(void) {
    if (!playing || !paused) {
        return;
    }
    paused = false;
    EM_ASM({ Module.onMusicPause && Module.onMusicPause(0); });
}

static void CD_f(void) {
    if (Cmd_Argc() < 2) {
        return;
    }
    const char* command = Cmd_Argv(1);
    if (Q_strcasecmp(command, "on") == 0) {
        enabled = true;
    } else if (Q_strcasecmp(command, "off") == 0) {
        BGMusic_Stop();
        enabled = false;
    } else if (Q_strcasecmp(command, "reset") == 0) {
        enabled = true;
        BGMusic_Stop();
        for (i32 n = 0; n < 100; n++) {
            remap[n] = (byte) n;
        }
    } else if (Q_strcasecmp(command, "remap") == 0) {
        for (i32 n = 1; n <= Cmd_Argc() - 2 && n < 100; n++) {
            remap[n] = (byte) Q_atoi(Cmd_Argv(n + 1));
        }
    } else if (Q_strcasecmp(command, "play") == 0) {
        BGMusic_Play((byte) Q_atoi(Cmd_Argv(2)), false);
    } else if (Q_strcasecmp(command, "loop") == 0) {
        BGMusic_Play((byte) Q_atoi(Cmd_Argv(2)), true);
    } else if (Q_strcasecmp(command, "stop") == 0) {
        BGMusic_Stop();
    } else if (Q_strcasecmp(command, "pause") == 0) {
        BGMusic_Pause();
    } else if (Q_strcasecmp(command, "resume") == 0) {
        BGMusic_Resume();
    } else if (Q_strcasecmp(command, "info") == 0) {
        if (playing) {
            Con_Printf("%s track %u\n", looping ? "Looping" : "Playing",
                       play_track);
        }
        Con_Printf("Volume is %f\n", volume);
    }
}

i32 BGMusic_Init(void) {
    if (COM_CheckParm("-nocdaudio")) {
        enabled = false;
        return -1;
    }
    for (i32 n = 0; n < 100; n++) {
        remap[n] = (byte) n;
    }
    Cmd_AddCommand("cd", CD_f);
    return 0;
}

void BGMusic_Shutdown(void) {
    BGMusic_Stop();
}

void BGMusic_Update(void) {
    if (bgmvolume.value != volume) {
        if (bgmvolume.value < 0 || bgmvolume.value > 1) {
            Cvar_SetValue("bgmvolume", bgmvolume.value < 0 ? 0 : 1);
        }
        volume = bgmvolume.value;
        EM_ASM({ Module.onMusicVolume && Module.onMusicVolume($0); }, volume);
    }
}

// snd_dma.c starts and stops the codecs, which aren't needed here.
void S_CodecInit(void) {
}

void S_CodecShutdown(void) {
}
