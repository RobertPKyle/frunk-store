/*
 * Copyright (C) 1996-1997 Id Software, Inc.
 * Copyright (C) Henrique Barateli, <henriquejb194@gmail.com>, et al.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include "snd_wave.h"
#include "console.h"
#include "sound.h"
#include <stdio.h>
#include <string.h>

/*
=================
FGetLittleLong
=================
*/
static i32 FGetLittleLong(FILE* f) {
    i32 v;
    fread(&v, 1, sizeof(v), f);
    return LittleLong(v);
}

/*
=================
FGetLittleShort
=================
*/
static i16 FGetLittleShort(FILE* f) {
    i16 v;
    fread(&v, 1, sizeof(v), f);
    return LittleShort(v);
}

/*
=================
WAV_ReadChunkInfo
=================
*/
static i32 WAV_ReadChunkInfo(FILE* f, char* name) {
    name[4] = 0;
    const i32 r = (i32) fread(name, 1, 4, f);
    if (r != 4) {
        return -1;
    }
    const i32 len = FGetLittleLong(f);
    if (len < 0) {
        Con_Printf("WAV: Negative chunk length\n");
        return -1;
    }
    return len;
}

/*
=================
WAV_FindRIFFChunk

Returns the length of the data in the chunk, or -1 if not found
=================
*/
static i32 WAV_FindRIFFChunk(FILE* f, const char* chunk) {
    char name[5];
    i32 len;
    while ((len = WAV_ReadChunkInfo(f, name)) >= 0) {
        // If this is the right chunk, return
        if (!Q_strncmp(name, chunk, 4)) {
            return len;
        }
        // Pad by 2.
        len = ((len + 1) & ~1);
        // Not the right chunk - skip it
        fseek(f, len, SEEK_CUR);
    }
    return -1;
}

/*
=================
WAV_ReadRIFFHeader
=================
*/
static qboolean WAV_ReadRIFFHeader(
    const char* name,
    FILE* file,
    snd_info_t* info
) {
    char dump[16];
    i32 fmtlen = 0;

    if (fread(dump, 1, 12, file) < 12
        || Q_strncmp(dump, "RIFF", 4) != 0
        || Q_strncmp(&dump[8], "WAVE", 4) != 0)
    {
        Con_Printf("%s is missing RIFF/WAVE chunks\n", name);
        return false;
    }

    // Scan for the format chunk
    if ((fmtlen = WAV_FindRIFFChunk(file, "fmt ")) < 0) {
        Con_Printf("%s is missing fmt chunk\n", name);
        return false;
    }

    // Save the parameters
    const i32 wav_format = FGetLittleShort(file);
    if (wav_format != WAV_FORMAT_PCM) {
        Con_Printf("%s is not Microsoft PCM format\n", name);
        return false;
    }

    info->channels = FGetLittleShort(file);
    info->rate = FGetLittleLong(file);
    FGetLittleLong(file);
    FGetLittleShort(file);
    info->bits = FGetLittleShort(file);

    if (info->bits != 8 && info->bits != 16) {
        Con_Printf("%s is not 8 or 16 bit\n", name);
        return false;
    }

    info->width = info->bits / 8;
    info->dataofs = 0;

    // Skip the rest of the format chunk if required.
    if (fmtlen > 16) {
        fmtlen -= 16;
        fseek(file, fmtlen, SEEK_CUR);
    }

    // Scan for the data chunk
    if ((info->size = WAV_FindRIFFChunk(file, "data")) < 0) {
        Con_Printf("%s is missing data chunk\n", name);
        return false;
    }

    if (info->channels != 1 && info->channels != 2) {
        Con_Printf("Unsupported number of channels %d in %s\n", info->channels,
                   name);
        return false;
    }
    info->samples = (info->size / info->width) / info->channels;
    if (info->samples == 0) {
        Con_Printf("%s has zero samples\n", name);
        return false;
    }

    return true;
}

/*
=================
S_WAV_CodecOpenStream
=================
*/
static qboolean S_WAV_CodecOpenStream(snd_stream_t* stream) {
    const long start = stream->fh.start;

    // Read the RIFF header
    // The file reads are sequential, therefore no need for
    // the FS_*() functions: We will manipulate the file by
    // ourselves from now on.
    if (!WAV_ReadRIFFHeader(stream->name, stream->fh.file, &stream->info)) {
        return false;
    }

    // Reset to data position.
    stream->fh.start = ftell(stream->fh.file);
    if (stream->fh.start - start + stream->info.size > stream->fh.length) {
        Con_Printf("%s data size mismatch\n", stream->name);
        return false;
    }

    return true;
}

/*
=================
S_WAV_CodecReadStream
=================
*/
i32 S_WAV_CodecReadStream(snd_stream_t* stream, i32 bytes, void* buffer) {
    const i32 remaining = stream->info.size - stream->fh.pos;
    if (remaining <= 0) {
        return 0;
    }
    if (bytes > remaining) {
        bytes = remaining;
    }
    stream->fh.pos += bytes;
    fread(buffer, 1, bytes, stream->fh.file);
    if (stream->info.width == 2) {
        const i32 samples = bytes / 2;
        i16* sbuf = buffer;
        for (i32 i = 0; i < samples; i++) {
            sbuf[i] = LittleShort(sbuf[i]);
        }
    }
    return bytes;
}

static void S_WAV_CodecCloseStream(snd_stream_t* stream) {
    S_CodecUtilClose(&stream);
}

static i32 S_WAV_CodecRewindStream(snd_stream_t* stream) {
    Q_rewind(&stream->fh);
    return 0;
}

static qboolean S_WAV_CodecInitialize(void) {
    return true;
}

static void S_WAV_CodecShutdown(void) {
    // Nothing to shut down.
}

snd_codec_t wav_codec = {
    .type = CODECTYPE_WAVE,
    .initialized = true, // always available.
    .ext = "wav",
    .initialize = S_WAV_CodecInitialize,
    .shutdown = S_WAV_CodecShutdown,
    .codec_open = S_WAV_CodecOpenStream,
    .codec_read = S_WAV_CodecReadStream,
    .codec_rewind = S_WAV_CodecRewindStream,
    .codec_jump = NULL,
    .codec_close = S_WAV_CodecCloseStream,
    .next = NULL,
};
