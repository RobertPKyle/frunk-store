/*
 * Copyright (C) 2026 frunk.store
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 */
// in_web.c -- calls for the browser page (frunk.store Quake). The page reads
// controllers and its touch controls itself and hands Quake one state per
// frame, so Quake never opens SDL's game controllers (the car shows each
// controller twice).

#ifdef __EMSCRIPTEN__

#include <emscripten.h>
#include "in_web.h"
#include "client.h"
#include "cmd.h"
#include "host.h"
#include "console.h"
#include "keys.h"
#include "server.h"
#include "sys.h"

// Key numbers for the page's buttons, above any real key, so KeyDown and
// KeyUp can tell them apart from keys bound to the same action.
#define WEB_KEY 1000

enum {
    WEB_ATTACK = 1,
    WEB_JUMP = 2,
    WEB_NEXT_WEAPON = 4,
    WEB_PREV_WEAPON = 8,
    WEB_SPEED = 16,
};

static i32 held;
static float move_forward, move_side, turn, look;
static float look_yaw, look_pitch;
static i32 frames;

static void IN_WebButton(const char* action, i32 bit, i32 now) {
    char cmd[64];
    if ((now & bit) == (held & bit)) {
        return;
    }
    snprintf(cmd, sizeof(cmd), "%c%s %d\n", (now & bit) ? '+' : '-', action,
             WEB_KEY + bit);
    Cmd_ExecuteString(cmd, src_command);
}

// buttons: WEB_* bits; forward, side: -65536..65536, forward and right
// positive; yaw, pitch: stick turning, -65536..65536, right and down
// positive.
EMSCRIPTEN_KEEPALIVE void web_pad(i32 buttons, i32 forward, i32 side, i32 yaw,
                                  i32 pitch) {
    if (key_dest != key_game) {
        buttons = 0;
        forward = side = yaw = pitch = 0;
    }
    IN_WebButton("attack", WEB_ATTACK, buttons);
    IN_WebButton("jump", WEB_JUMP, buttons);
    IN_WebButton("speed", WEB_SPEED, buttons);
    if ((buttons & WEB_NEXT_WEAPON) && !(held & WEB_NEXT_WEAPON)) {
        Cbuf_AddText("impulse 10\n");
    }
    if ((buttons & WEB_PREV_WEAPON) && !(held & WEB_PREV_WEAPON)) {
        Cbuf_AddText("impulse 12\n");
    }
    held = buttons;
    move_forward = forward / 65536.0f;
    move_side = side / 65536.0f;
    turn = yaw / 65536.0f;
    look = pitch / 65536.0f;
}

// Turning from a finger dragged across the screen, in degrees, added to
// the next frame's view.
EMSCRIPTEN_KEEPALIVE void web_look(i32 yaw_millideg, i32 pitch_millideg) {
    look_yaw += yaw_millideg / 1000.0f;
    look_pitch += pitch_millideg / 1000.0f;
}

// A key press or release, for menus and the console (Quake's K_* numbers).
EMSCRIPTEN_KEEPALIVE void web_key(i32 key, i32 down) {
    Key_Event(key, down != 0);
}

// A console command from the page (a setting it changed), run on the next
// frame.
EMSCRIPTEN_KEEPALIVE void web_cmd(const char* text) {
    Cbuf_AddText((char*) text);
    Cbuf_AddText("\n");
}

void IN_WebMove(usercmd_t* cmd) {
    if (cl.paused || key_dest != key_game) {
        look_yaw = look_pitch = 0;
        return;
    }
    float speed = cl_forwardspeed.value;
    float side = cl_sidespeed.value;
    if (in_speed.state & 1) {
        speed *= cl_movespeedkey.value;
        side *= cl_movespeedkey.value;
    }
    cmd->forwardmove += speed * move_forward;
    cmd->sidemove += side * move_side;

    const float time = (float) host_frametime;
    cl.viewangles[YAW] -= turn * 200.0f * time + look_yaw;
    cl.viewangles[PITCH] += look * 130.0f * time + look_pitch;
    if (cl.viewangles[PITCH] > 80) {
        cl.viewangles[PITCH] = 80;
    }
    if (cl.viewangles[PITCH] < -70) {
        cl.viewangles[PITCH] = -70;
    }
    if (turn != 0 || look != 0 || look_yaw != 0 || look_pitch != 0) {
        V_StopPitchDrift();
    }
    look_yaw = look_pitch = 0;
}

// Saves the game in progress as "auto" right away, for picking up where
// the player left off. Returns 1 when it saved, 0 when there's nothing to
// save (no game, a demo, the intermission, or the player is dead).
EMSCRIPTEN_KEEPALIVE i32 web_autosave(void) {
    if (!sv.active || cls.demoplayback || cl.intermission
        || svs.maxclients != 1 || cl.stats[STAT_HEALTH] <= 0) {
        return 0;
    }
    Cmd_ExecuteString("save auto", src_command);
    Con_ClearNotify(); // the page saves quietly
    return 1;
}

void Host_WriteConfiguration(void);

// Writes config.cfg with the player's settings.
EMSCRIPTEN_KEEPALIVE void web_save_config(void) {
    Host_WriteConfiguration();
}

// Where input goes: 0 the game, 1 the console, 2 a chat message, 3 a
// menu; +4 while a level is being played (not a demo), +8 in the
// intermission or finale, +16 when the player is dead, +32 when paused.
EMSCRIPTEN_KEEPALIVE i32 web_state(void) {
    i32 state = key_dest;
    if (sv.active && !cls.demoplayback && cls.state == ca_connected) {
        state |= 4;
    }
    if (cl.intermission) {
        state |= 8;
    }
    if (cls.state == ca_connected && cl.stats[STAT_HEALTH] <= 0) {
        state |= 16;
    }
    if (cl.paused) {
        state |= 32;
    }
    return state;
}

void IN_WebFrame(void) {
    ++frames;
}

// Frames drawn so far, for the page's frame rate counter.
EMSCRIPTEN_KEEPALIVE i32 web_frames(void) {
    return frames;
}

#endif
