/*
 * Copyright (C) 2026 frunk.store
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 */
// in_web.h -- calls for the browser page (frunk.store Quake)

#ifndef CHOCOLATE_QUAKE_IN_WEB_H
#define CHOCOLATE_QUAKE_IN_WEB_H

#include "client.h"

void IN_WebMove(usercmd_t* cmd);
void IN_WebFrame(void);

#endif
