#!/bin/sh
# [frunk] Builds Chocolate Quake for the browser with Emscripten (4.0.10),
# from the top of the source tree: web/build.sh [extra link flags]
# Output: build-web/chocolate-quake.js and .wasm, for frunk.store's Quake
# page (apps/quake in github.com/RobertPKyle/frunk-store).
#
# Instead of CMake: the codec-based music player (bgmusic.c and the
# snd_* codecs) is left out for bgmusic_web.c, where the page plays the
# music files itself. -fwrapv and -fno-strict-aliasing because the 1990s
# renderer relies on both; -mno-nontrapping-fptoint so out-of-range float
# to int conversions give what an x86 gives.
set -e
cat > config.h <<'H'
#define PACKAGE_NAME "Chocolate Quake"
#define PACKAGE_TARNAME "chocolate-quake"
#define PACKAGE_VERSION "2.1.0"
#define PACKAGE_STRING "Chocolate Quake 2.1.0"
H
SRCS=$(find src -name '*.c' | grep -v -E 'sound/src/(bgmusic|snd_codec|snd_flac|snd_mp3|snd_mp3tag|snd_vorbis|snd_wave)\.c$' | sort)
INC="-I. -Isrc $(for d in src/*/include; do printf -- '-I%s ' "$d"; done)"
CFLAGS="-O3 -std=gnu99 -fwrapv -fno-strict-aliasing -mno-nontrapping-fptoint -DHAVE_STRCPY -DHAVE_STRNCPY -DHAVE_STRCAT -sUSE_SDL=2 -sUSE_SDL_NET=2 -Wno-everything"
mkdir -p build-web/obj
OBJS=""
for f in $SRCS; do
  OBJS="$OBJS build-web/obj/$(echo "$f" | tr / _ | sed 's/\.c$/.o/')"
done
export CFLAGS INC
echo "$SRCS" | xargs -P 8 -I{} sh -c 'f={}; emcc $CFLAGS $INC -c "$f" -o "build-web/obj/$(echo "$f" | tr / _ | sed "s/\.c$/.o/")"'
emcc -O3 $OBJS -o build-web/chocolate-quake.js -sUSE_SDL=2 -sUSE_SDL_NET=2 \
  -sSTACK_SIZE=4194304 -sALLOW_MEMORY_GROWTH -sINITIAL_MEMORY=134217728 \
  -sMODULARIZE -sEXPORT_ES6 -sEXPORT_NAME=createQuake -sENVIRONMENT=web \
  -sINVOKE_RUN=0 -sEXIT_RUNTIME=0 \
  -sEXPORTED_RUNTIME_METHODS=FS,callMain,UTF8ToString,stringToNewUTF8,ENV \
  -sEXPORTED_FUNCTIONS=_main,_web_pad,_web_look,_web_key,_web_state,_web_frames,_web_autosave,_web_save_config,_web_cmd,_malloc,_free \
  "$@"
rm -f config.h
