The source of ASCII Quests' games (frunk.store/ascii): Scott Miller's Kroz
games as Apogee Software released them in 2009 under the GNU General Public
License, version 2 or later (GNU.TXT, readme.txt). They are unchanged; frunk.store's
translator (tools/kroz/pascal.mjs, run by tools/build-kroz.mjs) turns each into
JavaScript for the runtime in frunk-apps.vercel.app/ascii/runtime.js.
