//
// Copyright(C) 2026 frunk.store
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// DESCRIPTION:
//    Calls for the browser page (frunk.store Doom). The page reads the
//    controller and touch controls itself and hands Doom one gamepad
//    state per frame, so Doom never opens SDL's joystick.
//

#include <emscripten.h>

#include "d_event.h"
#include "d_think.h"
#include "doomstat.h"
#include "d_main.h"
#include "m_config.h"
#include "i_web.h"

// buttons: bitfield of virtual buttons (joyb_* settings);
// turn, move, strafe: -65536..65536 (FRACUNIT), right/back/right positive;
// dir: d-pad and stick directions for menus (see i_joystick.h).
EMSCRIPTEN_KEEPALIVE void web_pad(int buttons, int turn, int move, int strafe,
                                  int dir)
{
    event_t ev;

    ev.type = ev_joystick;
    ev.data1 = buttons;
    ev.data2 = turn;
    ev.data3 = move;
    ev.data4 = strafe;
    ev.data5 = 0;
    ev.data6 = dir;
    D_PostEvent(&ev);
}

void G_WebSaveNow(int slot, const char *description);

// Saves the game in progress to slot 77 (the last one on the last page of
// the save menu), for picking up where the player left off. Returns 1 when
// it saved, 0 when there's nothing to save.
EMSCRIPTEN_KEEPALIVE int web_autosave(void)
{
    if (gamestate != GS_LEVEL || !usergame || demoplayback || netgame
     || gameaction != ga_nothing
     || players[consoleplayer].playerstate == PST_DEAD)
        return 0;

    G_WebSaveNow(77, "AUTOSAVE");
    return 1;
}

void D_RunFrame(void);

static int frames;

// The browser's main loop: one frame on each screen refresh.
void W_RunFrame(void)
{
    D_RunFrame();
    ++frames;
}

// Frames drawn so far, for the page's frame rate counter.
EMSCRIPTEN_KEEPALIVE int web_frames(void)
{
    return frames;
}

EMSCRIPTEN_KEEPALIVE void web_save_config(void)
{
    M_SaveDefaults();
}

// 0 title/demos, 1 playing, 2 intermission or finale; +4 when the menu
// is open, +8 when paused.
EMSCRIPTEN_KEEPALIVE int web_state(void)
{
    int state;

    if (gamestate == GS_LEVEL && usergame && !demoplayback)
        state = 1;
    else if ((gamestate == GS_INTERMISSION || gamestate == GS_FINALE)
             && !demoplayback)
        state = 2;
    else
        state = 0;

    return state | (menuactive ? 4 : 0) | (paused ? 8 : 0);
}

// WebAssembly traps when a function is called through a pointer of another
// type. Doom calls every state's action as action(mobj, player, psp), but
// these monster actions take only the mobj, so they get called with one.

void A_BFGSpray();
void A_BabyMetal();
void A_BetaSkullAttack();
void A_BossDeath();
void A_BrainAwake();
void A_BrainDie();
void A_BrainExplode();
void A_BrainPain();
void A_BrainScream();
void A_BrainSpit();
void A_BruisAttack();
void A_BspiAttack();
void A_CPosAttack();
void A_CPosRefire();
void A_Chase();
void A_CyberAttack();
void A_Detonate();
void A_Die();
void A_Explode();
void A_Face();
void A_FaceTarget();
void A_Fall();
void A_FatAttack1();
void A_FatAttack2();
void A_FatAttack3();
void A_FatRaise();
void A_Fire();
void A_FireCrackle();
void A_HeadAttack();
void A_Hoof();
void A_KeenDie();
void A_LineEffect();
void A_Look();
void A_Metal();
void A_Mushroom();
void A_Pain();
void A_PainAttack();
void A_PainDie();
void A_PlaySound();
void A_PlayerScream();
void A_PosAttack();
void A_SPosAttack();
void A_SargAttack();
void A_Scratch();
void A_Scream();
void A_SkelFist();
void A_SkelMissile();
void A_SkelWhoosh();
void A_SkullAttack();
void A_Spawn();
void A_SpawnFly();
void A_SpawnSound();
void A_SpidRefire();
void A_StartFire();
void A_Stop();
void A_Tracer();
void A_TroopAttack();
void A_Turn();
void A_VileAttack();
void A_VileChase();
void A_VileStart();
void A_VileTarget();
void A_XScream();

static const actionf_v one_arg_actions[] =
{
    A_BFGSpray, A_BabyMetal, A_BetaSkullAttack, A_BossDeath,
    A_BrainAwake, A_BrainDie, A_BrainExplode, A_BrainPain,
    A_BrainScream, A_BrainSpit, A_BruisAttack, A_BspiAttack,
    A_CPosAttack, A_CPosRefire, A_Chase, A_CyberAttack,
    A_Detonate, A_Die, A_Explode, A_Face,
    A_FaceTarget, A_Fall, A_FatAttack1, A_FatAttack2,
    A_FatAttack3, A_FatRaise, A_Fire, A_FireCrackle,
    A_HeadAttack, A_Hoof, A_KeenDie, A_LineEffect,
    A_Look, A_Metal, A_Mushroom, A_Pain,
    A_PainAttack, A_PainDie, A_PlaySound, A_PlayerScream,
    A_PosAttack, A_SPosAttack, A_SargAttack, A_Scratch,
    A_Scream, A_SkelFist, A_SkelMissile, A_SkelWhoosh,
    A_SkullAttack, A_Spawn, A_SpawnFly, A_SpawnSound,
    A_SpidRefire, A_StartFire, A_Stop, A_Tracer,
    A_TroopAttack, A_Turn, A_VileAttack, A_VileChase,
    A_VileStart, A_VileTarget, A_XScream
};

void W_CallAction(actionf_t action, void *mobj, void *player, void *psp)
{
    size_t i;

    for (i = 0; i < arrlen(one_arg_actions); ++i)
    {
        if (action.acv == one_arg_actions[i])
        {
            action.acp1(mobj);
            return;
        }
    }

    action.acp3(mobj, player, psp);
}
