//
// Copyright(C) 2026 frunk.store
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//

#ifndef __I_WEB__
#define __I_WEB__

#include "d_think.h"

// Runs one frame; the browser calls it on each screen refresh.
void W_RunFrame(void);

// Calls a state's action with the arguments its function takes.
void W_CallAction(actionf_t action, void *mobj, void *player, void *psp);

#endif
