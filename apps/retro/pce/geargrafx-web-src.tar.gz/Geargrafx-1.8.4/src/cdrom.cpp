/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include "cdrom.h"
#include "scsi_controller.h"
#include "huc6280.h"
#include "memory.h"
#include "trace_logger.h"
#include "geargrafx_core.h"
#include "media.h"
#include "laseractive.h"

CdRom::CdRom(CdRomAudio* cdrom_audio, ScsiController* scsi_controller, GeargrafxCore* core, LaserActive* laseractive)
{
    m_core = core;
    m_cdrom_audio = cdrom_audio;
    m_scsi_controller = scsi_controller;
    m_laseractive = laseractive;
    InitPointer(m_trace_logger);
    InitPointer(m_adpcm);
    InitPointer(m_huc6280);
    InitPointer(m_memory);
    m_reset = 0;
    m_bram_enabled = false;
    m_active_irqs = 0;
    m_enabled_irqs = 0;
    m_cdaudio_sample_toggle = false;
    m_cdaudio_sample = 0;
    m_cdaudio_sample_last_clock = 0;
    m_fader = 0;
    m_fader_enabled = false;
    m_fader_adpcm = false;
    m_fader_fast = false;
    m_fader_start_cycles = 0;
    m_fader_cycles = 0;

    m_state.RESET = &m_reset;
    m_state.BRAM_ENABLED = &m_bram_enabled;
    m_state.ACTIVE_IRQS = &m_active_irqs;
    m_state.ENABLED_IRQS = &m_enabled_irqs;
    m_state.FADER = &m_fader;
}

CdRom::~CdRom()
{
}

void CdRom::Init(HuC6280* huc6280, Memory* memory, Adpcm* adpcm)
{
    m_huc6280 = huc6280;
    m_memory = memory;
    m_adpcm = adpcm;
    Reset();
}

void CdRom::SetTraceLogger(TraceLogger* trace_logger)
{
    m_trace_logger = trace_logger;
}

void CdRom::NotifyMediaEjected()
{
    m_scsi_controller->Reset(true);
}

void CdRom::LogCdRomEvent(u8 event, u8 value)
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    GG_Trace_Entry e = {};
    e.type = TRACE_CDROM;
    e.cdrom.event = event;

    switch (event)
    {
        case TRACE_CDROM_IRQ_SET:
        case TRACE_CDROM_IRQ_CLEAR:
        case TRACE_CDROM_IRQ_ENABLE:
        case TRACE_CDROM_RESET:
            e.cdrom.irq_type = value;
            e.cdrom.active = m_active_irqs;
            e.cdrom.enabled = m_enabled_irqs;
            break;
        case TRACE_CDROM_FADER:
            e.cdrom.irq_type = value;
            break;
        default:
            break;
    }

    m_trace_logger->TraceLog(e);
#else
    UNUSED(event);
    UNUSED(value);
#endif
}

void CdRom::Reset()
{
    m_reset = 0;
    m_bram_enabled = true;
    m_active_irqs = 0;
    m_enabled_irqs = 0;
    m_cdaudio_sample_toggle = false;
    m_cdaudio_sample = 0;
    m_cdaudio_sample_last_clock = 0;
    m_fader = 0;
    m_fader_enabled = false;
    m_fader_adpcm = false;
    m_fader_fast = false;
    m_fader_start_cycles = 0;
    m_fader_cycles = 0;
    m_memory->UpdateBackupRam(m_bram_enabled);
}

u8 CdRom::ReadRegister(u16 address)
{
    if (m_laseractive->IsActive())
    {
        u16 hardware_address = address & 0x1FFF;

        if (hardware_address > 0x180F)
        {
            if ((hardware_address >= 0x18C0) && (hardware_address <= 0x18C3))
                return m_laseractive->ReadSramControl(hardware_address);
            if ((hardware_address >= 0x1920) && (hardware_address <= 0x193F))
                return m_laseractive->ReadRegister((u8)(hardware_address - 0x1920), false);
            if ((hardware_address >= 0x1940) && (hardware_address <= 0x195F))
                return m_laseractive->ReadRegister((u8)(hardware_address - 0x1940), true);
            if (hardware_address >= 0x1960)
                return 0xFF;
            if ((hardware_address >= 0x18C4) || (hardware_address <= 0x18BF))
                address = (u16)(0x1800 | (hardware_address & 0x0F));
        }
    }

    u16 reg = address & 0x3FF;
    switch (reg)
    {
        case 0x00:
            // SCSI get status
            //Debug("CDROM Read SCSI get status %02X", reg);
            return m_scsi_controller->GetStatus();
        case 0x01:
        {
            // SCSI get data
            u8 ret = m_scsi_controller->ReadData();
            //Debug("CDROM Read %02X SCSI get data: %02X", reg, ret);
            return ret;
        }
        case 0x02:
            // IRQs
            //Debug("CDROM Read IRQs %02X", reg);
            return (m_enabled_irqs & 0x7F) | (m_scsi_controller->IsSignalSet(ScsiController::SCSI_SIGNAL_ACK) ? 0x80 : 0x00);
        case 0x03:
        {
            // BRAM Lock
            //Debug("CDROM Read BRAM Lock %02X", reg);
            m_bram_enabled = false;
            m_memory->UpdateBackupRam(m_bram_enabled);
            return m_active_irqs | 0x10 | (m_cdaudio_sample_toggle ? 0x00 : 0x02);
        }
        case 0x04:
            // Reset
            //Debug("CDROM Read Reset %02X", reg);
            return m_reset;
        case 0x05:
            // Audio Sample LSB
            //Debug("CDROM Read Audio Sample LSB %02X", reg);
            return (u8)(m_cdaudio_sample & 0xFF);
        case 0x06:
            // Audio Sample MSB
            //Debug("CDROM Read Audio Sample MSB %02X", reg);
            return (u8)((m_cdaudio_sample >> 8) & 0xFF);
        case 0x07:
            // Is BRAM Locked?
            //Debug("CDROM Read Is BRAM Locked? %02X", reg);
            return m_bram_enabled ? 0x80 : 0x00;
        case 0x08:
        {
            // SCSI get data
            //Debug("+++ CDROM Read SCSI get data %02X", reg);
            u8 ret = m_scsi_controller->ReadData();
            //Debug("CDROM Read %02X SCSI get data: %02X", reg, ret);
            m_scsi_controller->AutoAck();
            return ret;
        }
        case 0x09:
        case 0x0A:
        case 0x0B:
        case 0x0C:
        case 0x0D:
        case 0x0E:
            // ADPCM Read
            //Debug("CDROM Read ADPCM %02X", reg);
            return m_adpcm->Read(reg);
        case 0x0F:
            // Audio Fader
            return m_fader;
        case 0xC0:
        case 0xC1:
        case 0xC2:
        case 0xC3:
            // CDROM Signature
            //Debug("CDROM Read Signature %02X", reg);
            if (m_core->GetMedia()->GetCDROMType() != GG_CDROM_STANDARD)
                return k_super_cdrom_signature[reg & 0x03];
            else
                return 0xFF;
        default:
            Debug("CDROM Read Invalid register %04X", reg);
            return 0xFF;
    }
}

void CdRom::WriteRegister(u16 address, u8 value)
{
    if (m_laseractive->IsActive())
    {
        u16 hardware_address = address & 0x1FFF;

        if (hardware_address > 0x180F)
        {
            if (hardware_address == 0x18C0)
            {
                m_laseractive->WriteSramControl(value);
                return;
            }
            if ((hardware_address >= 0x18C1) && (hardware_address <= 0x18C3))
                return;
            if ((hardware_address >= 0x1920) && (hardware_address <= 0x193F))
            {
                m_laseractive->WriteRegister((u8)(hardware_address - 0x1920), false, value);
                return;
            }
            if ((hardware_address >= 0x1940) && (hardware_address <= 0x195F))
            {
                m_laseractive->WriteRegister((u8)(hardware_address - 0x1940), true, value);
                return;
            }
            if (hardware_address >= 0x1960)
                return;
            if ((hardware_address >= 0x18C4) || (hardware_address <= 0x18BF))
                address = (u16)(0x1800 | (hardware_address & 0x0F));
        }
    }

    u16 reg = address & 0x3FF;
    switch (reg)
    {
        case 0x00:
            // SCSI control
            //Debug("CDROM Write SCSI control %02X, value: %02X", reg, value);
            m_scsi_controller->StartSelection();
            break;
        case 0x01:
            // SCSI command
            //Debug("CDROM Write SCSI command %02X, value: %02X", reg, value);
            m_scsi_controller->WriteData(value);
            break;
        case 0x02:
        {
            // ACK
            //Debug("CDROM Write ACK %02X, value: %02X", reg, value);
            if ((value & 0x80) != 0)
                m_scsi_controller->SetSignal(ScsiController::SCSI_SIGNAL_ACK);
            else
                m_scsi_controller->ClearSignal(ScsiController::SCSI_SIGNAL_ACK);

            m_enabled_irqs = value & 0x7F;

            TraceCdRomEvent(TRACE_CDROM_IRQ_ENABLE, value);

            AssertIRQ2();
            break;
        }
        case 0x04:
            // Reset
            //Debug("CDROM Write Reset %02X, value: %02X", reg, value);
            m_reset = value & 0x0F;
            if ((value & 0x02) != 0)
            {
                m_scsi_controller->SetSignal(ScsiController::SCSI_SIGNAL_RST);
                m_active_irqs &= 0x8F;
                AssertIRQ2();
            }
            else
                m_scsi_controller->ClearSignal(ScsiController::SCSI_SIGNAL_RST);

            TraceCdRomEvent(TRACE_CDROM_RESET, value);

            break;
        case 0x05:
            // Audio Sample
            LatchCdAudioSample();
            break;
        case 0x07:
            // Is BRAM control
            //Debug("CDROM Write BRAM control %02X, value: %02X", reg, value);
            m_bram_enabled = (value & 0x80) != 0;
            m_memory->UpdateBackupRam(m_bram_enabled);
            break;
        case 0x08:
        case 0x09:
        case 0x0A:
        case 0x0B:
        case 0x0C:
        case 0x0D:
        case 0x0E:
            // ADPCM Write
            //Debug("CDROM Write ADPCM %02X, value: %02X", reg, value);
            m_adpcm->Write(reg, value);
            break;
        case 0x0F:
            // Audio Fader
            WriteFader(value);
            break;
        default:
            Debug("CDROM Write Invalid register %04X, value: %02X", reg, value);
            break;
    }
}

void CdRom::SaveState(std::ostream& stream)
{
    using namespace std;

    stream.write(reinterpret_cast<const char*> (&m_reset), sizeof(m_reset));
    stream.write(reinterpret_cast<const char*> (&m_bram_enabled), sizeof(m_bram_enabled));
    stream.write(reinterpret_cast<const char*> (&m_active_irqs), sizeof(m_active_irqs));
    stream.write(reinterpret_cast<const char*> (&m_enabled_irqs), sizeof(m_enabled_irqs));
    stream.write(reinterpret_cast<const char*> (&m_cdaudio_sample_toggle), sizeof(m_cdaudio_sample_toggle));
    stream.write(reinterpret_cast<const char*> (&m_cdaudio_sample), sizeof(m_cdaudio_sample));
    stream.write(reinterpret_cast<const char*> (&m_cdaudio_sample_last_clock), sizeof(m_cdaudio_sample_last_clock));
    stream.write(reinterpret_cast<const char*> (&m_fader), sizeof(m_fader));
    stream.write(reinterpret_cast<const char*> (&m_fader_enabled), sizeof(m_fader_enabled));
    stream.write(reinterpret_cast<const char*> (&m_fader_adpcm), sizeof(m_fader_adpcm));
    stream.write(reinterpret_cast<const char*> (&m_fader_fast), sizeof(m_fader_fast));
    stream.write(reinterpret_cast<const char*> (&m_fader_start_cycles), sizeof(m_fader_start_cycles));
    stream.write(reinterpret_cast<const char*> (&m_fader_cycles), sizeof(m_fader_cycles));
}

void CdRom::LoadState(std::istream& stream, int version)
{
    using namespace std;

    stream.read(reinterpret_cast<char*> (&m_reset), sizeof(m_reset));
    stream.read(reinterpret_cast<char*> (&m_bram_enabled), sizeof(m_bram_enabled));
    stream.read(reinterpret_cast<char*> (&m_active_irqs), sizeof(m_active_irqs));
    stream.read(reinterpret_cast<char*> (&m_enabled_irqs), sizeof(m_enabled_irqs));
    stream.read(reinterpret_cast<char*> (&m_cdaudio_sample_toggle), sizeof(m_cdaudio_sample_toggle));
    stream.read(reinterpret_cast<char*> (&m_cdaudio_sample), sizeof(m_cdaudio_sample));
    stream.read(reinterpret_cast<char*> (&m_cdaudio_sample_last_clock), sizeof(m_cdaudio_sample_last_clock));
    if (version < 27)
        m_cdaudio_sample_last_clock = 0;

    stream.read(reinterpret_cast<char*> (&m_fader), sizeof(m_fader));
    stream.read(reinterpret_cast<char*> (&m_fader_enabled), sizeof(m_fader_enabled));
    stream.read(reinterpret_cast<char*> (&m_fader_adpcm), sizeof(m_fader_adpcm));
    stream.read(reinterpret_cast<char*> (&m_fader_fast), sizeof(m_fader_fast));
    stream.read(reinterpret_cast<char*> (&m_fader_start_cycles), sizeof(m_fader_start_cycles));
    if (version < 27)
        m_fader_start_cycles = 0;

    stream.read(reinterpret_cast<char*> (&m_fader_cycles), sizeof(m_fader_cycles));

    m_memory->UpdateBackupRam(m_bram_enabled);
}
