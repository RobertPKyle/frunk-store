/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <assert.h>
#include <stdlib.h>
#include "scsi_controller.h"
#include "cdrom.h"
#include "cdrom_media.h"
#include "cdrom_audio.h"
#include "huc6280.h"
#include "random.h"
#include "trace_logger.h"
#include "laseractive.h"

static const u32 k_scsi_command_buffer_capacity = 16;
static const u32 k_scsi_data_buffer_capacity = 2048;
static const u32 k_scsi_response_byte_cycles = 900;
static const u32 k_scsi_phase_change_cycles = 1500;
static const u32 k_scsi_initial_read_phase_max_cycles = GG_MASTER_CLOCK_RATE / 60;
static const u8 k_scsi_command_buffer_padding[k_scsi_command_buffer_capacity] = {};
static const u8 k_scsi_data_buffer_padding[k_scsi_data_buffer_capacity] = {};

ScsiController::ScsiController(CdRomMedia* cdrom_media, CdRomAudio* cdrom_audio, Random* random, LaserActive* laseractive)
{
    m_cdrom_media = cdrom_media;
    m_cdrom_audio = cdrom_audio;
    m_random = random;
    m_laseractive = laseractive;
    InitPointer(m_trace_logger);
    m_bus.db = 0;
    m_bus.signals = 0;
    m_phase = SCSI_PHASE_BUS_FREE;
    m_next_event = SCSI_EVENT_NONE;
    m_next_event_cycles = 0;
    m_next_load_cycles = 0;
    m_load_sector = 0;
    m_load_sector_count = 0;
    m_auto_ack_cycles = 0;
    m_initial_read_phase_cycles = 0;
    m_reset_value = -1;
    m_read_speed = 1;
    m_command_buffer.clear();
    m_command_buffer.reserve(k_scsi_command_buffer_capacity);
    m_data_buffer.clear();
    m_data_buffer.reserve(k_scsi_data_buffer_capacity);
    m_data_buffer_offset = 0;
    m_bus_changed = false;
    m_previous_signals = 0;
    m_data_bus_latch = 0;

    m_state.DB = &m_bus.db;
    m_state.SIGNALS = &m_bus.signals;
    m_state.PHASE = &m_phase;
    m_state.NEXT_EVENT = &m_next_event;
    m_state.NEXT_EVENT_CYCLES = &m_next_event_cycles;
    m_state.NEXT_LOAD_CYCLES = &m_next_load_cycles;
    m_state.LOAD_SECTOR = &m_load_sector;
    m_state.LOAD_SECTOR_COUNT = &m_load_sector_count;
}

ScsiController::~ScsiController()
{
}

void ScsiController::Init(CdRom* cdrom)
{
    m_cdrom = cdrom;
    Reset();
}

void ScsiController::SetTraceLogger(TraceLogger* trace_logger)
{
    m_trace_logger = trace_logger;
}

void ScsiController::SetResetValue(int value)
{
    m_reset_value = value;
}

void ScsiController::SetReadSpeed(int speed)
{
    m_read_speed = (u32)CLAMP(speed, 1, 6);
}

void ScsiController::LogScsiEvent(u8 event, u8 command, u8 phase, u8 status,
    u32 param, const u8* data, u8 size)
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    GG_Trace_Entry e = {};
    e.type = TRACE_SCSI;
    e.scsi.event = event;
    e.scsi.command = command;
    e.scsi.phase = phase;
    e.scsi.status = status;
    e.scsi.param = param;
    if (event == TRACE_SCSI_RESPONSE_BYTE)
    {
        if (e.scsi.param > 0)
            e.scsi.param--;
    }
    else if (event == TRACE_SCSI_COMMAND)
    {
        if (command == SCSI_CMD_READ && m_command_buffer.size() >= 5)
            e.scsi.param = ((m_command_buffer[1] & 0x1F) << 16) |
                (m_command_buffer[2] << 8) | m_command_buffer[3];
        e.scsi.size = (u8)MIN(m_command_buffer.size(), sizeof(e.scsi.data));
        if (e.scsi.size > 0)
            memcpy(e.scsi.data, m_command_buffer.data(), e.scsi.size);
    }
    else if (event == TRACE_SCSI_RESPONSE)
    {
        if (m_command_buffer.size() > 1)
            e.scsi.param = m_command_buffer[1] << 8;
        if (m_command_buffer.size() > 2)
            e.scsi.param |= m_command_buffer[2];
        e.scsi.size = MIN(size, (u8)sizeof(e.scsi.data));
        if (e.scsi.size > 0 && IsValidPointer(data))
            memcpy(e.scsi.data, data, e.scsi.size);
    }
    m_trace_logger->TraceLog(e);
#else
    UNUSED(event);
    UNUSED(command);
    UNUSED(phase);
    UNUSED(status);
    UNUSED(param);
    UNUSED(data);
    UNUSED(size);
#endif
}

void ScsiController::LogScsiProblemEvent(u8 event, u8 problem, u8 command, u32 param, u32 extra)
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    GG_Trace_Entry e = {};
    e.type = TRACE_SCSI;
    e.scsi.event = event;
    e.scsi.command = command;
    e.scsi.phase = (u8)m_phase;
    e.scsi.status = problem;
    e.scsi.param = param;
    switch (problem)
    {
        case TRACE_SCSI_PROBLEM_COMMAND_OVERFLOW:
            e.scsi.command = m_command_buffer.empty() ? 0xFF : m_command_buffer[0];
            e.scsi.param = ((u32)m_command_buffer.size() << 8) | m_data_bus_latch;
            break;
        case TRACE_SCSI_PROBLEM_INVALID_READ_REQUEST:
            e.scsi.param = (extra << 24) | param;
            break;
        case TRACE_SCSI_PROBLEM_UNKNOWN_AUDIO_LBA_MODE:
            e.scsi.command = m_command_buffer.empty() ? 0 : m_command_buffer[0];
            break;
        case TRACE_SCSI_PROBLEM_CLAMPED_DATA_OFFSET:
            e.scsi.param = ((u32)m_data_buffer_offset << 16) |
                MIN((u32)m_data_buffer.size(), 0xFFFF);
            break;
        default:
            break;
    }
    m_trace_logger->TraceLog(e);
#else
    UNUSED(event);
    UNUSED(problem);
    UNUSED(command);
    UNUSED(param);
    UNUSED(extra);
#endif
}

void ScsiController::Reset(bool keep_rst_signal)
{
    m_bus.db = 0;
    if (keep_rst_signal)
        m_bus.signals &= SCSI_SIGNAL_RST;
    else    
        m_bus.signals = 0;
    m_phase = SCSI_PHASE_BUS_FREE;
    m_next_event = SCSI_EVENT_NONE;
    m_next_event_cycles = 0;
    m_next_load_cycles = 0;
    m_load_sector = 0;
    m_load_sector_count = 0;
    m_auto_ack_cycles = 0;
    if (!keep_rst_signal)
    {
        if (m_reset_value < 0)
            m_initial_read_phase_cycles = m_random->Next(k_scsi_initial_read_phase_max_cycles + 1);
        else
            m_initial_read_phase_cycles = MIN((u32)m_reset_value, k_scsi_initial_read_phase_max_cycles);
    }
    m_command_buffer.clear();
    m_data_buffer.clear();
    m_data_buffer_offset = 0;
    m_bus_changed = false;
    m_previous_signals = m_bus.signals;
    m_data_bus_latch = 0;
    UpdateIRQs();
    m_cdrom_audio->StopAudio();
    m_cdrom_media->SetCurrentSector(0);
    Debug("SCSI Reset");
}

ScsiController::Scsi_State* ScsiController::GetState()
{
    return &m_state;
}

void ScsiController::StartSelection()
{
    SCSI_DEBUG("SCSI Start selection");

    if (m_phase != SCSI_PHASE_DATA_IN)
        NextEvent(SCSI_EVENT_SET_COMMAND_PHASE, 75000);
    else
    {
        Debug("SCSI Start selection when already in data in phase");
        TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_SELECTION_DURING_DATA_IN, SCSI_CMD_READ, (u32)m_phase);
        StartStatus(SCSI_STATUS_GOOD, 8);
        NextEvent(SCSI_EVENT_SET_COMMAND_PHASE, 900000);
    }
}

void ScsiController::StartStatus(ScsiStatus status, u8 length)
{
    SCSI_DEBUG("SCSI Start status %02X", status);
    TraceScsiEvent(TRACE_SCSI_STATUS, 0, (u8)m_phase, (u8)status, length);
    m_data_buffer.assign(length, (u8)status);
    m_data_buffer_offset = 0;
    m_bus.db = (u8)status;
    SetPhase(SCSI_PHASE_STATUS);
}

void ScsiController::AudioSeekCompleted()
{
    if (m_phase == SCSI_PHASE_BUSY)
        StartStatus(SCSI_STATUS_GOOD);
}


void ScsiController::SetPhase(ScsiPhase phase)
{
    SCSI_DEBUG("----------------");
    SCSI_DEBUG("SCSI Set phase %s", k_scsi_phase_names[phase]);
    SCSI_DEBUG("----------------");

    if (m_phase == phase)
        return;

    ClearSignal(SCSI_SIGNAL_BSY | SCSI_SIGNAL_REQ | SCSI_SIGNAL_CD | SCSI_SIGNAL_MSG | SCSI_SIGNAL_IO);
    m_phase = phase;
    TraceScsiEvent(TRACE_SCSI_PHASE_CHANGE, 0, (u8)m_phase, 0, 0);

    switch (m_phase)
    {
        case SCSI_PHASE_BUS_FREE:
            break;
        case SCSI_PHASE_COMMAND:
            m_next_load_cycles = 0;
            m_data_buffer.clear();
            SetSignal(SCSI_SIGNAL_BSY | SCSI_SIGNAL_CD | SCSI_SIGNAL_REQ);
            break;
        case SCSI_PHASE_DATA_IN:
            SetSignal(SCSI_SIGNAL_BSY | SCSI_SIGNAL_IO);
            break;
        case SCSI_PHASE_MESSAGE_IN:
            SetSignal(SCSI_SIGNAL_BSY | SCSI_SIGNAL_CD | SCSI_SIGNAL_IO | SCSI_SIGNAL_MSG | SCSI_SIGNAL_REQ);
            TraceScsiEvent(TRACE_SCSI_RESPONSE_BYTE, 0, (u8)m_phase, m_bus.db, 0);
            break;
        case SCSI_PHASE_STATUS:
            SetSignal(SCSI_SIGNAL_BSY | SCSI_SIGNAL_CD | SCSI_SIGNAL_IO | SCSI_SIGNAL_REQ);
            TraceScsiEvent(TRACE_SCSI_RESPONSE_BYTE, 0, (u8)m_phase, m_bus.db, 0);
            break;
        case SCSI_PHASE_BUSY:
            SetSignal(SCSI_SIGNAL_BSY);
            break;
        default:
            break;
    }

}

void ScsiController::UpdateScsi()
{
    if (!m_bus_changed)
        return;

    m_bus_changed = false;

    if(IsSignalSet(SCSI_SIGNAL_RST))
    {
        Reset(true);
        return;
    }

    do
    {
        m_bus_changed = false;
        switch (m_phase)
        {
            case SCSI_PHASE_COMMAND:
                UpdateCommandPhase();
                break;
            case SCSI_PHASE_DATA_IN:
                UpdateDataInPhase();
                break;
            case SCSI_PHASE_STATUS:
                UpdateStatusPhase();
                break;
            case SCSI_PHASE_MESSAGE_IN:
                UpdateMessageInPhase();
                break;
            default:
                break;
        }
    }
    while (m_bus_changed);

    UpdateIRQs();
}

void ScsiController::UpdateCommandPhase()
{
    if (IsSignalSet(SCSI_SIGNAL_REQ) && IsSignalSet(SCSI_SIGNAL_ACK))
    {
        ClearSignal(SCSI_SIGNAL_REQ);

        if (m_command_buffer.size() < k_scsi_command_buffer_capacity)
        {
            m_command_buffer.push_back(m_data_bus_latch);
        }
        else
        {
            Debug("SCSI Command buffer overflow %d", (int)m_command_buffer.size());
            TraceScsiProblemEvent(TRACE_SCSI_ERROR, TRACE_SCSI_PROBLEM_COMMAND_OVERFLOW);
            StartStatus(SCSI_STATUS_GOOD);
            m_command_buffer.clear();
        }
    }
    else if (!IsSignalSet(SCSI_SIGNAL_REQ) && !IsSignalSet(SCSI_SIGNAL_ACK) && m_command_buffer.size() > 0)
    {
        u8 opcode = m_command_buffer[0];
        u8 length = CommandLength((ScsiCommand)opcode);

        if (length == 0)
        {
            Debug("SCSI Unknown command %02X", opcode);
            TraceScsiProblemEvent(TRACE_SCSI_ERROR, TRACE_SCSI_PROBLEM_UNKNOWN_COMMAND, opcode, 0);
            StartStatus(SCSI_STATUS_GOOD);
            m_command_buffer.clear();
        }
        else if (m_command_buffer.size() >= length)
        {
            for (size_t i = 0; i < length; i++)
                SCSI_DEBUG("  Command byte %02X", m_command_buffer[i]);
            ExecuteCommand();
            m_command_buffer.clear();
        }
        else
            NextEvent(SCSI_EVENT_SET_REQ_SIGNAL, 3000);
    }
}

void ScsiController::UpdateDataInPhase()
{
    if (IsSignalSet(SCSI_SIGNAL_REQ) && IsSignalSet(SCSI_SIGNAL_ACK))
        ClearSignal(SCSI_SIGNAL_REQ);
    else if (!IsSignalSet(SCSI_SIGNAL_REQ) && !IsSignalSet(SCSI_SIGNAL_ACK))
    {
        if (m_data_buffer.size() > 0)
        {
            bool short_response = m_data_buffer.size() < k_scsi_data_buffer_capacity;
            assert(m_data_buffer_offset < m_data_buffer.size());
            m_bus.db = m_data_buffer[m_data_buffer_offset];
            m_data_buffer_offset++;
            if (m_data_buffer_offset == m_data_buffer.size())
            {
                SCSI_DEBUG("SCSI Data in phase completed %02X, %d", m_bus.signals, m_data_buffer_offset);
                m_data_buffer.clear();
            }
            if (short_response)
            {
                if (m_data_buffer_offset > 1)
                    NextEvent(SCSI_EVENT_SET_RESPONSE_REQ_SIGNAL, k_scsi_response_byte_cycles);
                else
                {
                    SetSignal(SCSI_SIGNAL_REQ);
                    TraceScsiEvent(TRACE_SCSI_RESPONSE_BYTE, 0, (u8)m_phase, m_bus.db, m_data_buffer_offset);
                }
            }
            else
                SetSignal(SCSI_SIGNAL_REQ);
        }
        else
        {
            if (m_load_sector_count == 0)
            {
                SCSI_DEBUG("SCSI Data in phase completed %02X, %d. No more sectors.", m_bus.signals, m_data_buffer_offset);
                NextEvent(SCSI_EVENT_SET_GOOD_STATUS, 3000);
            }
        }
    }
}

void ScsiController::UpdateStatusPhase()
{
    if (IsSignalSet(SCSI_SIGNAL_REQ) && IsSignalSet(SCSI_SIGNAL_ACK))
        ClearSignal(SCSI_SIGNAL_REQ);
    else if (!IsSignalSet(SCSI_SIGNAL_REQ) && !IsSignalSet(SCSI_SIGNAL_ACK))
    {
        if (m_data_buffer.size() > 0)
        {
            assert(m_data_buffer_offset < m_data_buffer.size());
            m_bus.db = m_data_buffer[m_data_buffer_offset];
            m_data_buffer_offset++;
            if (m_data_buffer_offset == m_data_buffer.size())
            {
                SCSI_DEBUG("SCSI Status phase completed");
                m_data_buffer.clear();
                NextEvent(SCSI_EVENT_SET_MESSAGE_IN_PHASE, k_scsi_phase_change_cycles);
            }
            else
                NextEvent(SCSI_EVENT_SET_RESPONSE_REQ_SIGNAL, k_scsi_phase_change_cycles);
        }
    }
}

void ScsiController::UpdateMessageInPhase()
{
    if (IsSignalSet(SCSI_SIGNAL_REQ) && IsSignalSet(SCSI_SIGNAL_ACK))
        ClearSignal(SCSI_SIGNAL_REQ);
    else if (!IsSignalSet(SCSI_SIGNAL_REQ) && !IsSignalSet(SCSI_SIGNAL_ACK))
    {
        SCSI_DEBUG("SCSI Message in phase completed");
        NextEvent(SCSI_EVENT_SET_BUS_FREE_PHASE, k_scsi_phase_change_cycles);
    }
}

void ScsiController::ExecuteCommand()
{
    ScsiCommand command = (ScsiCommand)m_command_buffer[0];
    TraceScsiEvent(TRACE_SCSI_COMMAND, m_command_buffer[0], (u8)m_phase);

    switch(command)
    {
        case SCSI_CMD_TEST_UNIT_READY:
            CommandTestUnitReady();
            break;
        case SCSI_CMD_REQUEST_SENSE:
            CommandRequestSense();
            break;
        case SCSI_CMD_READ:
            CommandRead();
            break;
        case SCSI_CMD_AUDIO_START_POSITION:
            CommandAudioStartPosition();
            break;
        case SCSI_CMD_AUDIO_STOP_POSITION:
            CommandAudioStopPosition();
            break;
        case SCSI_CMD_AUDIO_PAUSE:
            CommandAudioPause();
            break;
        case SCSI_CMD_READ_SUBCODE_Q:
            CommandReadSubcodeQ();
            break;
        case SCSI_CMD_READ_TOC:
            CommandReadTOC();
            break;
        default:
            Debug("SCSI Trying to execute unknown command %02X", command);
            break;
    }
}

void ScsiController::CommandTestUnitReady()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Test Unit Ready");
    SCSI_DEBUG("******");

    NextEvent(SCSI_EVENT_SET_GOOD_STATUS, 450000);
}

void ScsiController::CommandRequestSense()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Request Sense");
    SCSI_DEBUG("******");

    NextEvent(SCSI_EVENT_SET_GOOD_STATUS, TimeToCycles(21000));
}

void ScsiController::CommandRead()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Read");
    SCSI_DEBUG("******");

    u32 lba = ((m_command_buffer[1] & 0x1F) << 16) | (m_command_buffer[2] << 8) | m_command_buffer[3];
    u16 count = m_command_buffer[4];
    if (count == 0)
        count = 256;

    if (lba >= m_cdrom_media->GetSectorCount())
    {
        Debug("SCSI CMD Read: Invalid sector");
        TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_INVALID_READ_REQUEST, SCSI_CMD_READ, lba, count);
        StartStatus(SCSI_STATUS_GOOD);
        return;
    }

    u32 current_lba = m_cdrom_media->GetCurrentSector();
    u32 seek_time = m_cdrom_media->SeekTime(current_lba, lba);
    u32 seek_cycles = ReadCycles(TimeToCycles(seek_time * 1000));
    u32 transfer_cycles = ReadCycles(m_cdrom_media->SectorTransferCycles());
    if (m_laseractive->IsActive())
        seek_cycles = m_laseractive->NotifyScsiReadStart(lba);

    if (m_initial_read_phase_cycles > 0)
    {
        seek_cycles += m_initial_read_phase_cycles;
        m_initial_read_phase_cycles = 0;
    }

    m_next_load_cycles = seek_cycles + transfer_cycles;
    m_load_sector = lba;
    m_load_sector_count = count;

    SCSI_DEBUG("SCSI CMD Read: current lba %d, target lba %d, count %d, seek cycles %d, transfer cycles %d", current_lba, lba, count, seek_cycles, transfer_cycles);

    SetPhase(SCSI_PHASE_DATA_IN);
    m_cdrom_audio->SetIdle();
}

void ScsiController::CommandAudioStartPosition()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Audio Start Position");
    SCSI_DEBUG("******");

    u32 start_lba = AudioLBA();
    if (start_lba >= m_cdrom_media->GetSectorCount())
    {
        Debug("SCSI CMD Audio Start Position: Invalid start LBA %d", start_lba);
        TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_INVALID_AUDIO_START_LBA,
                     SCSI_CMD_AUDIO_START_POSITION, start_lba);
        StartStatus(SCSI_STATUS_GOOD);
        return;
    }

    u8 mode = m_command_buffer[1];

    SCSI_DEBUG("SCSI CMD Audio Start Position: start LBA %d, mode %02X", start_lba, mode);

    if (!m_cdrom_media->IsReady())
    {
        StartStatus(SCSI_STATUS_CHECK_CONDITION);
        return;
    }

    m_cdrom_audio->StartAudio(start_lba, mode == 0);

    if ((mode == 0) && !m_cdrom_audio->IsSeeking())
        StartStatus(SCSI_STATUS_GOOD);
    else
        SetPhase(SCSI_PHASE_BUSY);
}

void ScsiController::CommandAudioStopPosition()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Audio Stop Position");
    SCSI_DEBUG("******");

    u32 stop_lba = AudioLBA();
    u8 mode = m_command_buffer[1];

    SCSI_DEBUG("SCSI CMD Audio Stop Position: stop LBA %d, mode %02X", stop_lba, mode);

    if (!m_cdrom_media->IsReady())
    {
        StartStatus(SCSI_STATUS_CHECK_CONDITION);
        return;
    }

    switch (mode)
    {
        case 0:
            m_cdrom_audio->StopAudio();
            break;
        case 1:
            m_cdrom_audio->SetStopLBA(stop_lba, CdRomAudio::CD_AUDIO_STOP_EVENT_LOOP);
            break;
        case 2:
            m_cdrom_audio->SetStopLBA(stop_lba, CdRomAudio::CD_AUDIO_STOP_EVENT_IRQ);
            break;
        case 3:
            m_cdrom_audio->SetStopLBA(stop_lba, CdRomAudio::CD_AUDIO_STOP_EVENT_STOP);
            break;
        default:
            Debug("SCSI CMD Audio Stop Position: Unknown mode %02X", m_command_buffer[1]);
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_UNKNOWN_AUDIO_STOP_MODE,
                         SCSI_CMD_AUDIO_STOP_POSITION, m_command_buffer[1]);
            break;
    }

    if((mode == 1) || (mode == 2))
        SetPhase(SCSI_PHASE_BUSY);
    else
        StartStatus(SCSI_STATUS_GOOD);
}

void ScsiController::CommandAudioPause()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Audio Pause");
    SCSI_DEBUG("******");

    if (!m_cdrom_media->IsReady())
    {
        StartStatus(SCSI_STATUS_CHECK_CONDITION);
        return;
    }

    m_cdrom_audio->PauseAudio();

    StartStatus(SCSI_STATUS_GOOD);
}

void ScsiController::CommandReadSubcodeQ()
{
    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Read Subcode Q");
    SCSI_DEBUG("******");

    if (!m_cdrom_media->IsReady())
    {
        StartStatus(SCSI_STATUS_CHECK_CONDITION);
        return;
    }

    CdRomAudio::CdAudioState audio_state = m_cdrom_audio->GetSubcodeState();
    u32 current_lba = (m_cdrom_audio->GetCurrentState() == CdRomAudio::CD_AUDIO_STATE_IDLE) ?
        m_cdrom_media->GetCurrentSector() : m_cdrom_audio->GetSubcodeLBA();
    s32 current_track = m_cdrom_media->GetTrackFromLBA(current_lba);
    bool is_data_track = current_track >= 0 ? m_cdrom_media->GetTrackType(current_track) != GG_CDROM_AUDIO_TRACK : false;
    u8 adr_control = is_data_track ? 0x41 : 0x01;

    u32 lba_offset = current_track >= 0 ? current_lba - m_cdrom_media->GetFirstSectorOfTrack(current_track) : 0;

    GG_CdRomMSF relative;
    GG_CdRomMSF absolute;

    LbaToMsf(lba_offset, &relative);
    LbaToMsf(current_lba + 150, &absolute);

    const int buffer_size = 10;
    u8 buffer[buffer_size] = { };

    buffer[0] = (u8)audio_state;
    buffer[1] = adr_control;
    buffer[2] = DecToBcd(current_track + 1);
    buffer[3] = 1;
    buffer[4] = DecToBcd(relative.minutes);
    buffer[5] = DecToBcd(relative.seconds);
    buffer[6] = DecToBcd(relative.frames);
    buffer[7] = DecToBcd(absolute.minutes);
    buffer[8] = DecToBcd(absolute.seconds);
    buffer[9] = DecToBcd(absolute.frames);

    if (m_cdrom_media->IsMmi())
    {
        s32 lba = m_laseractive->IsActive() ? m_laseractive->GetHeadLba() : (s32)current_lba;
        u8 captured_q[12];

        if (m_cdrom_media->ReadSubchannelQ(lba, captured_q))
        {
            memcpy(buffer + 1, captured_q, 6);
            memcpy(buffer + 7, captured_q + 7, 3);
        }
        else if (lba < 0)
        {
            LbaToMsf((u32)-(s64)lba, &relative);
            LbaToMsf((u32)MAX((s64)lba + 150, 0LL), &absolute);
            buffer[3] = 0;
            buffer[4] = DecToBcd(relative.minutes);
            buffer[5] = DecToBcd(relative.seconds);
            buffer[6] = DecToBcd(relative.frames);
            buffer[7] = DecToBcd(absolute.minutes);
            buffer[8] = DecToBcd(absolute.seconds);
            buffer[9] = DecToBcd(absolute.frames);
        }
    }

    m_data_buffer.assign(buffer, buffer + buffer_size);
    m_data_buffer_offset = 0;
    TraceScsiEvent(TRACE_SCSI_RESPONSE, SCSI_CMD_READ_SUBCODE_Q, (u8)m_phase, 0, 0, buffer, buffer_size);

    SCSI_DEBUG("SCSI CMD Read Subcode Q: audio state %d, track %d, relative %02X:%02X:%02X, absolute %02X:%02X:%02X",
               audio_state, current_track + 1, relative.minutes, relative.seconds, relative.frames,
               absolute.minutes, absolute.seconds, absolute.frames);

    NextEvent(SCSI_EVENT_SET_DATA_IN_PHASE, 3000);
}

void ScsiController::CommandReadTOC()
{
    if (!m_cdrom_media->IsReady())
    {
        StartStatus(SCSI_STATUS_CHECK_CONDITION);
        return;
    }

    SCSI_DEBUG("******");
    SCSI_DEBUG("SCSI CMD Read TOC");
    SCSI_DEBUG("******");

    const int buffer_size = 4;
    u8 mode = m_command_buffer[1];

    switch (mode)
    {
        case 0x00:
        {
            u8 buffer[buffer_size] = { 0x01, 0x00, 0x00, 0x00 };
            u8 track_count = m_cdrom_media->GetTrackCount();
            buffer[1] = DecToBcd(track_count);
            SCSI_DEBUG("Number of tracks: %d", track_count);
            m_data_buffer.assign(buffer, buffer + buffer_size);
            m_data_buffer_offset = 0;
            TraceScsiEvent(TRACE_SCSI_RESPONSE, SCSI_CMD_READ_TOC, (u8)m_phase, 0, 0, buffer, buffer_size);
            NextEvent(SCSI_EVENT_SET_DATA_IN_PHASE, 9000);
            break;
        }
        case 0x01:
        {
            u8 buffer[buffer_size] = { 0x00, 0x00, 0x00, 0x00 };
            GG_CdRomMSF length = m_cdrom_media->GetCdRomLength();
            buffer[0] = DecToBcd(length.minutes);
            buffer[1] = DecToBcd(length.seconds);
            buffer[2] = DecToBcd(length.frames);
            m_data_buffer.assign(buffer, buffer + buffer_size);
            m_data_buffer_offset = 0;
            TraceScsiEvent(TRACE_SCSI_RESPONSE, SCSI_CMD_READ_TOC, (u8)m_phase,
                0, 0, buffer, buffer_size);
            SCSI_DEBUG("Disc length: %d %02X:%02X:%02X", MsfToLba(&length), buffer[0], buffer[1], buffer[2]);
            NextEvent(SCSI_EVENT_SET_DATA_IN_PHASE, 9000);
            break;
        }
        case 0x02:
        {
            u8 track = BcdToDec(m_command_buffer[2]);

            if (track == 0)
                track = 1;

            u8 type = 0x04;
            u8 track_count = m_cdrom_media->GetTrackCount();
            GG_CdRomMSF start_msf = { 0, 0, 0 };
            if (track > track_count)
            {
                start_msf = m_cdrom_media->GetCdRomLength();
                type = 0x00;
            }
            else
            {
                if (m_cdrom_media->GetTrackType(track - 1) == GG_CDROM_AUDIO_TRACK)
                    type = 0x00;

                u32 first_sector = m_cdrom_media->GetFirstSectorOfTrack(track - 1);
                u32 start_lba = first_sector + 150;
                LbaToMsf(start_lba, &start_msf);
            }

            u8 buffer[buffer_size] = { 0x00, 0x00, 0x00, 0x00 };
            buffer[0] = DecToBcd(start_msf.minutes);
            buffer[1] = DecToBcd(start_msf.seconds);
            buffer[2] = DecToBcd(start_msf.frames);
            buffer[3] = type;
            SCSI_DEBUG("Track %d start: %d %02X:%02X:%02X, type: %d", track, MsfToLba(&start_msf), buffer[0], buffer[1], buffer[2], type);
            m_data_buffer.assign(buffer, buffer + buffer_size);
            m_data_buffer_offset = 0;
            TraceScsiEvent(TRACE_SCSI_RESPONSE, SCSI_CMD_READ_TOC, (u8)m_phase, 0, 0, buffer, buffer_size);

            NextEvent(SCSI_EVENT_SET_DATA_IN_PHASE, 9000);
            break;
        }
        default:
            Debug("SCSI CMD Read TOC: Unknown mode %02X", mode);
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_UNKNOWN_TOC_MODE,
                         SCSI_CMD_READ_TOC, mode);
            break;
    }
}

u32 ScsiController::ReadCycles(u32 cycles)
{
    return m_laseractive->IsActive() ? cycles : cycles / m_read_speed;
}

void ScsiController::LoadSector()
{
    if (m_data_buffer.empty())
    {
        if (m_load_sector >= m_cdrom_media->GetSectorCount())
        {
            Debug("SCSI Load sector: sector %d past end of disc", m_load_sector);
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_READ_PAST_END, SCSI_CMD_READ, m_load_sector);
            m_load_sector_count = 0;
            m_next_load_cycles = 0;
            StartStatus(SCSI_STATUS_CHECK_CONDITION);
            return;
        }

        m_data_buffer.resize(k_scsi_data_buffer_capacity);
        m_data_buffer_offset = 0;
        if (!m_cdrom_media->ReadSector(m_load_sector, m_data_buffer.data()))
        {
            Debug("SCSI Load sector: failed to read sector %d", m_load_sector);
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_READ_SECTOR_FAILED, SCSI_CMD_READ, m_load_sector);
            m_data_buffer.clear();
            m_data_buffer_offset = 0;
            m_load_sector_count = 0;
            m_next_load_cycles = 0;
            StartStatus(SCSI_STATUS_CHECK_CONDITION);
            return;
        }

    SCSI_DEBUG("SCSI Load sector %d", m_load_sector);

        m_load_sector++;
        m_load_sector &= 0x1FFFFF;
        m_load_sector_count--;

        if (m_laseractive->IsActive())
            m_laseractive->NotifyScsiSectorRead(m_load_sector - 1, m_load_sector_count == 0);

        if (m_load_sector_count == 0)
            m_next_load_cycles = 0;
        else
            m_next_load_cycles = ReadCycles(m_cdrom_media->SectorTransferCycles());

        SCSI_DEBUG("SCSI Sectors left: %d, next:%d, cycles: %d", m_load_sector_count, m_load_sector, m_next_load_cycles);

        m_bus_changed = true;
    }
    else if (m_read_speed > 1 && !m_laseractive->IsActive())
        m_next_load_cycles = 1;
    else
    {
        Debug("**** SCSI Load sector: buffer not empty *******************");
        Debug("**** Data buffer size: %d, offset: %d", m_data_buffer.size(), m_data_buffer_offset);
        TraceScsiEvent(TRACE_SCSI_SECTOR_RETRY, SCSI_CMD_READ, (u8)m_phase,
            (u8)m_load_sector_count, (m_load_sector << 11) | m_data_buffer_offset);

        m_next_load_cycles = TimeToCycles(290000);
    }
}

u32 ScsiController::AudioLBA()
{
    u8 mode = m_command_buffer[9] & 0xC0;

    switch (mode)
    {
        case 0x00:
            return m_command_buffer[3] << 16 | m_command_buffer[4] << 8 | m_command_buffer[5];
        case 0x40:
        {
            GG_CdRomMSF position;
            position.minutes = BcdToDec(m_command_buffer[2]);
            position.seconds = BcdToDec(m_command_buffer[3]);
            position.frames = BcdToDec(m_command_buffer[4]);
            u32 lba = MsfToLba(&position);
            return lba - 150;
        }
        case 0x80:
        {
            int track = BcdToDec(m_command_buffer[2]) - 1;
            if (track >= 0)
                return m_cdrom_media->GetFirstSectorOfTrack(track);
            else
                return 0;
        }
        default:
        {
            Debug("SCSI CMD Audio LBA: Unknown mode %02X", mode);
            TraceScsiProblemEvent(TRACE_SCSI_ERROR, TRACE_SCSI_PROBLEM_UNKNOWN_AUDIO_LBA_MODE,
                         0, mode);
            assert(false);
            return 0;
        }
    }
}

void ScsiController::SaveState(std::ostream& stream)
{
    using namespace std;

    stream.write(reinterpret_cast<const char*> (&m_bus.db), sizeof(m_bus.db));
    stream.write(reinterpret_cast<const char*> (&m_bus.signals), sizeof(m_bus.signals));
    stream.write(reinterpret_cast<const char*> (&m_phase), sizeof(m_phase));
    stream.write(reinterpret_cast<const char*> (&m_next_event), sizeof(m_next_event));
    stream.write(reinterpret_cast<const char*> (&m_next_event_cycles), sizeof(m_next_event_cycles));
    stream.write(reinterpret_cast<const char*> (&m_next_load_cycles), sizeof(m_next_load_cycles));
    stream.write(reinterpret_cast<const char*> (&m_load_sector), sizeof(m_load_sector));
    stream.write(reinterpret_cast<const char*> (&m_load_sector_count), sizeof(m_load_sector_count));
    stream.write(reinterpret_cast<const char*> (&m_auto_ack_cycles), sizeof(m_auto_ack_cycles));
    u32 command_buffer_size = MIN((u32)m_command_buffer.size(), k_scsi_command_buffer_capacity);
    stream.write(reinterpret_cast<const char*> (&command_buffer_size), sizeof(command_buffer_size));
    if (command_buffer_size > 0)
        stream.write(reinterpret_cast<const char*> (m_command_buffer.data()), command_buffer_size * sizeof(u8));
    if (command_buffer_size < k_scsi_command_buffer_capacity)
    {
        stream.write(reinterpret_cast<const char*> (k_scsi_command_buffer_padding),
                     (k_scsi_command_buffer_capacity - command_buffer_size) * sizeof(u8));
    }

    u32 data_buffer_size = MIN((u32)m_data_buffer.size(), k_scsi_data_buffer_capacity);
    stream.write(reinterpret_cast<const char*> (&data_buffer_size), sizeof(data_buffer_size));
    if (data_buffer_size > 0)
        stream.write(reinterpret_cast<const char*> (m_data_buffer.data()), data_buffer_size * sizeof(u8));
    if (data_buffer_size < k_scsi_data_buffer_capacity)
    {
        stream.write(reinterpret_cast<const char*> (k_scsi_data_buffer_padding),
                     (k_scsi_data_buffer_capacity - data_buffer_size) * sizeof(u8));
    }

    stream.write(reinterpret_cast<const char*> (&m_data_buffer_offset), sizeof(m_data_buffer_offset));
    stream.write(reinterpret_cast<const char*> (&m_bus_changed), sizeof(m_bus_changed));
    stream.write(reinterpret_cast<const char*> (&m_previous_signals), sizeof(m_previous_signals));
    stream.write(reinterpret_cast<const char*> (&m_data_bus_latch), sizeof(m_data_bus_latch));
    u32 current_sector = m_cdrom_media->GetCurrentSector();
    stream.write(reinterpret_cast<const char*> (&current_sector), sizeof(current_sector));
    stream.write(reinterpret_cast<const char*> (&m_initial_read_phase_cycles), sizeof(m_initial_read_phase_cycles));
}

void ScsiController::LoadState(std::istream& stream, int version)
{
    using namespace std;

    stream.read(reinterpret_cast<char*> (&m_bus.db), sizeof(m_bus.db));
    stream.read(reinterpret_cast<char*> (&m_bus.signals), sizeof(m_bus.signals));
    stream.read(reinterpret_cast<char*> (&m_phase), sizeof(m_phase));
    stream.read(reinterpret_cast<char*> (&m_next_event), sizeof(m_next_event));
    stream.read(reinterpret_cast<char*> (&m_next_event_cycles), sizeof(m_next_event_cycles));
    stream.read(reinterpret_cast<char*> (&m_next_load_cycles), sizeof(m_next_load_cycles));
    stream.read(reinterpret_cast<char*> (&m_load_sector), sizeof(m_load_sector));
    stream.read(reinterpret_cast<char*> (&m_load_sector_count), sizeof(m_load_sector_count));
    stream.read(reinterpret_cast<char*> (&m_auto_ack_cycles), sizeof(m_auto_ack_cycles));
    u32 command_buffer_size = 0;
    stream.read(reinterpret_cast<char*> (&command_buffer_size), sizeof(command_buffer_size));
    if (stream.fail())
        return;

    if (version >= 27)
    {
        u8 command_buffer[k_scsi_command_buffer_capacity] = {};
        stream.read(reinterpret_cast<char*> (command_buffer), sizeof(command_buffer));
        if (stream.fail())
            return;

        if (command_buffer_size > k_scsi_command_buffer_capacity)
        {
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_CLAMPED_COMMAND_SIZE,
                         0, command_buffer_size);
        }

        command_buffer_size = MIN(command_buffer_size, k_scsi_command_buffer_capacity);
        m_command_buffer.assign(command_buffer, command_buffer + command_buffer_size);
    }
    else
    {
        if (command_buffer_size > k_scsi_command_buffer_capacity)
        {
            stream.setstate(ios::failbit);
            return;
        }

        u8 command_buffer[k_scsi_command_buffer_capacity] = {};
        stream.read(reinterpret_cast<char*>(command_buffer), command_buffer_size);
        if (stream.fail())
            return;
        m_command_buffer.assign(command_buffer, command_buffer + command_buffer_size);
    }

    u32 data_buffer_size = 0;
    stream.read(reinterpret_cast<char*> (&data_buffer_size), sizeof(data_buffer_size));
    if (stream.fail())
        return;

    if (version >= 27)
    {
        u8 data_buffer[k_scsi_data_buffer_capacity] = {};
        stream.read(reinterpret_cast<char*> (data_buffer), sizeof(data_buffer));
        if (stream.fail())
            return;

        if (data_buffer_size > k_scsi_data_buffer_capacity)
        {
            TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_CLAMPED_DATA_SIZE,
                         0, data_buffer_size);
        }

        data_buffer_size = MIN(data_buffer_size, k_scsi_data_buffer_capacity);
        m_data_buffer.assign(data_buffer, data_buffer + data_buffer_size);
    }
    else
    {
        if (data_buffer_size > k_scsi_data_buffer_capacity)
        {
            stream.setstate(ios::failbit);
            return;
        }

        u8 data_buffer[k_scsi_data_buffer_capacity] = {};
        stream.read(reinterpret_cast<char*>(data_buffer), data_buffer_size);
        if (stream.fail())
            return;
        m_data_buffer.assign(data_buffer, data_buffer + data_buffer_size);
    }

    stream.read(reinterpret_cast<char*> (&m_data_buffer_offset), sizeof(m_data_buffer_offset));
    stream.read(reinterpret_cast<char*> (&m_bus_changed), sizeof(m_bus_changed));
    stream.read(reinterpret_cast<char*> (&m_previous_signals), sizeof(m_previous_signals));
    stream.read(reinterpret_cast<char*> (&m_data_bus_latch), sizeof(m_data_bus_latch));
    u32 current_sector = 0;
    stream.read(reinterpret_cast<char*> (&current_sector), sizeof(current_sector));

    if (version >= 40)
    {
        stream.read(reinterpret_cast<char*> (&m_initial_read_phase_cycles), sizeof(m_initial_read_phase_cycles));
        m_initial_read_phase_cycles = MIN(m_initial_read_phase_cycles, k_scsi_initial_read_phase_max_cycles);
    }
    else
        m_initial_read_phase_cycles = 0;

    if (stream.fail())
        return;

    u32 max_data_buffer_offset = m_data_buffer.empty() ?
        k_scsi_data_buffer_capacity : (u32)m_data_buffer.size();

    if (m_data_buffer_offset > max_data_buffer_offset)
    {
        TraceScsiProblemEvent(TRACE_SCSI_WARNING, TRACE_SCSI_PROBLEM_CLAMPED_DATA_OFFSET);
        m_data_buffer_offset = max_data_buffer_offset;
    }

    m_cdrom_media->SetCurrentSector(current_sector);
}
