/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef INPUT_H
#define INPUT_H

#include <iostream>
#include <fstream>
#include "common.h"
#include "mb128.h"
#include "turbolink.h"

class GeargrafxCore;
class Media;
class TraceLogger;

class Input
{
public:
    Input(Media* media, GeargrafxCore* core);
    void Init();
    void Reset();
    void KeyPressed(GG_Controllers controller, GG_Keys key);
    void KeyReleased(GG_Controllers controller, GG_Keys key);
    bool IsKeyPressed(GG_Controllers controller, GG_Keys key) const;
    u8 ReadK();
    void WriteO(u8 value);
    u8 GetIORegister();
    void SetIORegister(u8 value);
    bool GetSel();
    bool GetClr();
    void EndFrame();
    void EnablePCEJap(bool enable);
    void EnableCDROM(bool enable);
    void EnableTurboTap(bool enabled);
    void EnableTurbo(GG_Controllers controller, GG_Keys key, bool enabled);
    bool IsTurboEnabled(GG_Controllers controller, GG_Keys key);
    void SetTurboSpeed(GG_Controllers controller, GG_Keys key, u8 speed);
    void SetControllerType(GG_Controllers controller, GG_Controller_Type type);
    GG_Controller_Type GetControllerType(GG_Controllers controller);
    void SetAvenuePad3Button(GG_Controllers controller, GG_Keys button);
    GG_Keys GetAvenuePad3Button(GG_Controllers controller);
    void SetMouseDelta(s32 x, s32 y);
    void EnableMB128(bool enable);
    void SetTurboLinkCallbacks(GG_TurboLink_Publish_Callback publish_callback, GG_TurboLink_Sample_Callback sample_callback,
        GG_TurboLink_Sync_Callback sync_callback, void* user_data);
    void SetTurboLinkCableConnected(bool connected);
    void InvalidateTurboLinkSample();
    bool IsTurboLinkCableConnected() const;
    void SynchronizeTurboLink(u64 cycles);
    GG_TurboLink_Drive GetTurboLinkDrive() const;
    bool HasTurboLinkSample() const;
    u8 GetTurboLinkLastSampledLines() const;
    u8 GetTurboLinkLastPortResult() const;
    u8 GetTurboLinkLastSamplePullLowMask() const;
    bool GetTurboLinkLastSampleSel() const;
    bool GetTurboLinkLastSampleClr() const;
    u64 GetTurboLinkLastSampleTick() const;
    u64 GetTurboLinkLastControlTick() const;
    u64 GetTurboLinkLastDriveTick() const;
    void SetTraceLogger(TraceLogger* trace_logger);
    MB128* GetMB128();
    void SaveState(std::ostream& stream);
    void LoadState(std::istream& stream, int version, bool has_mb128_flag);

private:
    u64 GetMasterClockCycles();
    u64 GetTurboLinkCycles();
    void TraceInputEvent(u8 event, u8 value);
    void TraceTurboLinkEvent(u8 event, u8 value, u64 tick, u8 lines);
    void LogInputEvent(u8 event, u8 value);
    void LogTurboLinkEvent(u8 event, u8 value, u64 tick, u8 lines);

private:
    Media* m_media;
    GeargrafxCore* m_core;
    TraceLogger* m_trace_logger;
    bool m_clr;
    bool m_sel;
    u16 m_gamepads[GG_MAX_GAMEPADS];
    u8 m_register;
    bool m_pce_jap;
    bool m_cdrom;
    bool m_turbo_tap;
    GG_Controller_Type m_controller_type[GG_MAX_GAMEPADS];
    int m_selected_pad;
    bool m_selected_extra_buttons;
    GG_Keys m_avenue_pad_3_button[GG_MAX_GAMEPADS];
    u16 m_avenue_pad_3_state[GG_MAX_GAMEPADS];
    bool m_turbo_enabled[GG_MAX_GAMEPADS][2];
    bool m_turbo_state[GG_MAX_GAMEPADS][2];
    u8 m_turbo_counter[GG_MAX_GAMEPADS][2];
    u8 m_turbo_speed[GG_MAX_GAMEPADS][2];
    s32 m_mouse_x;
    s32 m_mouse_y;
    u16 m_mouse_shifter;
    bool m_mouse_latched;
    u64 m_mouse_last_latch_cycles;
    MB128 m_mb128;
    TurboLink m_turbolink;
};

#include "input_inline.h"

#endif /* INPUT_H */
