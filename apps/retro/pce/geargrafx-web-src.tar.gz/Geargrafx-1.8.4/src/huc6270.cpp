/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <stdlib.h>
#include <assert.h>
#include "huc6270.h"
#include "trace_logger.h"

HuC6270::HuC6270(HuC6280* huC6280)
{
    m_huc6280 = huC6280;
    InitPointer(m_huc6260);
    InitPointer(m_input_pump_fn);
    m_chip_id = 0;
    InitPointer(m_trace_logger);
    m_state.AR = &m_address_register;
    m_state.SR = &m_status_register;
    m_state.R = m_register;
    m_state.READ_BUFFER = &m_read_buffer;
    m_state.HPOS = &m_hpos;
    m_state.VPOS = &m_vpos;
    m_state.V_STATE = &m_v_state;
    m_state.H_STATE = &m_h_state;
    m_no_sprite_limit = false;
    m_safe_defaults = false;
}

HuC6270::~HuC6270()
{
}

void HuC6270::Init(HuC6260* huC6260, HuC6202* huC6202, GG_Input_Pump_Fn input_pump_fn, int chip_id)
{
    m_huc6260 = huC6260;
    m_huc6202 = huC6202;
    m_input_pump_fn = input_pump_fn;
    m_chip_id = chip_id;
    Reset();
}

void HuC6270::SetTraceLogger(TraceLogger* trace_logger)
{
    m_trace_logger = trace_logger;
}

void HuC6270::LogVdcEvent(u8 event, u8 raw, bool msb)
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    GG_Trace_Entry e = {};
    e.type = TRACE_VDC;
    e.vdc.event = event;
    e.vdc.chip = m_chip_id;

    switch (event)
    {
        case TRACE_VDC_REG_WRITE:
            e.vdc.reg = (u8)(m_address_register);
            e.vdc.value = m_register[m_address_register];
            e.vdc.raw = raw;
            e.vdc.msb = msb ? 1 : 0;
            break;
        case TRACE_VDC_SCANLINE_IRQ:
            e.vdc.value = m_register[HUC6270_REG_RCR];
            break;
        case TRACE_VDC_VRAM_DMA_START:
            e.vdc.value = m_vram_transfer_src;
            e.vdc.value2 = m_vram_transfer_dest;
            e.vdc.value3 = m_register[HUC6270_REG_DCR];
            e.vdc.param = (u32)m_register[HUC6270_REG_LENR] + 1;
            break;
        case TRACE_VDC_SATB_DMA_START:
            e.vdc.value = m_register[HUC6270_REG_DVSSR];
            break;
        default:
            break;
    }

    m_trace_logger->TraceLog(e);
#else
    UNUSED(event);
    UNUSED(raw);
    UNUSED(msb);
#endif
}

void HuC6270::LogSpriteBudget()
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    bool trace_budget = m_trace_logger->IsEventEnabled(TRACE_VDC, TRACE_VDC_SPRITE_BUDGET);
    bool trace_limit = m_trace_logger->IsEventEnabled(TRACE_VDC, TRACE_VDC_SPRITE_LIMIT);

    if (!trace_budget && !trace_limit)
        return;

    int requested = 0;

    for (int i = 0; i < HUC6270_SPRITES; i++)
    {
        int sprite_offset = i << 2;
        int sprite_y = (m_sat[sprite_offset + 0] & 0x3FF) - 64;
        u16 flags = m_sat[sprite_offset + 3];
        int height = k_huc6270_sprite_height[(flags >> 12) & 0x03];

        if ((sprite_y <= m_raster_line) && ((sprite_y + height) > m_raster_line))
            requested += ((flags >> 8) & 0x01) + 1;
    }

    bool limit = requested > 16;

    if (!trace_budget && !limit)
        return;

    GG_Trace_Entry e = {};
    e.type = TRACE_VDC;
    e.vdc.chip = m_chip_id;
    e.vdc.value = (u16)m_raster_line;
    e.vdc.value2 = (u16)m_sprite_count;
    e.vdc.value3 = (u16)requested;

    if (trace_budget)
    {
        e.vdc.event = TRACE_VDC_SPRITE_BUDGET;
        m_trace_logger->TraceLog(e);
    }

    if (trace_limit && limit)
    {
        e.vdc.event = TRACE_VDC_SPRITE_LIMIT;
        m_trace_logger->TraceLog(e);
    }
#endif
}

void HuC6270::LogMissedVBlank()
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    if (m_chip_id != 0)
        return;

    u32 misses = m_huc6280->UpdateVBlankWatch();

    if (misses == 0)
        return;

    GG_Trace_Entry e = {};
    e.type = TRACE_VDC;
    e.vdc.event = TRACE_VDC_MISSED_VBLANK;
    e.vdc.chip = m_chip_id;
    e.vdc.value = m_huc6280->GetVBlankWatchAddress();
    e.vdc.raw = (m_huc6280->GetVBlankWatchAccess(true) ? 0x01 : 0x00) |
        (m_huc6280->GetVBlankWatchAccess(false) ? 0x02 : 0x00);
    e.vdc.param = misses;
    m_trace_logger->TraceLog(e);
#endif
}

void HuC6270::Reset()
{
    memset(m_register, 0, sizeof(m_register));
    if (m_safe_defaults)
    {
        m_register[HUC6270_REG_HSR] = 0x0202;
        m_register[HUC6270_REG_HDR] = 0x041F;
        m_register[HUC6270_REG_VSR] = 0x0F02;
        m_register[HUC6270_REG_VDR] = 0x00EF;
        m_register[HUC6270_REG_VCR] = 0x0004;
    }
    else
    {
        m_register[HUC6270_REG_HDR] = 0x1F;
        m_register[HUC6270_REG_VDR] = 239;
    }

    m_address_register = 0;
    m_status_register = 0;
    m_read_buffer = 0xFFFF;
    m_vram_openbus = 0;
    m_pending_memory_read = false;
    m_pending_memory_write = false;
    m_transfer_delay = 0;
    m_cpu_vram_cycles = 0;
    m_load_bg_start_clock = HUC6260_LINE_LENGTH;
    m_load_bg_end_clock = 0;
    m_hsync_start_clock = 0;
    m_allow_vram_access = false;
    m_trigger_sat_transfer = false;
    m_sat_transfer_pending = 0;
    m_vram_transfer_pending = 0;
    m_vram_transfer_src = 0;
    m_vram_transfer_dest = 0;
    m_hpos = 0;
    m_vpos = 0;
    m_bg_offset_y = 0;
    m_bg_counter_y = 0;
    m_bg_scroll_y_update_pending = false;
    m_bxr_written_before_latch = false;
    m_byr_lsb_write_clock = -1;
    m_increment_bg_counter_y = false;
    m_need_to_increment_raster_line = false;
    m_latch_clock_y = -1;
    m_latch_clock_x = -1;
    m_raster_line = 0;
    m_latched_bxr = 0;
    m_latched_hds = HUC6270_VAR_HDS;
    m_latched_hdw = HUC6270_VAR_HDW;
    m_latched_hde = HUC6270_VAR_HDE;
    m_latched_hsw = HUC6270_VAR_HSW;
    m_latched_vds = HUC6270_VAR_VDS;
    m_latched_vdw = HUC6270_VAR_VDW;
    m_latched_vcr = HUC6270_VAR_VCR;
    m_latched_vsw = HUC6270_VAR_VSW;
    m_latched_mwr = 0;
    m_latched_cr = HUC6270_VAR_CR;
    m_v_state = HuC6270_VERTICAL_STATE_VDS;
    m_h_state = HuC6270_HORIZONTAL_STATE_HDS;
    m_next_event = HuC6270_EVENT_NONE;
    m_lines_to_next_v_state = m_latched_vds + 2;
    m_clocks_to_next_h_state = 1;
    m_clocks_to_next_event = -1;
    m_vblank_triggered = false;
    m_active_line = false;
    m_burst_mode = false;
    m_line_buffer_index = 0;
    m_sprite_count = 0;
    m_sprite_overflow = false;

    memset(m_vram, 0, sizeof(m_vram));
    memset(m_sat, 0, sizeof(m_sat));
    memset(m_line_buffer, 0, sizeof(m_line_buffer));
    memset(m_line_buffer_sprites, 0, sizeof(m_line_buffer_sprites));
    memset(m_sprites, 0, sizeof(m_sprites));
}

void HuC6270::SetHSyncHigh()
{
    // Low to high
    EndOfLine();
    HUC6270_DEBUG("  HSW start (force)");
    m_h_state = HuC6270_HORIZONTAL_STATE_HSW;
    m_clocks_to_next_h_state = m_huc6260->GetClockDivider() == 3 ? 32 : 24;
    HSyncStart();
}

void HuC6270::SetVSyncLow()
{
    // High to low
    HUC6270_DEBUG("+++ VerticalSyncStart");

    m_latched_mwr = m_register[HUC6270_REG_MWR];
    m_latched_vds = HUC6270_VAR_VDS;
    m_latched_vdw = HUC6270_VAR_VDW;
    m_latched_vcr = HUC6270_VAR_VCR;
    m_latched_vsw = HUC6270_VAR_VSW;

    HUC6270_DEBUG(" >> VSW start (force)");
    m_v_state = HuC6270_VERTICAL_STATE_VSW;
    m_lines_to_next_v_state = m_latched_vsw + 1;

    m_increment_bg_counter_y = false;
}

u8 HuC6270::ReadRegister(u16 address)
{
    switch (address & 0x03)
    {
        // Status register
        case 0:
        {
            u8 ret = m_status_register & 0x3F;
            if (HasPendingCpuVramAccess())
                ret |= HUC6270_STATUS_BUSY;
            m_huc6202->AssertIRQ1(this, false);
            m_status_register = 0;
            UpdateCpuVramBusyStatus();
            return ret;
        }
        // Unused register
        case 1:
            return 0x00;
        // Data register (LSB)
        case 2:
        {
            if (m_pending_memory_read)
                WaitForVramAccess();

            return m_read_buffer & 0xFF;
        }
        // Data register (MSB)
        case 3:
        {
            if (m_pending_memory_read)
                WaitForVramAccess();

#if !defined(GG_DISABLE_DISASSEMBLER)
            m_huc6280->CheckMemoryBreakpoints(HuC6280::HuC6280_BREAKPOINT_TYPE_HUC6270_REGISTER, m_address_register, true);
#endif
            u8 ret = m_read_buffer >> 8;

            if (m_address_register == HUC6270_REG_VRR)
                QueueMemoryRead();

            return ret;
        }
        default:
        {
            Debug("[PC=%04X] HuC6270 invalid register read at %06X, reg=%d", m_huc6280->GetState()->PC->GetValue(), address, address & 0x03);
            return 0x00;
        }
    }
}

void HuC6270::WriteRegister(u16 address, u8 value)
{
    switch (address & 0x03)
    {
        // Address register
        case 0:
            m_address_register = value & 0x1F;
            break;
        // Data register (LSB)
        case 2:
        // Data register (MSB)
        case 3:
        {
#if !defined(GG_DISABLE_DISASSEMBLER)
            m_huc6280->CheckMemoryBreakpoints(HuC6280::HuC6280_BREAKPOINT_TYPE_HUC6270_REGISTER, m_address_register, false);
#endif

            bool msb = address & 0x01;

            if (m_address_register > 0x13)
            {
                Debug("[PC=%04X] HuC6270 INVALID write to data register (%s) %02X: %04X", m_huc6280->GetState()->PC->GetValue(), msb ? "MSB" : "LSB", value, m_address_register);
                return;
            }

            if ((m_address_register == HUC6270_REG_MAWR) || (m_address_register == HUC6270_REG_MARR) || (m_address_register == HUC6270_REG_VWR))
                WaitForVramAccess();

            if (msb)
                m_register[m_address_register] = (m_register[m_address_register] & 0x00FF) | (value << 8);
            else
                m_register[m_address_register] = (m_register[m_address_register] & 0xFF00) | value;

            m_register[m_address_register] &= k_register_mask[m_address_register];

            TraceVdcEvent(TRACE_VDC_REG_WRITE, value, msb);

            switch (m_address_register)
            {
                // 0x01
                case HUC6270_REG_MARR:
                    if (msb)
                        QueueMemoryRead();
                    break;
                // 0x02
                case HUC6270_REG_VWR:
                    if (msb)
                        QueueMemoryWrite();
                    break;
                // 0x07
                case HUC6270_REG_BXR:
                    if (m_latch_clock_x < 0)
                        m_bxr_written_before_latch = true;
                    if (CheckUpdateLatchTiming(m_latch_clock_x))
                        m_latched_bxr = m_register[HUC6270_REG_BXR];
                    //HUC6270_DEBUG("*** BXR Set");
                    break;
                // 0x08
                case HUC6270_REG_BYR:
                {
                    m_bg_scroll_y_update_pending = true;
                    if (CheckUpdateLatchTiming(m_latch_clock_y))
                    {
                        LatchScrollY();
                        m_byr_lsb_write_clock = -1;
                    }
                    else if (!msb && (m_latch_clock_y >= 0))
                    {
                        s32 elapsed = CurrentHClock() - m_latch_clock_y;
                        if (elapsed < 0)
                            elapsed += HUC6260_LINE_LENGTH;

                        m_byr_lsb_write_clock = (elapsed <= (m_huc6260->GetClockDivider() << 2)) ? CurrentHClock() : -1;
                    }
                    else if (msb && (m_byr_lsb_write_clock >= 0))
                    {
                        if (!m_bxr_written_before_latch && (m_h_state == HuC6270_HORIZONTAL_STATE_HSW))
                        {
                            s32 elapsed = CurrentHClock() - m_byr_lsb_write_clock;
                            if (elapsed < 0)
                                elapsed += HUC6260_LINE_LENGTH;

                            if (elapsed <= (m_huc6260->GetClockDivider() * 6))
                                RefreshScrollYCurrentLine();
                        }

                        m_byr_lsb_write_clock = -1;
                    }
                    //HUC6270_DEBUG("*** BYR Set");
                    break;
                }
                // 0x12
                case HUC6270_REG_LENR:
                    if (msb)
                    {
                        m_vram_transfer_pending = 4 * (m_register[HUC6270_REG_LENR] + 1);
                        m_vram_transfer_src = m_register[HUC6270_REG_SOUR];
                        m_vram_transfer_dest = m_register[HUC6270_REG_DESR];

                        TraceVdcEvent(TRACE_VDC_VRAM_DMA_START);
                    }
                    break;
                // 0x13
                case HUC6270_REG_DVSSR:
                    if (msb)
                        m_trigger_sat_transfer = true;
                    break;
            }
            break;
        }
        default:
            Debug("[PC=%04X] HuC6270 invalid write at %06X, value=%02X", m_huc6280->GetState()->PC->GetValue(), address, value);
            break;
    }
}

void HuC6270::EndOfLine()
{
    m_hpos = 0;
    m_vpos++;
    m_latch_clock_y = -1;
    m_latch_clock_x = -1;
    m_bxr_written_before_latch = false;
    m_byr_lsb_write_clock = -1;

    if(m_need_to_increment_raster_line)
        IncrementRasterLine();

    if (m_vpos == m_huc6260->GetTotalLines())
    {
        m_vpos = 0;
        m_latched_cr = (m_latched_cr & ~0x00C0) | (HUC6270_VAR_CR & 0x00C0);
        m_burst_mode = ((HUC6270_VAR_CR & 0x00C0) == 0);
    }

    m_active_line = (m_v_state == HuC6270_VERTICAL_STATE_VDW) && (m_vpos >= 14) && (m_vpos < 256);
}

void HuC6270::LineEvents()
{
    m_clocks_to_next_event--;

    if (m_clocks_to_next_event == 0)
    {
        switch (m_next_event)
        {
            case HuC6270_EVENT_BYR:
            {
                HUC6270_DEBUG("  [+] Event BYR\t");
                m_next_event = HuC6270_EVENT_BXR;
                m_clocks_to_next_event = 2;

                m_latch_clock_y = CurrentHClock();
                LatchScrollY();

                break;
            }
            case HuC6270_EVENT_BXR:
                HUC6270_DEBUG("  [+] Event BXR\t");
                m_next_event = HuC6270_EVENT_HDS;
                m_clocks_to_next_event = 6;

                m_latched_bxr = m_register[HUC6270_REG_BXR];
                m_latch_clock_x = CurrentHClock();

                break;
            case HuC6270_EVENT_HDS:
                HUC6270_DEBUG("  [+] Event HDS\t");
                m_next_event = HuC6270_EVENT_NONE;
                m_clocks_to_next_event = -1;

                if ((m_v_state != HuC6270_VERTICAL_STATE_VDW) && !m_vblank_triggered)
                {
                    m_vblank_triggered = true;
                    TraceMissedVBlank();
                    VBlankIRQ();
                }

                HUC6270_DEBUG("  [!] Sprite OF IRQ");
                if (m_sprite_overflow)
                {
                    m_sprite_overflow = false;
                    OverflowIRQ();
                }

                break;
            case HuC6270_EVENT_RCR:
                HUC6270_DEBUG("  [+] Event RCR\t");
                m_next_event = HuC6270_EVENT_NONE;
                m_clocks_to_next_event = -1;

                IncrementRasterLine();

                if ((m_v_state == HuC6270_VERTICAL_STATE_VDW) && !m_burst_mode)
                {
                    FetchSprites();
                    TraceSpriteBudget();
                }

                break;
            default:
                HUC6270_DEBUG("HuC6270 invalid event %d", m_next_event);
                break;
        }
    }
}

void HuC6270::HSyncStart()
{
    HUC6270_DEBUG("--- HorizSyncStart");

    m_hsync_start_clock = CurrentHClock();
    m_load_bg_start_clock = HUC6260_LINE_LENGTH;
    m_load_bg_end_clock = 0;
    m_allow_vram_access = false;

    m_latched_hds = HUC6270_VAR_HDS;
    m_latched_hdw = HUC6270_VAR_HDW;
    m_latched_hde = HUC6270_VAR_HDE;
    m_latched_hsw = HUC6270_VAR_HSW;

    m_next_event = HuC6270_EVENT_NONE;
    m_clocks_to_next_event = -1;

    s32 display_start = m_hpos + m_clocks_to_next_h_state + ((m_latched_hds + 1) << 3);

    if (DotsToClocks(display_start - 24) >= HUC6260_LINE_LENGTH)
        return;

    if (m_v_state == HuC6270_VERTICAL_STATE_VDW)
    {
        s32 display_width = (m_latched_hdw + 1) << 3;
        m_load_bg_start_clock = DotsToClocks(display_start - 16);
        m_load_bg_end_clock = m_load_bg_start_clock + DotsToClocks(display_width + 16);
        if (m_load_bg_end_clock > HUC6260_LINE_LENGTH)
            m_load_bg_end_clock = HUC6260_LINE_LENGTH;
    }

    s32 event_clocks;
    if (m_v_state == HuC6270_VERTICAL_STATE_VDW)
    {
        m_next_event = HuC6270_EVENT_BYR;
        event_clocks = k_huc6270_byr_latch_clocks;
    }
    else
    {
        m_next_event = HuC6270_EVENT_HDS;
        event_clocks = 26;
    }

    if(display_start - event_clocks <= m_hpos)
    {
        m_clocks_to_next_event = 1;
        LineEvents();
    }
    else
        m_clocks_to_next_event = display_start - event_clocks - m_hpos;
}

void HuC6270::IncrementRasterLine()
{
    m_raster_line++;
    m_need_to_increment_raster_line = false;
    m_increment_bg_counter_y = true;

    m_lines_to_next_v_state--;
    while (m_lines_to_next_v_state <= 0)
        NextVerticalState();

    RCRIRQ();
}

void HuC6270::SATTransfer()
{
    m_sat_transfer_pending--;

    if ((m_sat_transfer_pending & 3) == 0)
    {
        u16 satb = m_register[HUC6270_REG_DVSSR];
        int i = 255 - (m_sat_transfer_pending >> 2);
        m_sat[i] = ReadVRAM(satb + i);

        if (m_sat_transfer_pending == 0)
        {
            if (m_register[HUC6270_REG_DCR] & 0x01)
            {
                m_status_register |= HUC6270_STATUS_SAT_END;
                m_huc6202->AssertIRQ1(this, true);

                TraceVdcEvent(TRACE_VDC_SATB_DMA_END_IRQ);
            }
        }
    }
}

void HuC6270::VRAMTransfer()
{
    m_vram_transfer_pending--;

    if ((m_vram_transfer_pending & 3) == 0)
    {
        if (m_vram_transfer_dest < 0x8000)
        {
            m_vram[m_vram_transfer_dest] = ReadVRAM(m_vram_transfer_src);
        }
        else
        {
            Debug("[PC=%04X] HuC6270 ignoring write VRAM-DMA out of bounds: %04X", m_huc6280->GetState()->PC->GetValue(), m_register[HUC6270_REG_DESR]);
        }

        s8 src_increment = IS_SET_BIT(m_register[HUC6270_REG_DCR], 2) ? -1 : 1;
        s8 dest_increment = IS_SET_BIT(m_register[HUC6270_REG_DCR], 3) ? -1 : 1;
        m_vram_transfer_src += src_increment;
        m_vram_transfer_dest += dest_increment;
        m_register[HUC6270_REG_SOUR] = m_vram_transfer_src;
        m_register[HUC6270_REG_DESR] = m_vram_transfer_dest;
        m_register[HUC6270_REG_LENR] = static_cast<u16>((m_vram_transfer_pending >> 2) - 1);

        if (m_vram_transfer_pending == 0)
        {
            if (m_register[HUC6270_REG_DCR] & 0x02)
            {
                m_status_register |= HUC6270_STATUS_VRAM_END;
                m_huc6202->AssertIRQ1(this, true);

                TraceVdcEvent(TRACE_VDC_VRAM_DMA_END_IRQ);
            }
        }
    }
}

void HuC6270::NextVerticalState()
{
    m_v_state++;
    if (m_v_state == HuC6270_VERTICAL_STATE_COUNT)
        m_v_state = 0;

    switch (m_v_state)
    {
        case HuC6270_VERTICAL_STATE_VDS:
            HUC6270_DEBUG(" >> VDS start\t");
            m_lines_to_next_v_state = m_latched_vds + 2;
            break;
        case HuC6270_VERTICAL_STATE_VDW:
            m_lines_to_next_v_state = m_latched_vdw + 1;
            m_raster_line = 0;
            m_vblank_triggered = false;
            HUC6270_DEBUG(" >> VDW start\t");
            break;
        case HuC6270_VERTICAL_STATE_VCR:
            HUC6270_DEBUG(" >> VCR start\t");
            m_lines_to_next_v_state = m_latched_vcr;
            break;
        case HuC6270_VERTICAL_STATE_VSW:
            HUC6270_DEBUG(" >> VSW start\t");
            m_lines_to_next_v_state = m_latched_vsw + 1;
            m_latched_mwr = m_register[HUC6270_REG_MWR];
            m_latched_vds = HUC6270_VAR_VDS;
            m_latched_vdw = HUC6270_VAR_VDW;
            m_latched_vcr = HUC6270_VAR_VCR;
            m_latched_vsw = HUC6270_VAR_VSW;
            break;
    }
}

void HuC6270::NextHorizontalState()
{
    m_h_state++;
    if (m_h_state == HuC6270_HORIZONTAL_STATE_COUNT)
        m_h_state = 0;

    switch (m_h_state)
    {
        case HuC6270_HORIZONTAL_STATE_HDS:
            HUC6270_DEBUG("  HDS start\t");
            m_clocks_to_next_h_state = (m_latched_hds + 1) << 3;
            m_line_buffer_index = 0;
            if (!m_burst_mode)
                m_latched_cr = HUC6270_VAR_CR;
            break;
        case HuC6270_HORIZONTAL_STATE_HDW:
            HUC6270_DEBUG("  HDW start\t");
            m_clocks_to_next_h_state = (m_latched_hdw + 1) << 3;
            m_next_event = HuC6270_EVENT_RCR;
            m_clocks_to_next_event = ((m_latched_hdw - 1) << 3) + 2;
            m_need_to_increment_raster_line = true;
            if (m_clocks_to_next_event <= 0)
            {
                m_clocks_to_next_event = 1;
                LineEvents();
            }
            if (m_active_line)
                RenderLine();
            break;
        case HuC6270_HORIZONTAL_STATE_HDE:
            HUC6270_DEBUG("  HDE start\t");
            m_clocks_to_next_h_state = (m_latched_hde + 1) << 3;
            break;
        case HuC6270_HORIZONTAL_STATE_HSW:
            HUC6270_DEBUG("  HSW start\t");
            m_clocks_to_next_h_state = (m_latched_hsw + 1) << 3;
            HSyncStart();
            break;
    }
}

void HuC6270::VBlankIRQ()
{
    HUC6270_DEBUG("  [!] VBLANK IRQ");
    if (m_register[HUC6270_REG_CR] & HUC6270_CONTROL_VBLANK)
    {
        m_status_register |= HUC6270_STATUS_VBLANK;
        m_huc6202->AssertIRQ1(this, true);
        if(IsValidPointer(m_input_pump_fn))
            m_input_pump_fn();

        TraceVdcEvent(TRACE_VDC_VBLANK_IRQ);
    }

    if (m_trigger_sat_transfer || (m_register[HUC6270_REG_DCR] & 0x10))
    {
        m_trigger_sat_transfer = false;
        m_sat_transfer_pending = 1024;

        TraceVdcEvent(TRACE_VDC_SATB_DMA_START);
    }
}

void HuC6270::RenderLine()
{
    int width = MIN(1024, (m_latched_hdw + 1) << 3);

    if((m_latched_cr & 0x80) == 0)
        for (int i = 0; i < width; i++)
            m_line_buffer[i] = 0x100;

    if (!m_burst_mode)
    {
        if((m_latched_cr & 0x80) != 0)
            RenderBackground(width);

        if((m_latched_cr & 0x40) != 0)
            RenderSprites(width);
    }
}

void HuC6270::RenderBackground(int width)
{
    int screen_reg = (m_latched_mwr >> 4) & 0x07;
    int screen_size_x = k_huc6270_screen_size_x[screen_reg];
    int screen_size_x_mask = k_huc6270_screen_size_x_pixels_mask[screen_reg];
    int bg_y = m_bg_offset_y;
    bg_y &= k_huc6270_screen_size_y_pixels_mask[screen_reg];
    int tile_y = (bg_y & 7);
    int bat_offset = (bg_y >> 3) * screen_size_x;
    int bg_x = m_latched_bxr & screen_size_x_mask;
    int i = 0;

    while (i < width)
    {
        int tile_col = bg_x >> 3;
        int bat_address = bat_offset + tile_col;
        assert(bat_address < HUC6270_VRAM_SIZE);

        u16 bat_entry = m_vram[bat_address];
        int tile_data = (bat_entry & 0x07FF) << 4;
        int line_start_a = tile_data + tile_y;
        int line_start_b = line_start_a + 8;
        assert(line_start_b < HUC6270_VRAM_SIZE);

        u16 word_a = m_vram[line_start_a];
        u16 word_b = m_vram[line_start_b];
        m_vram_openbus = word_b;
        u8 byte1 = word_a & 0xFF;
        u8 byte2 = word_a >> 8;
        u8 byte3 = word_b & 0xFF;
        u8 byte4 = word_b >> 8;

        u16 color_table = (bat_entry >> 12) << 4;
        u16 pixels[8];

        for (int x = 0; x < 8; x++)
        {
            u16 color = ((byte1 >> (7 - x)) & 0x01) |
                    (((byte2 >> (7 - x)) & 0x01) << 1) |
                    (((byte3 >> (7 - x)) & 0x01) << 2) |
                    (((byte4 >> (7 - x)) & 0x01) << 3);
            pixels[x] = color_table | color;
        }

        int offset = bg_x & 7;
        int count = MIN(8 - offset, width - i);
        if (count == 8)
            memcpy(m_line_buffer + i, pixels, sizeof(pixels));
        else
            memcpy(m_line_buffer + i, pixels + offset, count * sizeof(u16));
        i += count;

        bg_x = (bg_x + count) & screen_size_x_mask;
    }
}

void HuC6270::RenderSprites(int width)
{
    static const u16 sprite_rendered_flag = 0x0200;
    static const u16 sprite_limit_flag = 0x0400;

    if (m_sprite_count == 0)
        return;

    int min_x = width;
    int max_x = -1;

    for (int i = 0; i < m_sprite_count; i++)
    {
        int left = m_sprites[i].x - 0x20;
        int right = left + 15;

        if (right < 0 || left >= width)
            continue;

        min_x = MIN(min_x, MAX(left, 0));
        max_x = MAX(max_x, MIN(right, width - 1));
    }

    if (max_x < min_x)
        return;

    for (int i = min_x; i <= max_x; i++)
    {
        m_line_buffer_sprites[i] = 0;
    }

    for(int i = (m_sprite_count - 1) ; i >= 0; i--)
    {
        bool in_sprite_limit = (i < 16);
        int pos = m_sprites[i].x - 0x20;

        if ((pos + 15) < 0 || pos >= width)
            continue;

        bool priority = (m_sprites[i].flags & 0x0080);
        u16 plane1 = m_sprites[i].data[0];
        u16 plane2 = m_sprites[i].data[1];
        u16 plane3 = m_sprites[i].data[2];
        u16 plane4 = m_sprites[i].data[3];
        u16 opaque = plane1 | plane2 | plane3 | plane4;

        if (opaque == 0)
            continue;

        int start_x = (pos < 0) ? -pos : 0;
        int end_x = (pos + 15 >= width) ? (width - pos - 1) : 15;

        for(int x = start_x; x <= end_x; x++)
        {
            int pixel_x;
            if (m_sprites[i].flags & 0x0800)
                pixel_x = x & 0xF;
            else
                pixel_x = 15 - (x & 0xF);

            if ((opaque >> pixel_x) & 0x01)
            {
                u16 pixel = ((plane1 >> pixel_x) & 0x01) | (((plane2 >> pixel_x) & 0x01) << 1) |
                    (((plane3 >> pixel_x) & 0x01) << 2) | (((plane4 >> pixel_x) & 0x01) << 3);
                int x_in_screen = pos + x;

                if ((m_sprites[i].index == 0) && (m_line_buffer_sprites[x_in_screen] & 0x0F) &&
                    (!m_no_sprite_limit || (m_line_buffer_sprites[x_in_screen] & sprite_limit_flag)))
                    SpriteCollisionIRQ();

                if (!priority && (m_line_buffer[x_in_screen] & 0x0F))
                    pixel |= 0x100;
                else
                    pixel |= m_sprites[i].palette | 0x100 | sprite_rendered_flag;

                if (m_no_sprite_limit && in_sprite_limit)
                    pixel |= sprite_limit_flag;

                m_line_buffer_sprites[x_in_screen] = pixel;
            }
        }
    }

    for (int i = min_x; i <= max_x; i++)
    {
        if(m_line_buffer_sprites[i] & sprite_rendered_flag)
            m_line_buffer[i] = m_line_buffer_sprites[i] & ~(sprite_rendered_flag | sprite_limit_flag);
    }
}

void HuC6270::FetchSprites()
{
    m_sprite_count = 0;
    bool mode1 = ((m_latched_mwr >> 2) & 0x03) == 1;

    for (int i = 0; i < HUC6270_SPRITES; i++)
    {
        int sprite_offset = i << 2;
        u16 sat0 = m_sat[sprite_offset + 0];
        u16 sat3 = m_sat[sprite_offset + 3];
        int sprite_y = (sat0 & 0x3FF) - 64;
        u16 flags = sat3;
        int cgy = (flags >> 12) & 0x03;
        u16 height = k_huc6270_sprite_height[cgy];

        if ((sprite_y <= m_raster_line) && ((sprite_y + height) > m_raster_line))
        {
            int y = m_raster_line - sprite_y;
            if (y >= height)
                continue;

            if (m_sprite_count >= 16)
            {
                m_sprite_overflow = true;
                if (!m_no_sprite_limit)
                    break;
            }

            u16 sat1 = m_sat[sprite_offset + 1];
            u16 sat2 = m_sat[sprite_offset + 2];
            int mode1_offset = mode1 ? (sat2 & 1) << 5 : 0;
            int cgx = (flags >> 8) & 0x01;
            u16 width = k_huc6270_sprite_width[cgx];
            u16 sprite_x = sat1 & 0x3FF;
            u16 pattern = (sat2 >> 1) & 0x3FF;
            pattern &= k_huc6270_sprite_mask_width[cgx];
            pattern &= k_huc6270_sprite_mask_height[cgy];
            u16 sprite_address = pattern << 6;
            u8 palette = (flags & 0x0F) << 4;
            bool x_flip = (flags & 0x0800);

            if(flags & 0x8000)
                y = height - 1 - y;

            int tile_y = y >> 4;
            int tile_line_offset = tile_y * 128;
            int offset_y = y & 0xF;

            if (width == 16)
            {
                u16 line_start = sprite_address + tile_line_offset + offset_y + mode1_offset;
                m_sprites[m_sprite_count].index = i;
                m_sprites[m_sprite_count].x = sprite_x;
                m_sprites[m_sprite_count].flags = flags;
                m_sprites[m_sprite_count].palette = palette;
                m_sprites[m_sprite_count].data[0] = ReadVRAM(line_start + 0);
                m_sprites[m_sprite_count].data[1] = ReadVRAM(line_start + 16);
                m_sprites[m_sprite_count].data[2] = mode1 ? 0 : ReadVRAM(line_start + 32);
                m_sprites[m_sprite_count].data[3] = mode1 ? 0 : ReadVRAM(line_start + 48);
            }
            else
            {
                u16 line_start = sprite_address + tile_line_offset + offset_y + mode1_offset;
                u16 line = line_start + (x_flip ? 64 : 0);
                m_sprites[m_sprite_count].index = i;
                m_sprites[m_sprite_count].x = sprite_x;
                m_sprites[m_sprite_count].flags = flags;
                m_sprites[m_sprite_count].palette = palette;
                m_sprites[m_sprite_count].data[0] = ReadVRAM(line + 0);
                m_sprites[m_sprite_count].data[1] = ReadVRAM(line + 16);
                m_sprites[m_sprite_count].data[2] = mode1 ? 0 : ReadVRAM(line + 32);
                m_sprites[m_sprite_count].data[3] = mode1 ? 0 : ReadVRAM(line + 48);

                m_sprite_count++;

                if (m_sprite_count >= 16)
                {
                    m_sprite_overflow = true;
                    if (!m_no_sprite_limit)
                        break;
                }

                line = line_start + (x_flip ? 0 : 64);
                m_sprites[m_sprite_count].index = i;
                m_sprites[m_sprite_count].x = sprite_x + 16;
                m_sprites[m_sprite_count].flags = flags;
                m_sprites[m_sprite_count].palette = palette;
                m_sprites[m_sprite_count].data[0] = ReadVRAM(line + 0);
                m_sprites[m_sprite_count].data[1] = ReadVRAM(line + 16);
                m_sprites[m_sprite_count].data[2] = mode1 ? 0 : ReadVRAM(line + 32);
                m_sprites[m_sprite_count].data[3] = mode1 ? 0 : ReadVRAM(line + 48);
            }

            m_sprite_count++;
        }
    }
}

void HuC6270::SaveState(std::ostream& stream)
{
    using namespace std;
    UpdateCpuVramBusyStatus();
    stream.write(reinterpret_cast<const char*> (m_vram), sizeof(u16) * HUC6270_VRAM_SIZE);
    stream.write(reinterpret_cast<const char*> (&m_address_register), sizeof(m_address_register));
    stream.write(reinterpret_cast<const char*> (&m_status_register), sizeof(m_status_register));
    stream.write(reinterpret_cast<const char*> (m_register), sizeof(m_register));
    stream.write(reinterpret_cast<const char*> (m_sat), sizeof(u16) * HUC6270_SAT_SIZE);
    stream.write(reinterpret_cast<const char*> (&m_read_buffer), sizeof(m_read_buffer));
    stream.write(reinterpret_cast<const char*> (&m_vram_openbus), sizeof(m_vram_openbus));
    stream.write(reinterpret_cast<const char*> (&m_pending_memory_read), sizeof(m_pending_memory_read));
    stream.write(reinterpret_cast<const char*> (&m_pending_memory_write), sizeof(m_pending_memory_write));
    stream.write(reinterpret_cast<const char*> (&m_transfer_delay), sizeof(m_transfer_delay));
    stream.write(reinterpret_cast<const char*> (&m_trigger_sat_transfer), sizeof(m_trigger_sat_transfer));
    stream.write(reinterpret_cast<const char*> (&m_sat_transfer_pending), sizeof(m_sat_transfer_pending));
    stream.write(reinterpret_cast<const char*> (&m_vram_transfer_pending), sizeof(m_vram_transfer_pending));
    stream.write(reinterpret_cast<const char*> (&m_vram_transfer_src), sizeof(m_vram_transfer_src));
    stream.write(reinterpret_cast<const char*> (&m_vram_transfer_dest), sizeof(m_vram_transfer_dest));
    stream.write(reinterpret_cast<const char*> (&m_hpos), sizeof(m_hpos));
    stream.write(reinterpret_cast<const char*> (&m_vpos), sizeof(m_vpos));
    stream.write(reinterpret_cast<const char*> (&m_bg_offset_y), sizeof(m_bg_offset_y));
    stream.write(reinterpret_cast<const char*> (&m_bg_counter_y), sizeof(m_bg_counter_y));
    stream.write(reinterpret_cast<const char*> (&m_increment_bg_counter_y), sizeof(m_increment_bg_counter_y));
    stream.write(reinterpret_cast<const char*> (&m_need_to_increment_raster_line), sizeof(m_need_to_increment_raster_line));
    stream.write(reinterpret_cast<const char*> (&m_raster_line), sizeof(m_raster_line));
    stream.write(reinterpret_cast<const char*> (&m_latched_bxr), sizeof(m_latched_bxr));
    stream.write(reinterpret_cast<const char*> (&m_latched_hds), sizeof(m_latched_hds));
    stream.write(reinterpret_cast<const char*> (&m_latched_hdw), sizeof(m_latched_hdw));
    stream.write(reinterpret_cast<const char*> (&m_latched_hde), sizeof(m_latched_hde));
    stream.write(reinterpret_cast<const char*> (&m_latched_hsw), sizeof(m_latched_hsw));
    stream.write(reinterpret_cast<const char*> (&m_latched_vds), sizeof(m_latched_vds));
    stream.write(reinterpret_cast<const char*> (&m_latched_vdw), sizeof(m_latched_vdw));
    stream.write(reinterpret_cast<const char*> (&m_latched_vcr), sizeof(m_latched_vcr));
    stream.write(reinterpret_cast<const char*> (&m_latched_vsw), sizeof(m_latched_vsw));
    stream.write(reinterpret_cast<const char*> (&m_latched_mwr), sizeof(m_latched_mwr));
    stream.write(reinterpret_cast<const char*> (&m_latched_cr), sizeof(m_latched_cr));
    stream.write(reinterpret_cast<const char*> (&m_v_state), sizeof(m_v_state));
    stream.write(reinterpret_cast<const char*> (&m_h_state), sizeof(m_h_state));
    stream.write(reinterpret_cast<const char*> (&m_lines_to_next_v_state), sizeof(m_lines_to_next_v_state));
    stream.write(reinterpret_cast<const char*> (&m_clocks_to_next_h_state), sizeof(m_clocks_to_next_h_state));
    stream.write(reinterpret_cast<const char*> (&m_vblank_triggered), sizeof(m_vblank_triggered));
    stream.write(reinterpret_cast<const char*> (&m_active_line), sizeof(m_active_line));
    stream.write(reinterpret_cast<const char*> (&m_burst_mode), sizeof(m_burst_mode));
    stream.write(reinterpret_cast<const char*> (&m_line_buffer_index), sizeof(m_line_buffer_index));
    stream.write(reinterpret_cast<const char*> (&m_no_sprite_limit), sizeof(m_no_sprite_limit));
    stream.write(reinterpret_cast<const char*> (&m_sprite_count), sizeof(m_sprite_count));
    stream.write(reinterpret_cast<const char*> (&m_sprite_overflow), sizeof(m_sprite_overflow));
    stream.write(reinterpret_cast<const char*> (&m_next_event), sizeof(m_next_event));
    stream.write(reinterpret_cast<const char*> (&m_clocks_to_next_event), sizeof(m_clocks_to_next_event));

    for (int i = 0; i < (HUC6270_MAX_SPRITE_HEIGHT * 2); i++)
    {
        stream.write(reinterpret_cast<const char*> (&m_sprites[i].index), sizeof(m_sprites[i].index));
        stream.write(reinterpret_cast<const char*> (&m_sprites[i].x), sizeof(m_sprites[i].x));
        stream.write(reinterpret_cast<const char*> (&m_sprites[i].flags), sizeof(m_sprites[i].flags));
        stream.write(reinterpret_cast<const char*> (&m_sprites[i].palette), sizeof(m_sprites[i].palette));
        stream.write(reinterpret_cast<const char*> (m_sprites[i].data), sizeof(m_sprites[i].data));
    }

    stream.write(reinterpret_cast<const char*> (&m_load_bg_start_clock), sizeof(m_load_bg_start_clock));
    stream.write(reinterpret_cast<const char*> (&m_load_bg_end_clock), sizeof(m_load_bg_end_clock));
    stream.write(reinterpret_cast<const char*> (&m_hsync_start_clock), sizeof(m_hsync_start_clock));
    stream.write(reinterpret_cast<const char*> (&m_allow_vram_access), sizeof(m_allow_vram_access));
    stream.write(reinterpret_cast<const char*> (&m_bg_scroll_y_update_pending), sizeof(m_bg_scroll_y_update_pending));
    stream.write(reinterpret_cast<const char*> (&m_latch_clock_y), sizeof(m_latch_clock_y));
    stream.write(reinterpret_cast<const char*> (&m_latch_clock_x), sizeof(m_latch_clock_x));
    stream.write(reinterpret_cast<const char*> (&m_bxr_written_before_latch), sizeof(m_bxr_written_before_latch));
    stream.write(reinterpret_cast<const char*> (&m_byr_lsb_write_clock), sizeof(m_byr_lsb_write_clock));
    stream.write(reinterpret_cast<const char*> (&m_cpu_vram_cycles), sizeof(m_cpu_vram_cycles));
}

void HuC6270::LoadState(std::istream& stream, int version)
{
    using namespace std;
    stream.read(reinterpret_cast<char*> (m_vram), sizeof(u16) * HUC6270_VRAM_SIZE);
    stream.read(reinterpret_cast<char*> (&m_address_register), sizeof(m_address_register));
    stream.read(reinterpret_cast<char*> (&m_status_register), sizeof(m_status_register));
    stream.read(reinterpret_cast<char*> (m_register), sizeof(m_register));
    stream.read(reinterpret_cast<char*> (m_sat), sizeof(u16) * HUC6270_SAT_SIZE);
    stream.read(reinterpret_cast<char*> (&m_read_buffer), sizeof(m_read_buffer));
    stream.read(reinterpret_cast<char*> (&m_vram_openbus), sizeof(m_vram_openbus));
    if (version >= 29)
    {
        stream.read(reinterpret_cast<char*> (&m_pending_memory_read), sizeof(m_pending_memory_read));
        stream.read(reinterpret_cast<char*> (&m_pending_memory_write), sizeof(m_pending_memory_write));
        stream.read(reinterpret_cast<char*> (&m_transfer_delay), sizeof(m_transfer_delay));
    }
    else
    {
        m_pending_memory_read = false;
        m_pending_memory_write = false;
        m_transfer_delay = 0;
    }
    UpdateCpuVramBusyStatus();
    stream.read(reinterpret_cast<char*> (&m_trigger_sat_transfer), sizeof(m_trigger_sat_transfer));
    stream.read(reinterpret_cast<char*> (&m_sat_transfer_pending), sizeof(m_sat_transfer_pending));
    m_sat_transfer_pending = MIN(m_sat_transfer_pending, 1024);
    stream.read(reinterpret_cast<char*> (&m_vram_transfer_pending), sizeof(m_vram_transfer_pending));
    stream.read(reinterpret_cast<char*> (&m_vram_transfer_src), sizeof(m_vram_transfer_src));
    stream.read(reinterpret_cast<char*> (&m_vram_transfer_dest), sizeof(m_vram_transfer_dest));
    stream.read(reinterpret_cast<char*> (&m_hpos), sizeof(m_hpos));
    stream.read(reinterpret_cast<char*> (&m_vpos), sizeof(m_vpos));
    stream.read(reinterpret_cast<char*> (&m_bg_offset_y), sizeof(m_bg_offset_y));
    stream.read(reinterpret_cast<char*> (&m_bg_counter_y), sizeof(m_bg_counter_y));
    stream.read(reinterpret_cast<char*> (&m_increment_bg_counter_y), sizeof(m_increment_bg_counter_y));
    stream.read(reinterpret_cast<char*> (&m_need_to_increment_raster_line), sizeof(m_need_to_increment_raster_line));
    stream.read(reinterpret_cast<char*> (&m_raster_line), sizeof(m_raster_line));
    stream.read(reinterpret_cast<char*> (&m_latched_bxr), sizeof(m_latched_bxr));
    stream.read(reinterpret_cast<char*> (&m_latched_hds), sizeof(m_latched_hds));
    stream.read(reinterpret_cast<char*> (&m_latched_hdw), sizeof(m_latched_hdw));
    stream.read(reinterpret_cast<char*> (&m_latched_hde), sizeof(m_latched_hde));
    stream.read(reinterpret_cast<char*> (&m_latched_hsw), sizeof(m_latched_hsw));
    stream.read(reinterpret_cast<char*> (&m_latched_vds), sizeof(m_latched_vds));
    stream.read(reinterpret_cast<char*> (&m_latched_vdw), sizeof(m_latched_vdw));
    stream.read(reinterpret_cast<char*> (&m_latched_vcr), sizeof(m_latched_vcr));
    stream.read(reinterpret_cast<char*> (&m_latched_vsw), sizeof(m_latched_vsw));
    stream.read(reinterpret_cast<char*> (&m_latched_mwr), sizeof(m_latched_mwr));
    stream.read(reinterpret_cast<char*> (&m_latched_cr), sizeof(m_latched_cr));
    stream.read(reinterpret_cast<char*> (&m_v_state), sizeof(m_v_state));
    stream.read(reinterpret_cast<char*> (&m_h_state), sizeof(m_h_state));
    stream.read(reinterpret_cast<char*> (&m_lines_to_next_v_state), sizeof(m_lines_to_next_v_state));
    stream.read(reinterpret_cast<char*> (&m_clocks_to_next_h_state), sizeof(m_clocks_to_next_h_state));
    stream.read(reinterpret_cast<char*> (&m_vblank_triggered), sizeof(m_vblank_triggered));
    stream.read(reinterpret_cast<char*> (&m_active_line), sizeof(m_active_line));
    stream.read(reinterpret_cast<char*> (&m_burst_mode), sizeof(m_burst_mode));
    stream.read(reinterpret_cast<char*> (&m_line_buffer_index), sizeof(m_line_buffer_index));
    stream.read(reinterpret_cast<char*> (&m_no_sprite_limit), sizeof(m_no_sprite_limit));
    stream.read(reinterpret_cast<char*> (&m_sprite_count), sizeof(m_sprite_count));
    stream.read(reinterpret_cast<char*> (&m_sprite_overflow), sizeof(m_sprite_overflow));
    stream.read(reinterpret_cast<char*> (&m_next_event), sizeof(m_next_event));
    stream.read(reinterpret_cast<char*> (&m_clocks_to_next_event), sizeof(m_clocks_to_next_event));

    for (int i = 0; i < (HUC6270_MAX_SPRITE_HEIGHT * 2); i++)
    {
        stream.read(reinterpret_cast<char*> (&m_sprites[i].index), sizeof(m_sprites[i].index));
        stream.read(reinterpret_cast<char*> (&m_sprites[i].x), sizeof(m_sprites[i].x));
        stream.read(reinterpret_cast<char*> (&m_sprites[i].flags), sizeof(m_sprites[i].flags));
        stream.read(reinterpret_cast<char*> (&m_sprites[i].palette), sizeof(m_sprites[i].palette));
        stream.read(reinterpret_cast<char*> (m_sprites[i].data), sizeof(m_sprites[i].data));
    }

    if (version >= 29)
    {
        stream.read(reinterpret_cast<char*> (&m_load_bg_start_clock), sizeof(m_load_bg_start_clock));
        stream.read(reinterpret_cast<char*> (&m_load_bg_end_clock), sizeof(m_load_bg_end_clock));
        stream.read(reinterpret_cast<char*> (&m_hsync_start_clock), sizeof(m_hsync_start_clock));
        stream.read(reinterpret_cast<char*> (&m_allow_vram_access), sizeof(m_allow_vram_access));
    }
    else
    {
        m_load_bg_start_clock = HUC6260_LINE_LENGTH;
        m_load_bg_end_clock = 0;
        m_hsync_start_clock = CurrentHClock();
        m_allow_vram_access = false;
    }

    if (version >= 30)
    {
        stream.read(reinterpret_cast<char*> (&m_bg_scroll_y_update_pending), sizeof(m_bg_scroll_y_update_pending));
        stream.read(reinterpret_cast<char*> (&m_latch_clock_y), sizeof(m_latch_clock_y));
        stream.read(reinterpret_cast<char*> (&m_latch_clock_x), sizeof(m_latch_clock_x));
        if (version >= 31)
        {
            stream.read(reinterpret_cast<char*> (&m_bxr_written_before_latch), sizeof(m_bxr_written_before_latch));
            stream.read(reinterpret_cast<char*> (&m_byr_lsb_write_clock), sizeof(m_byr_lsb_write_clock));
        }
        else
        {
            m_bxr_written_before_latch = false;
            m_byr_lsb_write_clock = -1;
        }
    }
    else
    {
        m_bg_scroll_y_update_pending = false;
        m_latch_clock_y = -1;
        m_latch_clock_x = -1;
        m_bxr_written_before_latch = false;
        m_byr_lsb_write_clock = -1;
    }

    if (version >= 44)
        stream.read(reinterpret_cast<char*> (&m_cpu_vram_cycles), sizeof(m_cpu_vram_cycles));
    else
        m_cpu_vram_cycles = 0;
}
