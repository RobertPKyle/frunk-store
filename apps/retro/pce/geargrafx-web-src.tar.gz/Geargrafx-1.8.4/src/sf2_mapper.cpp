/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include "sf2_mapper.h"
#include "media.h"
#include "memory.h"

SF2Mapper::SF2Mapper(Media* media, Memory* memory) : Mapper(media, memory)
{
    InitPointer(m_trace_logger);
    Reset();
}

SF2Mapper::~SF2Mapper()
{
}

void SF2Mapper::SetTraceLogger(TraceLogger* trace_logger)
{
    m_trace_logger = trace_logger;
}

void SF2Mapper::LogSF2MapperEvent(u16 address)
{
#if !defined(GG_DISABLE_DISASSEMBLER)
    u8 new_bank = (u8)(address & 0x0F);
    GG_Trace_Entry entry = {};
    entry.type = TRACE_SYSTEM;
    entry.system.event = TRACE_SYSTEM_SF2_MAPPER;
    entry.system.address = address;
    entry.system.old_value = (u8)m_bank;
    entry.system.new_value = new_bank;
    entry.system.physical = 0x80000U + (u32)ComputeBankAddress(new_bank);
    m_trace_logger->TraceLog(entry);
#else
    UNUSED(address);
#endif
}

u8 SF2Mapper::Read(u8 bank, u16 address)
{
    if (bank < 0x40)
    {
        u8** rom_map = m_media->GetROMMap();
        return rom_map[bank][address];
    }
    else
    {
        u8* rom = m_media->GetROM();
        int bank_address = (bank * 0x2000) + m_bank_address;
        return rom[bank_address + address];
    }
}

u8 SF2Mapper::Peek(u8 bank, u16 address)
{
    return SF2Mapper::Read(bank, address);
}

bool SF2Mapper::GetROMPhysicalAddress(u8 bank, u16 address, u32& rom_address)
{
    int rom_size = m_media->GetROMSize();

    if (rom_size <= 0)
        return false;

    u32 phys = 0;
    if (bank < 0x40)
    {
        u32* rom_bank_offset = m_media->GetROMBankOffset();

        if (!IsValidPointer(rom_bank_offset))
            return false;

        phys = rom_bank_offset[bank] + address;
    }
    else
    {
        phys = ((u32)bank * 0x2000) + (u32)m_bank_address + address;
    }

    if (phys >= (u32)rom_size)
        return false;

    rom_address = phys;
    return true;
}

void SF2Mapper::Write(u8 bank, u16 address, u8 value)
{
    if ((bank == 0x00) && ((address & 0x1FF0) == 0x1FF0))
    {
        UNUSED(value);
        TraceSF2MapperEvent(address);
        m_bank = address & 0x0F;
        m_bank_address = ComputeBankAddress(m_bank);
    }
    else
    {
        Debug("SF2Mapper: Attempted write to ROM at bank=%02X, value=%02X, address=%04X", bank, value, address);
    }
}

void SF2Mapper::Reset()
{
    m_bank = 0;
    m_bank_address = 0;
}

void SF2Mapper::SaveState(std::ostream& stream)
{
    using namespace std;
    stream.write(reinterpret_cast<const char*> (&m_bank), sizeof(m_bank));
    stream.write(reinterpret_cast<const char*> (&m_bank_address), sizeof(m_bank_address));

}

void SF2Mapper::LoadState(std::istream& stream)
{
    using namespace std;
    stream.read(reinterpret_cast<char*> (&m_bank), sizeof(m_bank));
    stream.read(reinterpret_cast<char*> (&m_bank_address), sizeof(m_bank_address));
    m_bank &= 0x0F;
    m_bank_address = ComputeBankAddress(m_bank);
}
