/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include "cdrom_chd_image.h"
#include "cdrom_chd_file_adapter.h"
#include "crc.h"

CdRomChdImage::CdRomChdImage() : CdRomImage()
{
    InitPointer(m_chd_file);
    InitPointer(m_file_adapter);
    InitPointer(m_hunk_cache);
}

CdRomChdImage::~CdRomChdImage()
{
    chd_close(m_chd_file);
    SafeDelete(m_file_adapter);
    DestroyHunkCache();
}

void CdRomChdImage::Init()
{
    CdRomImage::Init();
    Reset();
}

void CdRomChdImage::Reset()
{
    CdRomImage::Reset();

    DestroyHunkCache();

    m_hunk_bytes = 0;
    m_hunk_count = 0;
    m_sectors_per_hunk = 0;

    chd_close(m_chd_file);
    InitPointer(m_chd_file);
    SafeDelete(m_file_adapter);
}

bool CdRomChdImage::LoadFromFile(const char* path, bool preload)
{
    using namespace std;

    Log("Loading CHD from %s...", path);

    if (!IsValidPointer(path))
    {
        Error("Invalid path %s", path);
        m_ready = false;
        return m_ready;
    }

    Reset();
    GatherPaths(path);

    if (strcmp(m_file_extension, "chd") != 0)
    {
        Error("Invalid file extension %s. Expected .chd", m_file_extension);
        m_ready = false;
        return m_ready;
    }

    m_file_adapter = new CdRomChdFileAdapter;
    chd_error err = m_file_adapter->Open(path) ? chd_open_core_file(m_file_adapter->GetCoreFile(), CHD_OPEN_READ, NULL, &m_chd_file) : CHDERR_FILE_NOT_FOUND;

    if (err == CHDERR_NONE)
    {
        const chd_header* header = chd_get_header(m_chd_file);

        if (IsValidPointer(header))
        {
            Debug("CHD Header: Version: %d, Hunk Size: %d, Total Hunks: %d, Flags: %04X",
                    header->version, header->hunkbytes, header->totalhunks, header->flags);

            m_hunk_bytes = header->hunkbytes;
            m_hunk_count = header->totalhunks;
            m_sectors_per_hunk = m_hunk_bytes / (2352 + 96);

            if (m_hunk_bytes == 0 || m_hunk_count == 0)
            {
                Error("Invalid CHD header - hunk size or count is zero");
                chd_close(m_chd_file);
                InitPointer(m_chd_file);
                m_ready = false;
            }
            else if (m_hunk_count > 500000)
            {
                Error("Invalid CHD header - hunk count %u exceeds maximum", m_hunk_count);
                chd_close(m_chd_file);
                InitPointer(m_chd_file);
                m_ready = false;
            }
            else if (m_hunk_bytes % (2352 + 96) != 0)
            {
                Error("Invalid CHD hunk size %d, must be a multiple of 2448 (2352 + 96)", m_hunk_bytes);
                chd_close(m_chd_file);
                InitPointer(m_chd_file);
                m_ready = false;
            }
            else
            {
                if (InitHunkCache())
                {
                    m_ready = ReadTOC();

                    if (preload && m_ready)
                        m_ready = PreloadDisc();

                    CalculateCRC();
                }
                else
                {
                    m_ready = false;
                }
            }
        }
        else
        {
            Error("Failed to get CHD header for %s", path);
            chd_close(m_chd_file);
            InitPointer(m_chd_file);
            m_ready = false;
        }
    }
    else
    {
        Error("Unable to open CHD file %s.", path);
        Error("CHD: %d, %s", err, chd_error_string(err));
        chd_close(m_chd_file);
        InitPointer(m_chd_file);
        m_ready = false;
    }

    if (!m_ready)
        Reset();

    return m_ready;
}

bool CdRomChdImage::ReadSector(u32 lba, u8* buffer)
{
    if (!m_ready || buffer == NULL)
    {
        Error("ReadSector failed - Media not ready or buffer is NULL");
        return false;
    }

    s32 track_index = FindTrackFromLBA(lba, false);
    if (track_index < 0)
    {
        Error("ReadSector failed - LBA %d not found in any track", lba);
        return false;
    }

    const Track& track = m_toc.tracks[(size_t)track_index];
    u32 sector_index = (lba - track.start_lba) + (u32)track.file_offset;
    u32 hunk_index  = sector_index / m_sectors_per_hunk;
    u32 hunk_offset = sector_index % m_sectors_per_hunk;
    u32 byte_offset_in_hunk = hunk_offset * (2352 + 96);

    if (!LoadHunk(hunk_index))
        return false;

    u32 sector_offset = 0;

    if (track.sector_size == 2352)
        sector_offset = 16;

    u32 final_offset = byte_offset_in_hunk + sector_offset;

    if (final_offset + 2048 > m_hunk_bytes)
    {
        Error("ReadSector failed - offset %u + 2048 exceeds hunk size %u", final_offset, m_hunk_bytes);
        return false;
    }

    Debug("Reading LBA %d, sector_index %u, hunk_index %u, hunk_offset %u, byte_offset_in_hunk %d, sector_offset %d",
        lba, sector_index, hunk_index, hunk_offset, byte_offset_in_hunk, sector_offset);

    memcpy(buffer, m_hunk_cache[hunk_index] + final_offset, 2048);

    m_current_sector = lba + 1;
    if (m_current_sector >= m_toc.sector_count)
        m_current_sector = m_toc.sector_count - 1;

    return true;
}

bool CdRomChdImage::ReadSamples(u32 lba, u32 offset, s16* buffer, u32 count)
{
    if (!m_ready || buffer == NULL)
    {
        Error("ReadBytes failed - Media not ready or buffer is NULL");
        return false;
    }

    if (lba >= m_toc.sector_count)
    {
        Error("ReadBytes failed - LBA %d out of bounds (max: %d)", lba, m_toc.sector_count - 1);
        return false;
    }

    s32 track_index = FindTrackFromLBA(lba, true);
    if (track_index < 0)
    {
        Error("ReadBytes failed - LBA %d not found in any track", lba);
        return false;
    }

    const Track& track = m_toc.tracks[(size_t)track_index];

    if ((lba < track.start_lba) && !track.lead_in_stored)
    {
        Error("ReadBytes failed - LBA %d is in a pregap the image does not store", lba);
        return false;
    }

    u32 sector_index = (u32)track.file_offset + lba - track.start_lba;
    u32 hunk_index  = sector_index / m_sectors_per_hunk;
    u32 hunk_offset = sector_index % m_sectors_per_hunk;
    u32 byte_offset_in_hunk = hunk_offset * (2352 + 96);

    if (!LoadHunk(hunk_index))
        return false;

    u32 size = count * 2;
    u32 final_offset = byte_offset_in_hunk + offset;

    if (final_offset + size > m_hunk_bytes)
    {
        Error("ReadSamples failed - offset %u + size %u exceeds hunk size %u", final_offset, size, m_hunk_bytes);
        return false;
    }

    memcpy(buffer, m_hunk_cache[hunk_index] + final_offset, size);

    m_current_sector = lba;

#ifdef GG_LITTLE_ENDIAN
    for (u32 i = 0; i < count; i++)
    {
        u16 u = (u16)buffer[i];
        buffer[i] = (s16)((u >> 8) | (u << 8));
    }
#endif

    return true;
}

bool CdRomChdImage::PreloadDisc()
{
    if (!m_ready)
    {
        Error("PreloadDisc failed - Media not ready");
        return false;
    }

    if (m_hunk_cache == NULL)
    {
        Error("PreloadDisc failed - Hunk cache not initialized");
        return false;
    }

    Log("Preloading CHD disc...");
    chd_error err = chd_precache(m_chd_file);

    if (err != CHDERR_NONE)
    {
        Error("PreloadDisc failed - chd_precache returned error %d, %s", err, chd_error_string(err));
        return false;
    }

    return true;
}

bool CdRomChdImage::PreloadTrack(u32 track_number, u32 lba)
{
    if (track_number >= m_toc.tracks.size())
    {
        Error("PreloadTrack failed - Invalid track number %d", track_number);
        return false;
    }

    const Track& track = m_toc.tracks[track_number];

    if ((lba < track.start_lba) || (lba > track.end_lba))
    {
        Error("PreloadTrack failed - LBA %u out of track %u bounds", lba, track_number + 1);
        return false;
    }

    u32 sector_index = 0;

    if (!checked_add_u32((u32)track.file_offset, lba - track.start_lba, &sector_index))
    {
        Error("PreloadTrack failed - Track sector range overflow");
        return false;
    }

    u32 hunk = sector_index / m_sectors_per_hunk;

    Debug("Preloading track %u from LBA %u: hunk %u", track_number + 1, lba, hunk);

    if (!LoadHunk(hunk))
    {
        Error("PreloadTrack failed - Unable to load hunk %u", hunk);
        return false;
    }

    return true;
}

bool CdRomChdImage::ReadTOC()
{
    chd_error err;
    char metadata[512];

    u32 current_lba = 0;
    u32 file_offset = 0;

    for (int i = 0; i < 99; i++)
    {
        bool track_exists = false;
        int track = 0, frames = 0, pregap = 0, postgap = 0;
        char type[64], subtype[32], pgtype[32], pgsub[32];
        type[0] = subtype[0] = pgtype[0] = pgsub[0] = 0;
        memset(metadata, 0, sizeof(metadata));

        err = chd_get_metadata(m_chd_file, CDROM_TRACK_METADATA2_TAG, i, metadata, sizeof(metadata) - 1, NULL, NULL, NULL);

        if (err == CHDERR_NONE)
        {
            if (sscanf(metadata, "TRACK:%d TYPE:%63s SUBTYPE:%31s FRAMES:%d PREGAP:%d PGTYPE:%31s PGSUB:%31s POSTGAP:%d",
                &track, type, subtype, &frames, &pregap, pgtype, pgsub, &postgap) != 8)
            {
                Error("Failed to parse CDROM_TRACK_METADATA2_FORMAT for track %d", i + 1);
                return false;
            }
            track_exists = true;
        }
        else
        {
            err = chd_get_metadata(m_chd_file, CDROM_TRACK_METADATA_TAG, i, metadata, sizeof(metadata) - 1, NULL, NULL, NULL);
            if (err == CHDERR_NONE)
            {
                if (sscanf(metadata, "TRACK:%d TYPE:%63s SUBTYPE:%31s FRAMES:%d", &track, type, subtype, &frames) != 4)
                {
                    Error("Failed to parse CDROM_TRACK_METADATA_FORMAT for track %d", i + 1);
                    return false;
                }
                track_exists = true;
            }
        }

        if (!track_exists)
            break;

        Debug("Track %d: Type: %s, Subtype: %s, Frames: %d, Pregap: %d, Postgap: %d, PGType: %s, PGSub: %s", 
                track, type, subtype, frames, pregap, postgap, pgtype, pgsub);

        if (frames < 0 || pregap < 0 || postgap < 0)
        {
            Error("Invalid CHD metadata for track %d - Negative frame or gap count", i + 1);
            return false;
        }

        // Calculate real pregap and pregap_dv
        u32 pregap_real = (pgtype[0] == 'V' ? 0 : pregap);
        u32 pregap_dv = (pgtype[0] == 'V' ? pregap : 0);

        if ((u32)frames <= pregap_dv)
        {
            Error("Invalid CHD metadata for track %d - Frames must exceed stored pregap", i + 1);
            return false;
        }

        // Advance current LBA by pregaps
        if (!checked_add_u32(current_lba, pregap_real + pregap_dv, &current_lba))
        {
            Error("Invalid CHD metadata for track %d - LBA overflow", i + 1);
            return false;
        }

        Track new_track;
        InitTrack(new_track);

        if (!GetTrackType(type, new_track.type))
            return false;

        new_track.sector_size = TrackTypeSectorSize(new_track.type);

        new_track.start_lba = current_lba;
        LbaToMsf(new_track.start_lba, &new_track.start_msf);

        if (pregap_real > 0 || pregap_dv > 0)
        {
            new_track.has_lead_in = true;
            new_track.lead_in_lba = current_lba - pregap_real - pregap_dv;
            new_track.lead_in_stored = pregap_dv > 0;
        }

        u32 data_frames = (u32)frames - pregap_dv;
        new_track.sector_count = data_frames;

        if (!checked_add_u32(new_track.start_lba, data_frames - 1, &new_track.end_lba))
        {
            Error("Invalid CHD metadata for track %d - Track end LBA overflow", i + 1);
            return false;
        }

        LbaToMsf(new_track.end_lba, &new_track.end_msf);

        // Advance current LBA past data and postgap
        if (!checked_add_u32(current_lba, data_frames, &current_lba) ||
            !checked_add_u32(current_lba, (u32)postgap, &current_lba))
        {
            Error("Invalid CHD metadata for track %d - LBA overflow", i + 1);
            return false;
        }

        // Update file_offset: pregap_dv + data + alignment to 4 sectors, postgaps are not stored
        if (!checked_add_u32(file_offset, pregap_dv, &file_offset))
        {
            Error("Invalid CHD metadata for track %d - File offset overflow", i + 1);
            return false;
        }

        new_track.file_offset = file_offset;

        u32 frame_padding = (4 - ((u32)frames & 3)) & 3;

        if (!checked_add_u32(file_offset, data_frames, &file_offset) ||
            !checked_add_u32(file_offset, frame_padding, &file_offset))
        {
            Error("Invalid CHD metadata for track %d - File offset overflow", i + 1);
            return false;
        }

        m_toc.tracks.push_back(new_track);
    }

    for (size_t i = 0; i < m_toc.tracks.size(); ++i)
    {
        Track& track = m_toc.tracks[i];

        Log("Track %2d (%s): Start LBA: %6u, End LBA: %6u, Sectors: %6u, File Offset: %8llu",
                i + 1,
                TrackTypeName(track.type),
                track.start_lba,
                track.end_lba,
                track.sector_count,
                track.file_offset);
    }

    Log("Successfully parsed CHD file with %d tracks", (int)m_toc.tracks.size());

    if (m_toc.tracks.empty())
    {
        m_toc.sector_count = 0;
        m_toc.total_length = {0, 0, 0};
    }
    else
    {
        if (!checked_add_u32(m_toc.tracks.back().end_lba, 1, &m_toc.sector_count))
        {
            Error("Invalid CHD metadata - Total sector count overflow");
            return false;
        }

        u32 total_frames = 0;
        if (!checked_add_u32(m_toc.sector_count, 150, &total_frames))
        {
            Error("Invalid CHD metadata - Total length overflow");
            return false;
        }

        LbaToMsf(total_frames, &m_toc.total_length);
    }

    Debug("CD-ROM length: %02d:%02d:%02d, Total sectors: %d",
        m_toc.total_length.minutes, m_toc.total_length.seconds, m_toc.total_length.frames,
        m_toc.sector_count);

    return !m_toc.tracks.empty();
}

void CdRomChdImage::CalculateCRC()
{
    m_crc = 0;

    if (m_toc.tracks.empty())
    {
        Log("No tracks to calculate CRC from");
        return;
    }

    Track* first_data_track = NULL;
    size_t track_count = m_toc.tracks.size();

    for (size_t i = 0; i < track_count; i++)
    {
        if (m_toc.tracks[i].type == GG_CDROM_DATA_TRACK_MODE1_2048 ||
            m_toc.tracks[i].type == GG_CDROM_DATA_TRACK_MODE1_2352)
        {
            first_data_track = &m_toc.tracks[i];
            break;
        }
    }

    if (!first_data_track)
    {
        Log("No data tracks found for CRC calculation");
        return;
    }

    if (first_data_track->sector_count == 0)
    {
        Log("First data track has no sectors, cannot calculate CRC");
        return;
    }

    const u32 sector_data_size = 2048;
    u8 buffer[sector_data_size];
    u32 current_sector = m_current_sector;

    u32 sectors_to_crc = 64;
    u32 first_sector = 1;
    u32 last_needed = first_sector + sectors_to_crc - 1;
    u32 max_index = ((first_data_track->sector_count - 1) >= last_needed)
                     ? last_needed
                     : (first_data_track->sector_count - 1);

    for (u32 sec = first_sector; sec <= max_index; sec++)
    {
        if (!ReadSector(sec + first_data_track->start_lba, buffer))
        {
            Error("CRC ReadSector failed for LBA %u", sec + first_data_track->start_lba);
            m_current_sector = current_sector;
            return;
        }

        m_crc = CalculateCRC32(m_crc, buffer, sector_data_size);
    }

    m_current_sector = current_sector;
}

bool CdRomChdImage::InitHunkCache()
{
    if (IsValidPointer(m_hunk_cache))
    {
        DestroyHunkCache();
    }

    if (m_hunk_count == 0 || m_hunk_count > 500000)
    {
        Error("Invalid CHD hunk count %u", m_hunk_count);
        return false;
    }

    m_hunk_cache = new u8*[m_hunk_count];

    for (u32 i = 0; i < m_hunk_count; i++)
    {
        InitPointer(m_hunk_cache[i]);
    }

    return true;
}

void CdRomChdImage::DestroyHunkCache()
{
    if (IsValidPointer(m_hunk_cache))
    {
        for (u32 i = 0; i < m_hunk_count; i++)
        {
            SafeDeleteArray(m_hunk_cache[i]);
        }
        SafeDeleteArray(m_hunk_cache);
    }
}

bool CdRomChdImage::LoadHunk(u32 hunk_index)
{
    if (hunk_index >= m_hunk_count)
    {
        Error("LoadHunk failed - hunk index %u out of bounds (max: %u)", hunk_index, m_hunk_count - 1);
        return false;
    }

    if (m_hunk_cache[hunk_index] == NULL)
    {
        m_hunk_cache[hunk_index] = new u8[m_hunk_bytes];

        Debug("Caching hunk %u", hunk_index);

        chd_error err = chd_read(m_chd_file, hunk_index, m_hunk_cache[hunk_index]);

        if (err != CHDERR_NONE)
        {
            Error("CHD read hunk %u failed: %d, %s", hunk_index, err, chd_error_string(err));
            SafeDeleteArray(m_hunk_cache[hunk_index]);
            return false;
        }
    }

    return true;
}

bool CdRomChdImage::GetTrackType(const char* type_str, GG_CdRomTrackType& type)
{
    if (strcmp(type_str, "AUDIO") == 0)
        type = GG_CDROM_AUDIO_TRACK;
    else if (strcmp(type_str, "MODE1") == 0)
        type = GG_CDROM_DATA_TRACK_MODE1_2048;
    else if (strcmp(type_str, "MODE1_RAW") == 0)
        type = GG_CDROM_DATA_TRACK_MODE1_2352;
    else
    {
        Error("Unsupported CHD track type: %s", type_str);
        return false;
    }

    return true;
}
