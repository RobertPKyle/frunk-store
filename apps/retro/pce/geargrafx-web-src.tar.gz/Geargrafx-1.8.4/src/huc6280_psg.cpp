/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <math.h>
#include <assert.h>
#include <algorithm>
#include "huc6280_psg.h"

HuC6280PSG::HuC6280PSG()
{
    InitPointer(m_channels);
    InitPointer(m_ch);
    m_dac_offset = k_huc6280_psg_huc6280_dac_offset;
    m_hpf_prev_input[0] = 0.0f;
    m_hpf_prev_input[1] = 0.0f;
    m_hpf_prev_output[0] = 0.0f;
    m_hpf_prev_output[1] = 0.0f;
}

HuC6280PSG::~HuC6280PSG()
{
    SafeDeleteArray(m_channels);
}

void HuC6280PSG::Init()
{
    m_channels = new HuC6280PSG_Channel[6];
    m_lfo_src = &m_channels[1];
    m_lfo_dest = &m_channels[0];

    m_state.CHANNELS = m_channels;
    m_state.CHANNEL_SELECT = &m_channel_select;
    m_state.MAIN_AMPLITUDE = &m_main_vol;
    m_state.LFO_FREQUENCY = &m_lfo_frequency;
    m_state.LFO_CONTROL = &m_lfo_control;
    m_state.FRAME_SAMPLES = &m_frame_samples;

    for (int i = 0; i < 6; i++)
    {
        m_channels[i].mute = false;
    }

    ComputeVolumeLUT();
    Reset();
}

void HuC6280PSG::Reset()
{
    m_elapsed_cycles = 0;
    m_buffer_index = 0;
    m_frame_samples = 0;

    m_hpf_prev_input[0] = 0.0f;
    m_hpf_prev_input[1] = 0.0f;
    m_hpf_prev_output[0] = 0.0f;
    m_hpf_prev_output[1] = 0.0f;

    m_channel_select = 0;
    m_main_vol = 0;
    m_main_vol_left = 0;
    m_main_vol_right = 0;
    m_lfo_enabled = 0;
    m_lfo_frequency = 0;
    m_lfo_control = 0;

    m_ch = &m_channels[0];

    for (int i = 0; i < 6; i++)
    {
        m_channels[i].enabled = 0;
        m_channels[i].frequency = 0;
        m_channels[i].control = 0;
        m_channels[i].amplitude = 0;
        m_channels[i].vol_left = 0;
        m_channels[i].vol_right = 0;
        m_channels[i].wave = 0;
        m_channels[i].wave_index = 0;
        m_channels[i].noise_control = 0;
        m_channels[i].noise_enabled = 0;
        m_channels[i].noise_freq = 0x1F << 6;
        m_channels[i].noise_seed = 1;
        m_channels[i].noise_counter = 0;
        m_channels[i].counter = 0;
        m_channels[i].dda = 0;
        m_channels[i].dda_enabled = 0;
        m_channels[i].left_sample = 0;
        m_channels[i].right_sample = 0;
        m_wave_sum[i] = 0;

        for (int j = 0; j < 32; j++)
        {
            m_channels[i].wave_data[j] = 0;
        }

        for (int j = 0; j < GG_AUDIO_BUFFER_SIZE; j++)
        {
            m_channels[i].output[j] = 0;
        }

        UpdateChannelVolume(i);
    }
}

void HuC6280PSG::RebuildWaveSums()
{
    for (int channel = 0; channel < 6; channel++)
    {
        m_wave_sum[channel] = 0;

        for (int i = 0; i < 32; i++)
            m_wave_sum[channel] += m_channels[channel].wave_data[i] & 0x1F;
    }
}

void HuC6280PSG::Write(u16 address, u8 value)
{
    Sync();

    switch (address & 0x0F)
    {
    // Channel select
    case 0:
        m_channel_select = value & 0x07;
        if (m_channel_select < 6)
            m_ch = &m_channels[m_channel_select];
        break;
    // Main amplitude
    case 1:
        m_main_vol = value;
        m_main_vol_left = (value >> 4) & 0x0F;
        m_main_vol_right = value & 0x0F;

        for (int i = 0; i < 6; i++)
            UpdateChannelVolume(i);

        break;
    // Channel frequency (low)
    case 2:
        if (m_channel_select < 6)
        {
            m_ch->frequency = (m_ch->frequency & 0x0F00) | value;
        }
        break;
    // Channel frequency (high)
    case 3:
        if (m_channel_select < 6)
        {
            m_ch->frequency = (m_ch->frequency & 0x00FF) | ((value & 0x0F) << 8);
        }
        break;
    // Channel control
    case 4:
        if (m_channel_select < 6)
        {
            bool enabled = IS_SET_BIT(value, 7);
            bool dda_enabled = IS_SET_BIT(value, 6);
            bool dda_falling = m_ch->dda_enabled && !dda_enabled;

            // DDA holds the waveform address reset
            if (m_ch->dda_enabled || dda_enabled)
            {
                m_ch->wave_index = 0;
            }

            if (dda_falling)
            {
                m_ch->counter = m_ch->frequency ? m_ch->frequency : 0x1000;
            }

            m_ch->control = value;
            m_ch->enabled = enabled;
            m_ch->dda_enabled = dda_enabled;

            UpdateChannelVolume(m_channel_select);

            if (dda_falling)
            {
                UpdateWaveformOutput(m_ch->wave_data[0]);
            }
        }
        break;
    // Channel amplitude
    case 5:
        if (m_channel_select < 6)
        {
            m_ch->amplitude = value;
            m_ch->vol_left = (value >> 4) & 0x0F;
            m_ch->vol_right = value & 0x0F;

            UpdateChannelVolume(m_channel_select);
        }
        break;
    // Channel waveform data
    case 6:
        if (m_channel_select < 6)
        {
            u8 data = value & 0x1F;
            m_ch->wave = data;

            // DDA on
            if (IS_SET_BIT(m_ch->control, 6))
            {
                m_ch->dda = data;
            }
            // DDA off
            else
            {
                m_wave_sum[m_channel_select] -= m_ch->wave_data[m_ch->wave_index] & 0x1F;
                m_ch->wave_data[m_ch->wave_index] = data;
                m_wave_sum[m_channel_select] += m_ch->wave_data[m_ch->wave_index];

                if (!m_ch->enabled)
                {
                    m_ch->wave_index = ((m_ch->wave_index + 1) & 0x1F);
                }

                UpdateWaveformOutput(data);
            }
        }
        break;
    // Channel noise (only channels 4 and 5)
    case 7:
        if ((m_channel_select > 3) && (m_channel_select < 6))
        {
            m_ch->noise_control = value;
            m_ch->noise_enabled = IS_SET_BIT(value, 7);
            u8 freq = value & 0x1F;
            if (freq == 0x1F)
                m_ch->noise_freq = 32;
            else
                m_ch->noise_freq = ((~freq) & 0x1F) << 6;
        }
        break;
    // LFO frequency
    case 8:
        m_lfo_frequency = value;
        break;
    // LFO control
    case 9:
        if (IS_SET_BIT(value, 7))
        {
            u16 lfo_freq = m_lfo_src->frequency ? m_lfo_src->frequency : 0x1000;
            // Reload the period active before this control write.
            m_lfo_src->counter = lfo_freq * (m_lfo_enabled ? GetLfoFrequency() : 1);
            m_lfo_src->wave_index = 0;
            m_lfo_src->dda = m_lfo_src->wave_data[0];
        }

        m_lfo_control = value;
        m_lfo_enabled = (value & 0x03);
        break;
    }
}

void HuC6280PSG::Sync()
{
    int remaining_cycles = m_elapsed_cycles;
    m_elapsed_cycles = 0;

    while (remaining_cycles > 0)
    {
        int batch_size = remaining_cycles;

        bool lfo_configured = IsLfoConfigured();
        bool lfo_running = IsLfoRunning();

        if (lfo_running && !m_lfo_src->dda_enabled && !m_lfo_dest->dda_enabled)
        {
            int source_counter = MAX(1, m_lfo_src->counter);
            int dest_counter = MAX(1, m_lfo_dest->counter);

            // Batch constant modulation, or stop at the first destination reload
            // after the source changes.
            int lfo_cycles = dest_counter < source_counter ? source_counter - 1 : dest_counter;
            batch_size = MIN(batch_size, lfo_cycles);
        }

        remaining_cycles -= batch_size;

        if (lfo_running && !m_lfo_src->dda_enabled)
        {
            u16 lfo_freq = m_lfo_src->frequency ? m_lfo_src->frequency : 0x1000;
            s32 lfo_period = lfo_freq * GetLfoFrequency();
            int lfo_counter_new = m_lfo_src->counter - batch_size;

            if (lfo_counter_new <= 0)
            {
                int lfo_steps = 1 + ((-lfo_counter_new) / lfo_period);
                m_lfo_src->counter = lfo_counter_new + (lfo_steps * lfo_period);
                m_lfo_src->wave_index = (m_lfo_src->wave_index + lfo_steps) & 0x1F;
            }
            else
            {
                m_lfo_src->counter = lfo_counter_new;
            }
        }

        for (int i = 0; i < 6; i++)
        {
            HuC6280PSG_Channel* ch = &m_channels[i];
            ch->left_sample = 0;
            ch->right_sample = 0;
            s8 noise_data = 0;

            // LFSR is always running
            if (i >= 4)
            {
                noise_data = IS_SET_BIT(ch->noise_seed, 0) ? 0x1F : 0;

                int noise_counter_new = ch->noise_counter - batch_size;
                if (noise_counter_new <= 0)
                {
                    int noise_steps = 1 + ((-noise_counter_new) / ch->noise_freq);
                    ch->noise_counter = noise_counter_new + (noise_steps * ch->noise_freq);

                    for (int step = 0; step < noise_steps; step++)
                    {
                        u32 seed = ch->noise_seed;
                        ch->noise_seed = (seed >> 1) | ((IS_SET_BIT(seed, 0) ^ IS_SET_BIT(seed, 1) ^ 
                                         IS_SET_BIT(seed, 11) ^ IS_SET_BIT(seed, 12) ^ 
                                         IS_SET_BIT(seed, 17)) << 17);
                    }

                    noise_data = IS_SET_BIT(ch->noise_seed, 0) ? 0x1F : 0;
                }
                else
                {
                    ch->noise_counter = noise_counter_new;
                }
            }

            if (!ch->enabled)
                continue;

            s8 data = 0;
            bool noise_enabled = ch->noise_enabled && (i >= 4);

            // Noise
            if (noise_enabled)
            {
                if (!ch->dda_enabled)
                    AdvanceWaveform(ch, batch_size);

                data = noise_data;
            }
            // DDA
            else if (ch->dda_enabled)
                data = ch->dda;
            // LFO destination
            else if (lfo_configured && (i == 0))
            {
                u16 freq = m_lfo_dest->frequency ? m_lfo_dest->frequency : 0x1000;
                u8 lfo_data = m_lfo_src->wave_data[m_lfo_src->wave_index];
                freq = CalculateLfoPeriod(freq, lfo_data);

                int dest_counter_new = m_lfo_dest->counter - batch_size;
                if (dest_counter_new <= 0)
                {
                    int dest_steps = 1 + ((-dest_counter_new) / freq);
                    m_lfo_dest->counter = dest_counter_new + (dest_steps * freq);
                    m_lfo_dest->wave_index = (m_lfo_dest->wave_index + dest_steps) & 0x1F;
                }
                else
                {
                    m_lfo_dest->counter = dest_counter_new;
                }

                data = m_lfo_dest->wave_data[m_lfo_dest->wave_index];
            }
            // LFO source or channel 1 held by the trigger, even without modulation
            else if ((i == 1) && (lfo_configured || IS_SET_BIT(m_lfo_control, 7)))
                data = m_lfo_src->wave_data[m_lfo_src->wave_index];
            // Waveform without LFO
            else
            {
                u16 freq = AdvanceWaveform(ch, batch_size);

                if (!ch->mute)
                {
                    ch->left_sample = GetWaveformSample(i, freq, ch->gain_left);
                    ch->right_sample = GetWaveformSample(i, freq, ch->gain_right);
                }

                continue;
            }

            if (!ch->mute)
            {
                ch->left_sample = ScaleSample(data, ch->gain_left);
                ch->right_sample = ScaleSample(data, ch->gain_right);
            }
        }

    }
}

void HuC6280PSG::Sample()
{
    Sync();

    for (int i = 0; i < 6; i++)
    {
        m_channels[i].output[m_buffer_index + 0] = m_channels[i].left_sample;
        m_channels[i].output[m_buffer_index + 1] = m_channels[i].right_sample;
    }

    m_buffer_index += 2;

    if (m_buffer_index >= GG_AUDIO_BUFFER_SIZE)
    {
        Error("PSG buffer overflow");
        m_buffer_index = 0;
    }
}

int HuC6280PSG::EndFrame(s16* sample_buffer)
{
    Sync();

    int samples = 0;

    if (IsValidPointer(sample_buffer))
    {
        samples = m_buffer_index;
        m_frame_samples = m_buffer_index;

        for (int s = 0; s < samples; s++)
        {
            int channel = s & 0x01;
            float raw = 0.0f;
            for (int i = 0; i < 6; i++)
                raw += m_channels[i].output[s];
            raw *= k_huc6280_psg_output_scale;

            const float hpf_r = 0.9985f;
            float outSample = raw - m_hpf_prev_input[channel] + hpf_r * m_hpf_prev_output[channel];

            m_hpf_prev_input[channel] = raw;
            m_hpf_prev_output[channel] = outSample;

            sample_buffer[s] = (s16)CLAMP(outSample, -32768.0f, 32767.0f);
        }
    }

    m_buffer_index = 0;

    return samples;
}

void HuC6280PSG::ComputeVolumeLUT()
{
    double amplitude = 65535.0 / 6.0 / 32.0;
    double step = 48.0 / 32.0;
    
    for (int i = 0; i < 31; i++)
    {
        m_volume_lut[i] = (u16)amplitude;
        amplitude /= pow(10.0, step / 20.0);
    }

    m_volume_lut[31] = 0;
}

void HuC6280PSG::UpdateChannelVolume(int channel)
{
    HuC6280PSG_Channel* ch = &m_channels[channel];

    u8 main_left = k_huc6280_psg_volume_scale[m_main_vol_left & 0x0F];
    u8 main_right = k_huc6280_psg_volume_scale[m_main_vol_right & 0x0F];
    u8 channel_left = k_huc6280_psg_volume_scale[ch->vol_left & 0x0F];
    u8 channel_right = k_huc6280_psg_volume_scale[ch->vol_right & 0x0F];
    u8 channel_volume = ch->control & 0x1F;

    u8 temp_left_vol = MIN(0x1F, (0x1F - main_left) + (0x1F - channel_left) + (0x1F - channel_volume));
    u8 temp_right_vol = MIN(0x1F, (0x1F - main_right) + (0x1F - channel_right) + (0x1F - channel_volume));

    ch->gain_left = m_volume_lut[temp_left_vol];
    ch->gain_right = m_volume_lut[temp_right_vol];
}

void HuC6280PSG::SaveState(std::ostream& stream)
{
    stream.write(reinterpret_cast<const char*> (&m_channel_select), sizeof(m_channel_select));
    stream.write(reinterpret_cast<const char*> (&m_main_vol), sizeof(m_main_vol));
    stream.write(reinterpret_cast<const char*> (&m_main_vol_left), sizeof(m_main_vol_left));
    stream.write(reinterpret_cast<const char*> (&m_main_vol_right), sizeof(m_main_vol_right));
    stream.write(reinterpret_cast<const char*> (&m_lfo_enabled), sizeof(m_lfo_enabled));
    stream.write(reinterpret_cast<const char*> (&m_lfo_frequency), sizeof(m_lfo_frequency));
    stream.write(reinterpret_cast<const char*> (&m_lfo_control), sizeof(m_lfo_control));
    stream.write(reinterpret_cast<const char*> (&m_elapsed_cycles), sizeof(m_elapsed_cycles));
    stream.write(reinterpret_cast<const char*> (&m_frame_samples), sizeof(m_frame_samples));

    for (int i = 0; i < 6; i++)
    {
        stream.write(reinterpret_cast<const char*> (&m_channels[i].enabled), sizeof(m_channels[i].enabled));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].frequency), sizeof(m_channels[i].frequency));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].control), sizeof(m_channels[i].control));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].amplitude), sizeof(m_channels[i].amplitude));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].vol_left), sizeof(m_channels[i].vol_left));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].vol_right), sizeof(m_channels[i].vol_right));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].wave), sizeof(m_channels[i].wave));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].wave_index), sizeof(m_channels[i].wave_index));
        stream.write(reinterpret_cast<const char*> (m_channels[i].wave_data), sizeof(m_channels[i].wave_data));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].noise_control), sizeof(m_channels[i].noise_control));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].noise_enabled), sizeof(m_channels[i].noise_enabled));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].noise_freq), sizeof(m_channels[i].noise_freq));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].noise_seed), sizeof(m_channels[i].noise_seed));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].noise_counter), sizeof(m_channels[i].noise_counter));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].counter), sizeof(m_channels[i].counter));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].dda), sizeof(m_channels[i].dda));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].dda_enabled), sizeof(m_channels[i].dda_enabled));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].left_sample), sizeof(m_channels[i].left_sample));
        stream.write(reinterpret_cast<const char*> (&m_channels[i].right_sample), sizeof(m_channels[i].right_sample));
    }

    stream.write(reinterpret_cast<const char*> (m_hpf_prev_input), sizeof(m_hpf_prev_input));
    stream.write(reinterpret_cast<const char*> (m_hpf_prev_output), sizeof(m_hpf_prev_output));
}

void HuC6280PSG::LoadState(std::istream& stream, int version)
{
    stream.read(reinterpret_cast<char*> (&m_channel_select), sizeof(m_channel_select));
    stream.read(reinterpret_cast<char*> (&m_main_vol), sizeof(m_main_vol));
    stream.read(reinterpret_cast<char*> (&m_main_vol_left), sizeof(m_main_vol_left));
    stream.read(reinterpret_cast<char*> (&m_main_vol_right), sizeof(m_main_vol_right));
    stream.read(reinterpret_cast<char*> (&m_lfo_enabled), sizeof(m_lfo_enabled));
    stream.read(reinterpret_cast<char*> (&m_lfo_frequency), sizeof(m_lfo_frequency));
    m_lfo_frequency &= 0xFF;
    stream.read(reinterpret_cast<char*> (&m_lfo_control), sizeof(m_lfo_control));
    stream.read(reinterpret_cast<char*> (&m_elapsed_cycles), sizeof(m_elapsed_cycles));

    if (version < 32)
    {
        s32 sample_cycle_counter = 0;
        stream.read(reinterpret_cast<char*> (&sample_cycle_counter), sizeof(sample_cycle_counter));
    }

    if (version >= 27)
    {
        stream.read(reinterpret_cast<char*> (&m_frame_samples), sizeof(m_frame_samples));
        m_frame_samples = CLAMP(m_frame_samples, 0, GG_AUDIO_BUFFER_SIZE);
    }
    else
        m_frame_samples = 0;

    bool has_output = (version >= 27) && (version < 40);

    if (has_output)
    {
        stream.read(reinterpret_cast<char*> (&m_buffer_index), sizeof(m_buffer_index));
        m_buffer_index = CLAMP(m_buffer_index, 0, GG_AUDIO_BUFFER_SIZE - 2);
        m_buffer_index &= ~1;
    }
    else
        m_buffer_index = 0;

    for (int i = 0; i < 6; i++)
    {
        stream.read(reinterpret_cast<char*> (&m_channels[i].enabled), sizeof(m_channels[i].enabled));
        stream.read(reinterpret_cast<char*> (&m_channels[i].frequency), sizeof(m_channels[i].frequency));
        stream.read(reinterpret_cast<char*> (&m_channels[i].control), sizeof(m_channels[i].control));
        stream.read(reinterpret_cast<char*> (&m_channels[i].amplitude), sizeof(m_channels[i].amplitude));

        if (version < 42)
        {
            u8 vol = 0;
            stream.read(reinterpret_cast<char*> (&vol), sizeof(vol));
        }

        stream.read(reinterpret_cast<char*> (&m_channels[i].vol_left), sizeof(m_channels[i].vol_left));
        stream.read(reinterpret_cast<char*> (&m_channels[i].vol_right), sizeof(m_channels[i].vol_right));
        stream.read(reinterpret_cast<char*> (&m_channels[i].wave), sizeof(m_channels[i].wave));
        stream.read(reinterpret_cast<char*> (&m_channels[i].wave_index), sizeof(m_channels[i].wave_index));
        stream.read(reinterpret_cast<char*> (m_channels[i].wave_data), sizeof(m_channels[i].wave_data));
        stream.read(reinterpret_cast<char*> (&m_channels[i].noise_control), sizeof(m_channels[i].noise_control));
        stream.read(reinterpret_cast<char*> (&m_channels[i].noise_enabled), sizeof(m_channels[i].noise_enabled));
        stream.read(reinterpret_cast<char*> (&m_channels[i].noise_freq), sizeof(m_channels[i].noise_freq));
        stream.read(reinterpret_cast<char*> (&m_channels[i].noise_seed), sizeof(m_channels[i].noise_seed));
        stream.read(reinterpret_cast<char*> (&m_channels[i].noise_counter), sizeof(m_channels[i].noise_counter));
        stream.read(reinterpret_cast<char*> (&m_channels[i].counter), sizeof(m_channels[i].counter));
        stream.read(reinterpret_cast<char*> (&m_channels[i].dda), sizeof(m_channels[i].dda));
        stream.read(reinterpret_cast<char*> (&m_channels[i].dda_enabled), sizeof(m_channels[i].dda_enabled));
        stream.read(reinterpret_cast<char*> (&m_channels[i].left_sample), sizeof(m_channels[i].left_sample));
        stream.read(reinterpret_cast<char*> (&m_channels[i].right_sample), sizeof(m_channels[i].right_sample));

        if (has_output)
            stream.read(reinterpret_cast<char*> (m_channels[i].output), sizeof(m_channels[i].output));
        else
            memset(m_channels[i].output, 0, sizeof(m_channels[i].output));

        if (version < 36)
        {
            s32 left_sample = (s32)m_channels[i].left_sample * k_huc6280_psg_sample_scale;
            s32 right_sample = (s32)m_channels[i].right_sample * k_huc6280_psg_sample_scale;
            m_channels[i].left_sample = (s16)CLAMP(left_sample, -32768, 32767);
            m_channels[i].right_sample = (s16)CLAMP(right_sample, -32768, 32767);

            for (int j = 0; j < GG_AUDIO_BUFFER_SIZE; j++)
            {
                s32 sample = (s32)m_channels[i].output[j] * k_huc6280_psg_sample_scale;
                m_channels[i].output[j] = (s16)CLAMP(sample, -32768, 32767);
            }
        }
    }

    if (version >= 28)
    {
        stream.read(reinterpret_cast<char*> (m_hpf_prev_input), sizeof(m_hpf_prev_input));
        stream.read(reinterpret_cast<char*> (m_hpf_prev_output), sizeof(m_hpf_prev_output));
    }
    else if (version >= 24)
    {
        float hpf_prev_input = 0.0f;
        float hpf_prev_output = 0.0f;
        stream.read(reinterpret_cast<char*> (&hpf_prev_input), sizeof(hpf_prev_input));
        stream.read(reinterpret_cast<char*> (&hpf_prev_output), sizeof(hpf_prev_output));

        m_hpf_prev_input[0] = hpf_prev_input;
        m_hpf_prev_input[1] = hpf_prev_input;
        m_hpf_prev_output[0] = hpf_prev_output;
        m_hpf_prev_output[1] = hpf_prev_output;
    }
    else
    {
        m_hpf_prev_input[0] = 0.0f;
        m_hpf_prev_input[1] = 0.0f;
        m_hpf_prev_output[0] = 0.0f;
        m_hpf_prev_output[1] = 0.0f;
    }

    RebuildWaveSums();

    m_channel_select &= 0x07;
    if (m_channel_select < 6)
        m_ch = &m_channels[m_channel_select];
    else
        m_ch = &m_channels[0];

    for (int i = 0; i < 6; i++)
        UpdateChannelVolume(i);
}
