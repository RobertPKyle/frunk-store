/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef GAME_DB_H
#define GAME_DB_H

#include "common.h"

#define GG_GAMEDB_SGX_REQUIRED          0x0001
#define GG_GAMEDB_SGX_OPTIONAL          0x0002
#define GG_GAMEDB_SF2_MAPPER            0x0004
#define GG_GAMEDB_CARD_RAM_8000         0x0008
#define GG_GAMEDB_AVENUE_PAD_3_SELECT   0x0010
#define GG_GAMEDB_AVENUE_PAD_3_RUN      0x0020
#define GG_GAMEDB_GAME_EXPRESS          0x0040
#define GG_GAMEDB_ARCADE_CARD           0x0080
#define GG_GAMEDB_MB128                 0x0100
#define GG_GAMEDB_BIOS_SYSCARD          0x4000
#define GG_GAMEDB_BIOS_GAME_EXPRESS     0x8000

struct GG_DB_Entry
{
    u32 crc;
    const char* title;
    u16 flags;
    float adpcm_clock_speed;
};

const GG_DB_Entry k_game_database[] =
{
    // BIOS
    { 0x3F9F95A4, "CD-ROM System Card [1.0] (J)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x52520BC6, "CD-ROM System Card [2.0] (J)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x283B74E0, "CD-ROM System Card [2.1] (J)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x6D9A73EF, "Super CD-ROM System [3.0] (J)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x0ECEA1F3, "Super CD-ROM System [3.0] (J) [NuFont Hack]", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0xFF2A5EC3, "TurboGrafx CD System Card [2.0] (USA)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x2B5B75FE, "TurboGrafx CD Super System [3.0] (USA)", GG_GAMEDB_BIOS_SYSCARD, 0 },
    { 0x51A12D90, "Game Express Card [Blue Version] (J)", GG_GAMEDB_BIOS_GAME_EXPRESS, 0 },
    { 0x16AAF05A, "Game Express Card [Green Version] (J)", GG_GAMEDB_BIOS_GAME_EXPRESS, 0 },

    // SGX
    { 0x8C4588E2, "1941 - Counter Attack (J) (SGX)", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xCD854B38, "1941 - Counter Attack (J) (SGX) [Alt 1]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x4C2126B0, "Aldynes (J) (SGX)", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xFF30DC62, "Aldynes (J) (SGX) [Alt 1]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x33A92136, "Aldynes (J) (SGX) [Alt 2]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x3B13AF61, "Battle Ace (J) (SGX)", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x6D97373E, "Battle Ace (J) (SGX) [Alt 1]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x130A2E77, "Battle Ace (J) (SGX) [Alt 2]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xB486A8ED, "Daimakaimura (J) (SGX)", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x3334202A, "Daimakaimura (J) (SGX) [Alt 1]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xB9F758E4, "Daimakaimura (J) (SGX) [Alt 2]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xB5BEE732, "Daimakaimura (J) (SGX) [Alt 3]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x0E81080A, "Daimakaimura (J) (SGX) [Alt 4]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x7E4D6CAF, "Daimakaimura (J) (SGX) [Alt 5]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0xD6722C04, "Daimakaimura (J) (SGX) [Alt 6]", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x1F041166, "Madouou Granzort (J) (SGX)", GG_GAMEDB_SGX_REQUIRED, 0 },
    { 0x6B0C982E, "Madouou Granzort (J) (SGX) [Alt]", GG_GAMEDB_SGX_REQUIRED, 0 },

    // SGX-CD
    { 0xBB22DAB5, "Space Ava 201 - Release v1.01", GG_GAMEDB_SGX_REQUIRED | GG_GAMEDB_ARCADE_CARD, 0 },

    // OPTIONAL SGX
    { 0xBEBFE042, "Darius Plus (J) (SGX)", GG_GAMEDB_SGX_OPTIONAL, 0 },
    { 0xEB2466F9, "Darius Alpha (J) (SGX)", GG_GAMEDB_SGX_OPTIONAL, 0 },

    // SF2 MAPPER
    { 0xD15CB6BB, "Street Fighter II' - Champion Edition (J)", GG_GAMEDB_SF2_MAPPER | GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },

    // CARD RAM SIZE = 0x8000
    { 0x083C956A, "Populous (J)", GG_GAMEDB_CARD_RAM_8000, 0 },
    { 0x0A9ADE99, "Populous (J) [Alt]", GG_GAMEDB_CARD_RAM_8000, 0 },

    // GAME EXPRESS CD-ROM GAMES
    { 0x563E7822, "AV Tanjou (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },
    { 0xD74A8B08, "CD Bishoujo Pachinko - Kyuuma Yon Shimai (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },
    { 0x29AB009A, "CD Hanafuda - Bishoujo Fan Club (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },
    { 0x8FE1EC66, "CD Mahjong - Bishoujo Chuushinha (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },
    { 0xECF7F668, "CD Pachi-Slot - Bishoujo Gambler (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },
    { 0xAB786649, "Hi-Leg Fantasy (Japan) (Unl)", GG_GAMEDB_GAME_EXPRESS, 0 },

    // ARCADE CARD COMPATIBLE SUPER CD-ROM GAMES
    { 0x0B5D6132, "3x3 Eyes - Sanjiyan Hensei (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xB797C7F2, "3x3 Eyes - Sanjiyan Hensei (J) [Rev 1]", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xCDD5208E, "Formation Soccer 95 della Serie A (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xA0CDB71C, "J. League Tremendous Soccer '94 (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xD69A7A56, "Linda^3 (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x2DF5FA07, "Mahjong Sword - Princess Quest Gaiden (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x9F9404B3, "Popful Mail (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x64DA90DD, "Sexy Idol Mahjong - Fashion Monogatari (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xA6B2A3F9, "Sotsugyou II - Neo Generation (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x946897FC, "Tanjou - Debut (J)", GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x05E496DB, "Wrestling Angels - Double Impact (J)", GG_GAMEDB_ARCADE_CARD, 0 },

    // ARCADE CARD REQUIRED GAMES
    { 0xEF4294FC, "Garou Densetsu Special (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x083F480F, "Garou Densetsu Special (J) [Demo]" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x4B2CEDF2, "Garou Densetsu 2 - Aratanaru Tatakai (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x97948AEF, "Garou Densetsu 2 - Aratanaru Tatakai (J) [Demo]" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x2D41EBF7, "Ginga Fukei Densetsu Sapphire (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xC1FEA3C8, "Quest of Jongmaster - Janshin Densetsu (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x6BDC0BDA, "Kabuki Ittouryoudan (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x3DA7810B, "Mad Stalker - Full Metal Force (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xDDD1DDBB, "Mad Stalker - Full Metal Force (J) [Deemo]" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x3769A61F, "Madou Monogatari I - Honoo no Sotsuenji (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0xBA3E56D9, "Ryuuko no Ken (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x654C5174, "Shin Nihon Pro Wrestling - '94 Battlefield in Tokyo Dome (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x9C980BF1, "Strider Hiryuu (J)" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x9511585C, "Sorcery Saga I: The Fiery Kindergarten Graduation [Translation]" , GG_GAMEDB_ARCADE_CARD, 0 },
    { 0x70F5F55B, "World Heroes 2 (J)" , GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xC55F9963, "World Heroes 2 (J) [Demo]" , GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xB597F0A9, "Wrestling Universe - Fire Pro Joshi - Dome Choujo Taisen - Zenjo vs. JWP (J)" , GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },

    // AVENUE PAD 3
    { 0x933D5BCC, "Air Zonk (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xD76C4169, "Air Zonk (USA) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xCA72A828, "After Burner II (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x28B72810, "Akumajou Dracula X - Chi no Rondo (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xA1996DD5, "Akumajou Dracula X - Chi no Rondo (J) [Alt]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xCACC06FB, "Ankoku Densetsu (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xFDDC5814, "Atlantean [Unl]", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x4A3DF3CA, "Barunba (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xE70B01AF, "Battle Royale (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xB4A1B0F6, "Blazing Lazers (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xE52BE33E, "Blazing Lazers (USA) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x37BAF6BC, "Bloody Wolf (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xA98D276A, "Cyber Core (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x4CFB6E3E, "Cyber Core (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x85101C20, "Download (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x4E0DE488, "Download (J) [Alt]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x560D2305, "Final Match Tennis (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xAF2DD2AF, "Final Soldier (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x02A578C5, "Final Soldier - Special Version (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x06835D94, "Final Soldier (J) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x7FF6BE90, "Forgotten Worlds (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x8C70F1C0, "Forgotten Worlds (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xF175D704, "Gate of Thunder (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xD58E6C61, "Golden Axe (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x6DBC6A0B, "Gradius II - Gofer no Yabou (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xA17D4D7E, "Gunhed (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x57F183AE, "Gunhed - Special Version (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x609EAB27, "John Madden Duo CD Football (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x220EBF91, "Legendary Axe 2 (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x5CF2FE36, "Martial Champion (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xE18748B1, "Metamor Jupiter (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xB01F70C2, "Narazumono Sento Butai - Bloody Wolf (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x37E33F90, "Nekketsu Koukou Dodgeball-bu CD - Soccer-hen (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xF2285C6D, "Nekketsu Koukou Dodgeball-bu - PC Soccer Hen (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xDE8AF1C1, "Ninja Spirit (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x85D1E33B, "Ninja Spirit (USA) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x61B5B8D9, "Ookami-teki Monshou - Crest of Wolf (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x740491C2, "PC Denjin - Punkic Cyborgs (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x51982CE2, "PC Denjin - Punkic Cyborgs (J) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xDAE8F28D, "Riot Zone (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x0590A156, "Saigou no Nindou - Ninja Spirit (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x5ECBB3AC, "Saigou no Nindou - Ninja Spirit (J) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xBC655CF3, "Shinobi (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x616EA179, "Silent Debuggers (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xFA7E5D66, "Silent Debuggers (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0x8420B12B, "Soldier Blade (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x4BB68B13, "Soldier Blade (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xF39F38ED, "Soldier Blade (J) [Special - Caravan Stage] ", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x1D8701C9, "Soldier Blade (J) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xD2113BF1, "Soldier Blade (USA) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x9DB3C8C7, "Special Criminal Investigation (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x23162307, "Spriggan Mark 2 - Re Terraform Project (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x5D0E3105, "Super Star Soldier (J)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xDB29486F, "Super Star Soldier (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x71A5A90B, "Super Star Soldier (J) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x0FCA781A, "Super Star Soldier (USA) [Wii U]", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0xEB045EDF, "Turrican (USA)", GG_GAMEDB_AVENUE_PAD_3_SELECT, 0 },
    { 0x30D42007, "Valis III (J)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },
    { 0xD77DACCE, "Valis III (USA)", GG_GAMEDB_AVENUE_PAD_3_RUN, 0 },

    // MB128 REQUIRED
    { 0xF12521E2, "A.III. - A Ressha de Ikou III (J)", GG_GAMEDB_MB128, 0 },
    { 0x5BE0579C, "Aoki Ookami to Shiroki Mejika - Genchou Hishi (J)", GG_GAMEDB_MB128, 0 },
    { 0x04EAAFE4, "Eikan wa Kimi ni - Koukou Yakyuu Zenkoku Taikai (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0xDBD015F9, "Nobunaga no Yabou - Bushou Fuuunroku (J)", GG_GAMEDB_MB128, 0 },
    { 0x3CF9B1FE, "Nobunaga no Yabou - Zenkokuban (J)", GG_GAMEDB_MB128, 0 },
    { 0x7F4CB0C0, "Sangokushi III (J)", GG_GAMEDB_MB128, 0 },
    { 0x5E9F63A9, "The Atlas - Renaissance Voyager (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },

    // MB128 COMPATIBLE
    { 0x05B6E0FA, "Bishoujo Senshi Sailor Moon Collection (J)", GG_GAMEDB_MB128, 0 },
    { 0x771A3258, "Brandish (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0x367DE1F4, "Magicoal (J)", GG_GAMEDB_MB128, 0 },
    { 0xDC2760EA, "Princess Maker 2 (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0x655C319F, "Private Eye dol (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0x9B8A510C, "Shin Megami Tensei (J)", GG_GAMEDB_MB128, 0 },
    { 0xF6980283, "Super Mahjong Taikai (J)", GG_GAMEDB_MB128, 0 },
    { 0x16D344D4, "Super Real Mahjong PII·III Custom (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0x42A6B864, "Super Real Mahjong P.V Custom (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },
    { 0x86F2C397, "Tadaima Yuusha Boshuu-chuu (J)", GG_GAMEDB_MB128, 0 },
    { 0x38DD30EB, "Vasteel 2 (J)", GG_GAMEDB_ARCADE_CARD | GG_GAMEDB_MB128, 0 },

    {0, 0, 0, 0}
};

#endif /* GAME_DB_H */