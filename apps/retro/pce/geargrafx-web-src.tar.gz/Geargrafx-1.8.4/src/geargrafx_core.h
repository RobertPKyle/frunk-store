/*
 * Geargrafx - PC Engine / TurboGrafx Emulator
 * Copyright (C) 2024  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef GEARGRAFX_CORE_H
#define GEARGRAFX_CORE_H

#include <iostream>
#include <fstream>
#include "common.h"
#include "turbolink.h"

class Audio;
class Input;
class HuC6260;
class HuC6270;
class HuC6280;
class HuC6202;
class Memory;
class Media;
class CdRom;
class CdRomMedia;
class CdRomAudio;
class Adpcm;
class ScsiController;
class Random;
class TraceLogger;
class Profiler;
class LaserActive;

class GeargrafxCore
{
public:

    struct GG_Debug_Run
    {
        bool step_debugger;
        bool stop_on_breakpoint;
        bool stop_on_run_to_breakpoint;
        bool stop_on_irq;
        bool stop_on_brk;
        u8 brk_value;
        bool brk_trigger_irq;
    };

public:
    GeargrafxCore();
    ~GeargrafxCore();
    void Init(GG_Input_Pump_Fn input_pump_fn, GG_Pixel_Format pixel_format = GG_PIXEL_RGBA8888);
    bool RunToVBlank(u8* frame_buffer, s16* sample_buffer, int* sample_count, GG_Debug_Run* debug = NULL, bool render = true);
    bool LoadMedia(const char* file_path, bool softpatching = false);
#if defined(GG_ENABLE_PHYSICAL_CDROM)
    bool LoadPhysicalCdRom(const char* device_id);
#endif
    bool LoadHuCardFromBuffer(const u8* buffer, int size, const char* path = NULL);
    bool LoadBios(const char* file_path, bool syscard);
    bool LoadBiosFromBuffer(const u8* buffer, int size, bool syscard);
    bool LoadPacBios(const char* file_path, GG_LaserActive_Region region);
    bool LoadPacBiosFromBuffer(const u8* buffer, int size, GG_LaserActive_Region region);
    void UnloadBios(bool syscard);
    void UnloadPacBios(GG_LaserActive_Region region);
    void SetLaserActiveRegion(GG_LaserActive_Region region);
    bool EjectLaserDisc();
    bool InsertLaserDisc();
    bool SelectLaserDiscMedia(u32 index);
    void ResetMedia(bool preserve_ram);
    void KeyPressed(GG_Controllers controller, GG_Keys key);
    void KeyReleased(GG_Controllers controller, GG_Keys key);
    void Pause(bool paused);
    bool IsPaused();
    void SaveRam();
    void SaveRam(const char* path, bool full_path = false);
    void LoadRam();
    void LoadRam(const char* path, bool full_path = false);
    void SaveMB128(const char* path, bool full_path = false);
    void LoadMB128(const char* path, bool full_path = false);
    void EnableMB128(GG_MB128_Mode mode);
    void SetPSGRevision(GG_PSG_Revision revision);
    void SetADPCMClockSpeed(float clock_speed);
    bool SaveState(const char* path = NULL, int index = -1, bool screenshot = false);
    bool SaveState(u8* buffer, size_t& size, bool screenshot = false);
    bool LoadState(const char* path = NULL, int index = -1);
    bool LoadState(const u8* buffer, size_t size);
    bool GetSaveStateHeader(int index, const char* path, GG_SaveState_Header* header);
    bool GetSaveStateScreenshot(int index, const char* path, GG_SaveState_Screenshot* screenshot);
    bool GetRuntimeInfo(GG_Runtime_Info& runtime_info);
    Memory* GetMemory();
    Media* GetMedia();
    HuC6202* GetHuC6202();
    HuC6260* GetHuC6260();
    HuC6270* GetHuC6270_1();
    HuC6270* GetHuC6270_2();
    HuC6280* GetHuC6280();
    CdRom* GetCDROM();
    CdRomMedia* GetCDROMMedia();
    CdRomAudio* GetCDROMAudio();
    ScsiController* GetScsiController();
    Adpcm* GetAdpcm();
    Audio* GetAudio();
    Input* GetInput();
    u64 GetMasterClockCycles();
    void SetTurboLinkCallbacks(
        GG_TurboLink_Publish_Callback publish_callback, GG_TurboLink_Sample_Callback sample_callback,
        GG_TurboLink_Sync_Callback sync_callback, void* user_data);
    void SetTurboLinkCableConnected(bool connected);
    void InvalidateTurboLinkSample();
    u64 GetTurboLinkCycle() const;
    GG_TurboLink_Drive GetTurboLinkDrive() const;
    TraceLogger* GetTraceLogger();
    Profiler* GetProfiler();
    LaserActive* GetLaserActive();

private:
    void Reset();
    void SelectPSGRevision();
    void SelectADPCMClockSpeed();
    template<bool is_cdrom, bool is_sgx, bool is_laseractive>
    bool ClockHardware(u32 cycles);
    template<bool is_cdrom, bool is_sgx, bool is_laseractive>
    static void ClockHardwareCallback(void* context, u32 cycles);
    template<bool debugger, bool is_cdrom, bool is_sgx, bool is_laseractive = false>
    bool RunToVBlankTemplate(u8* frame_buffer, s16* sample_buffer, int* sample_count, GG_Debug_Run* debug, bool render);
    bool SaveState(std::ostream& stream, size_t& size, bool screenshot);
    bool LoadState(std::istream& stream);
    bool LoadStateTail(std::istream& stream, u32 version, bool has_mb128_flag, size_t end);
    std::string GetSaveStatePath(const char* path, int index);

private:
    Memory* m_memory;
    HuC6202* m_huc6202;
    HuC6260* m_huc6260;
    HuC6270* m_huc6270_1;
    HuC6270* m_huc6270_2;
    HuC6280* m_huc6280;
    Audio* m_audio;
    Input* m_input;
    Media* m_media;
    CdRom* m_cdrom;
    CdRomMedia* m_cdrom_media;
    CdRomAudio* m_cdrom_audio;
    Adpcm* m_adpcm;
    ScsiController* m_scsi_controller;
    Random* m_random;
    LaserActive* m_laseractive;
    bool m_paused;
    TraceLogger* m_trace_logger;
    Profiler* m_profiler;
    u64 m_master_clock_cycles;
    u64 m_turbolink_cycles;
    u64 m_turbolink_next_sync_cycle;
    bool m_frame_ready;
    GG_MB128_Mode m_mb128_mode;
    GG_PSG_Revision m_requested_psg_revision;
    GG_PSG_Revision m_psg_revision;
    float m_requested_adpcm_clock_speed;
};

#include "geargrafx_core_inline.h"

#endif /* GEARGRAFX_CORE_H */
