/*
 * Gearsystem - Sega Master System / Game Gear Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef MEMORYRULE_H
#define	MEMORYRULE_H

#include "definitions.h"
#include "TraceLogger.h"
#include "Cartridge.h"

class Memory;
class Input;

class MemoryRule
{
public:
    MemoryRule(Memory* pMemory, Cartridge* pCartridge, Input* pInput);
    void SetTraceLogger(TraceLogger* pTraceLogger);
    virtual ~MemoryRule();
    virtual u8 PerformRead(u16 address) = 0;
    virtual void PerformWrite(u16 address, u8 value) = 0;
    virtual void Reset() = 0;
    virtual void SaveRam(std::ostream &file);
    virtual bool LoadRam(std::istream &file, s32 fileSize);
    virtual bool PersistedRAM();
    virtual size_t GetRamSize();
    virtual u8* GetRamBanks();
    virtual int GetRamBank();
    virtual u8* GetPage(int index);
    virtual int GetBank(int index);
    virtual bool Has8kBanks();
    virtual void SaveState(std::ostream& stream);
    virtual void LoadState(std::istream& stream, int version = GS_SAVESTATE_VERSION);

protected:
    INLINE void TraceBankSwitchEvent(u16 address, u8 value, u8 flags = 0, u16 auxiliary = 0);
    INLINE void TraceMapperEvent(u8 event, u16 address, u8 value, u8 flags = 0, u16 auxiliary = 0);
    void LogBankSwitchEvent(u16 address, u8 value, u8 flags, u16 auxiliary);
    void LogMapperEvent(u8 event, u16 address, u8 value, u8 flags, u16 auxiliary);
    void PopulateMapperTraceEntry(GS_Trace_Entry& entry, u8 event, u16 address, u8 value, u8 flags, u16 auxiliary);

    Memory* m_pMemory;
    Cartridge* m_pCartridge;
    Input* m_pInput;
    TraceLogger* m_pTraceLogger;
};

INLINE void MemoryRule::TraceBankSwitchEvent(u16 address, u8 value, u8 flags, u16 auxiliary)
{
    if (m_pTraceLogger->IsEnabled(TRACE_MAPPER))
        LogBankSwitchEvent(address, value, flags, auxiliary);
}

INLINE void MemoryRule::TraceMapperEvent(u8 event, u16 address, u8 value, u8 flags, u16 auxiliary)
{
    if (m_pTraceLogger->IsEventEnabled(TRACE_MAPPER, event))
        LogMapperEvent(event, address, value, flags, auxiliary);
}

#endif	/* MEMORYRULE_H */
