#ifndef YM2413_H
#define YM2413_H

#include "definitions.h"
#include "log.h"
#include "audio/emu2413/emu2413.h"

class YM2413
{

public:
    YM2413();
    ~YM2413();

    void Init(int clockRate);
    void Reset(int clockRate);
    void Write(u8 port, u8 value);
    u8 Read();
    u8 GetSelectedRegister() const;
    void Tick(unsigned int clockCycles);
    int EndFrame(s16* pSampleBuffer);
    void Enable(bool bEnabled);
    void SaveState(std::ostream& stream);
    void LoadState(std::istream& stream, int version);
    void LoadStateV1(std::istream& stream);

private:
    INLINE void WriteSample(s16 sample);
    void Sync();

private:
    int m_iCycleCounter;
    int m_iSampleCounter;
    int m_iSampleRateFactor;
    s16* m_pBuffer;
    int m_iBufferIndex;
    int m_ElapsedCycles;
    int m_iClockRate;
    u8 m_RegisterF2;
    s16 m_CurrentSample;
    bool m_bEnabled;
};

const int kYM2413SampleAccuracy = 16;

#endif	/* YM2413_H */
