/*
 * Gearlynx - Lynx Emulator
 * Copyright (C) 2025  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef DEFINES_H
#define DEFINES_H

#if !defined(EMULATOR_BUILD)
    #define EMULATOR_BUILD "undefined"
#endif

#define GLYNX_VERSION EMULATOR_BUILD

#define GLYNX_TITLE "Gearlynx"
#define GLYNX_TITLE_ASCII "" \
"   ____                 _                  \n" \
"  / ___| ___  __ _ _ __| |_   _ _ __ __  __\n" \
" | |  _ / _ \\/ _` | '__| | | | | '_ \\\\ \\/ /\n" \
" | |_| |  __/ (_| | |  | | |_| | | | |>  < \n" \
"  \\____|\\___|\\__,_|_|  |_|\\__, |_| |_/_/\\_\\\n" \
"                          |___/            \n"

#if defined(DEBUG)
    #define GLYNX_DEBUG 1
#endif

#define GLYNX_SCREEN_WIDTH 160
#define GLYNX_SCREEN_HEIGHT 102

#define GLYNX_MASTER_CLOCK 16000000
#define GLYNX_AUDIO_SAMPLE_RATE 44100
#define GLYNX_AUDIO_BUFFER_SIZE 2384    // (44100 / 37fps) * 2 channels = ~2383.78 samples
#define GLYNX_AUDIO_QUEUE_SIZE 2384     // (44100 / 37fps) * 2 channels = ~2383.78 samples

#define GLYNX_BIOS_SIZE 0x200

#define GLYNX_SAVESTATE_VERSION 29
#define GLYNX_SAVESTATE_MIN_VERSION 12
#define GLYNX_SAVESTATE_MAGIC 0x56191212

#define GLYNX_DEBUG_MSG_MAX_SIZE 80

#define GLYNX_MAX_CHEATS 256

#if !defined(NULL)
    #define NULL 0
#endif

#define SafeDelete(pointer) if(pointer != NULL) {delete pointer; pointer = NULL;}
#define SafeDeleteArray(pointer) if(pointer != NULL) {delete [] pointer; pointer = NULL;}

#define InitPointer(pointer) ((pointer) = NULL)
#define IsValidPointer(pointer) ((pointer) != NULL)

#define UNUSED(expr) (void)(expr)

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define CLAMP(value, min, max) MIN(MAX(value, min), max)

#if defined(MSB_FIRST) || defined(__BIG_ENDIAN__) || (defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    #define GLYNX_BIG_ENDIAN
#else
    #define GLYNX_LITTLE_ENDIAN
#endif

#if defined(__GNUC__) || defined(__clang__)
    #define INLINE inline __attribute__((always_inline))
    #define NO_INLINE __attribute__((noinline))
#elif defined(_MSC_VER)
    #define INLINE __forceinline
    #define NO_INLINE __declspec(noinline)
#else
    #define INLINE inline
    #define NO_INLINE
#endif

#if !defined(GLYNX_DEBUG)
    #if defined(__GNUC__) || defined(__clang__)
        #if !defined(__OPTIMIZE__) && !defined(__OPTIMIZE_SIZE__)
            #warning "Compiling without optimizations."
            #define GLYNX_NO_OPTIMIZATIONS
        #endif
    #elif defined(_MSC_VER)
        #if !defined(NDEBUG)
            #pragma message("Compiling without optimizations.")
            #define GLYNX_NO_OPTIMIZATIONS
        #endif
    #endif
#endif

#if defined(__GNUC__) || defined(__clang__)
    #define likely(x)   __builtin_expect(!!(x), 1)
    #define unlikely(x) __builtin_expect(!!(x), 0)
#else
    #define likely(x)   (x)
    #define unlikely(x) (x)
#endif

#if defined(__has_cpp_attribute)
  #if __has_cpp_attribute(fallthrough)
    #define FALLTHROUGH [[fallthrough]]
  #elif __has_cpp_attribute(clang::fallthrough)
    #define FALLTHROUGH [[clang::fallthrough]]
  #elif __has_cpp_attribute(gnu::fallthrough)
    #define FALLTHROUGH [[gnu::fallthrough]]
  #endif
#endif

// MSVC older toolsets
#ifndef FALLTHROUGH
  #if defined(_MSC_VER) && !defined(__clang__)
    #include <sal.h>
    #ifdef __fallthrough
      #define FALLTHROUGH __fallthrough
    #else
      #define FALLTHROUGH ((void)0) /* fall through */
    #endif
  #else
    // Safe no-op for compilers without a recognized attribute
    #define FALLTHROUGH ((void)0) /* fall through */
  #endif
#endif

#endif /* DEFINES_H */
