#include "bus-main-m68k.h"

#include <assert.h>

#include "bus-sub-m68k.h"
#include "bus-z80.h"
#include "io-port.h"
#include "log.h"

/* The Z80 can trigger 68k bus errors by using the 68k address space window, so print its program counter here too. */
#define LOG_MAIN_CPU_BUS_ERROR_MESSAGE_PREFIX "[M68K PC: 0x%06" CC_PRIXLEAST32 ", Z80 PC: 0x%04" CC_PRIXLEAST16 "] "
#define LOG_MAIN_CPU_BUS_ERROR_ARGUMENTS clownmdemu->m68k.program_counter, clownmdemu->z80.program_counter
#define LOG_MAIN_CPU_BUS_ERROR_0(MESSAGE)                   LogMessage(LOG_MAIN_CPU_BUS_ERROR_MESSAGE_PREFIX MESSAGE, LOG_MAIN_CPU_BUS_ERROR_ARGUMENTS);
#define LOG_MAIN_CPU_BUS_ERROR_1(MESSAGE, ARG1)             LogMessage(LOG_MAIN_CPU_BUS_ERROR_MESSAGE_PREFIX MESSAGE, LOG_MAIN_CPU_BUS_ERROR_ARGUMENTS, ARG1);
#define LOG_MAIN_CPU_BUS_ERROR_2(MESSAGE, ARG1, ARG2)       LogMessage(LOG_MAIN_CPU_BUS_ERROR_MESSAGE_PREFIX MESSAGE, LOG_MAIN_CPU_BUS_ERROR_ARGUMENTS, ARG1, ARG2);
#define LOG_MAIN_CPU_BUS_ERROR_3(MESSAGE, ARG1, ARG2, ARG3) LogMessage(LOG_MAIN_CPU_BUS_ERROR_MESSAGE_PREFIX MESSAGE, LOG_MAIN_CPU_BUS_ERROR_ARGUMENTS, ARG1, ARG2, ARG3);

/* https://github.com/Clownacy/clownmdemu-mcd-boot */
static const cc_u16l megacd_boot_rom[] = {
#include "mega-cd-boot-rom.c"
};

/* Super useful reference for HV counter and interrupt timings. */
/* http://gendev.spritesmind.net/forum/viewtopic.php?p=35660#p35660 */
/* https://gendev.spritesmind.net/forum/viewtopic.php?p=8201#p8201 */
/* https://gendev.spritesmind.net/forum/viewtopic.php?t=787 */

/* Nemesis' HV counter tables are very important for understanding this H-counter stuff */
/*
Analog screen sections in relation to HCounter (H32 mode):
-----------------------------------------------------------------
| Screen section | HCounter  |Pixel| Pixel |Serial|Serial |MCLK |
| (PAL/NTSC H32) |  value    |clock| clock |clock |clock  |ticks|
|                |           |ticks|divider|ticks |divider|     |
|----------------|-----------|-----|-------|------|-------|-----|
|Left border     |0x00B-0x017|  13 |SCLK/2 |   26 |MCLK/5 | 130 |
|----------------|-----------|-----|-------|------|-------|-----|
|Active display  |0x018-0x117| 256 |SCLK/2 |  512 |MCLK/5 |2560 |
|----------------|-----------|-----|-------|------|-------|-----|
|Right border    |0x118-0x125|  14 |SCLK/2 |   28 |MCLK/5 | 140 |
|----------------|-----------|-----|-------|------|-------|-----|
|Front porch     |0x126-0x127|   9 |SCLK/2 |   18 |MCLK/5 |  90 |
|(Right Blanking)|0x1D2-0x1D8|     |       |      |       |     |
|----------------|-----------|-----|-------|------|-------|-----|
|Horizontal sync |0x1D9-0x1F2|  26 |SCLK/2 |   52 |MCLK/5 | 260 |
|----------------|-----------|-----|-------|------|-------|-----|
|Back porch      |0x1F3-0x00A|  24 |SCLK/2 |   48 |MCLK/5 | 240 |
|(Left Blanking) |           |     |       |      |       |     |
|----------------|-----------|-----|-------|------|-------|-----|
|TOTALS          |           | 342 |       |  684 |       |3420 |
-----------------------------------------------------------------

Analog screen sections in relation to HCounter (H40 mode):
--------------------------------------------------------------------
| Screen section |   HCounter    |Pixel| Pixel |EDCLK| EDCLK |MCLK |
| (PAL/NTSC H40) |    value      |clock| clock |ticks|divider|ticks|
|                |               |ticks|divider|     |       |     |
|----------------|---------------|-----|-------|-----|-------|-----|
|Left border     |0x00D-0x019    |  13 |EDCLK/2|  26 |MCLK/4 | 104 |
|----------------|---------------|-----|-------|-----|-------|-----|
|Active display  |0x01A-0x159    | 320 |EDCLK/2| 640 |MCLK/4 |2560 |
|----------------|---------------|-----|-------|-----|-------|-----|
|Right border    |0x15A-0x167    |  14 |EDCLK/2|  28 |MCLK/4 | 112 |
|----------------|---------------|-----|-------|-----|-------|-----|
|Front porch     |0x168-0x16C    |   9 |EDCLK/2|  18 |MCLK/4 |  72 |
|(Right Blanking)|0x1C9-0x1CC    |     |       |     |       |     |
|----------------|---------------|-----|-------|-----|-------|-----|
|Horizontal sync |0x1CD.0-0x1D4.5| 7.5 |EDCLK/2|  15 |MCLK/5 |  75 |
|                |0x1D4.5-0x1D5.5|   1 |EDCLK/2|   2 |MCLK/4 |   8 |
|                |0x1D5.5-0x1DC.0| 7.5 |EDCLK/2|  15 |MCLK/5 |  75 |
|                |0x1DD.0        |   1 |EDCLK/2|   2 |MCLK/4 |   8 |
|                |0x1DE.0-0x1E5.5| 7.5 |EDCLK/2|  15 |MCLK/5 |  75 |
|                |0x1E5.5-0x1E6.5|   1 |EDCLK/2|   2 |MCLK/4 |   8 |
|                |0x1E6.5-0x1EC.0| 6.5 |EDCLK/2|  13 |MCLK/5 |  65 |
|                |===============|=====|=======|=====|=======|=====|
|        Subtotal|0x1CD-0x1EC    | (32)|       | (64)|       |(314)|
|----------------|---------------|-----|-------|-----|-------|-----|
|Back porch      |0x1ED          |   1 |EDCLK/2|   2 |MCLK/5 |  10 |
|(Left Blanking) |0x1EE-0x00C    |  31 |EDCLK/2|  62 |MCLK/4 | 248 |
|                |===============|=====|=======|=====|=======|=====|
|        Subtotal|0x1ED-0x00C    | (32)|       | (64)|       |(258)|
|----------------|---------------|-----|-------|-----|-------|-----|
|TOTALS          |               | 420 |       | 840 |       |3420 |
--------------------------------------------------------------------
*/

static cc_u16f GetHCounterValue(const ClownMDEmu* const clownmdemu, const CycleMegaDrive target_cycle)
{
	/* TODO: This entire thing is a disgusting hack. */
	/* Once the VDP emulator becames slot-based, this junk should be erased. */
	const cc_bool h40 = clownmdemu->vdp.state.h40_enabled;
	const cc_u16f range = h40 ? 420 : 342;
	const cc_u16f start = h40 ? 0x15A : 0x10A; /* The emulated scanline begins directly at the end of active display. */
	const cc_u16f jump_from = h40 ? 0x16D : 0x128;
	const cc_u16f jump_to = h40 ? 0x1C9 : 0x1D2;

	const cc_u16f cycles_per_scanline = GetMegaDriveCyclesPerFrame(clownmdemu).cycle / GetTelevisionVerticalResolution(clownmdemu);

	cc_u16f value = target_cycle.cycle % cycles_per_scanline;

	/* Convert from master cycles to VDP pixels. */
	if (h40)
	{
		/* Big pain in the ass!!! */
		/* TODO: This table is a headache: break it down to make more sense. */
		static const cc_u16l cycles[][2] = {
			/* Remember: 0x15A is the start! */
			{((0x1CD - 0x15A) - (0x1C9 - 0x16D)) * 2, 4},
			{15, 5},
			{ 2, 4},
			{15, 5},
			{ 2, 4},
			{15, 5},
			{ 2, 4},
			{13, 5},
			{ 2, 5},
			{62, 4},
			{(0x15A - 0xD)  * 2, 4},
			/* The left column should total 840. */
		};

		cc_u16f countdown = value;
		cc_u8f i;

		value = 0;

		for (i = 0; ; ++i)
		{
			if (countdown < cycles[i][0] * cycles[i][1])
			{
				value += countdown / cycles[i][1];
				break;
			}

			countdown -= cycles[i][0] * cycles[i][1];
			value += cycles[i][0];
		}

		/* Convert from EDCLK ticks to pixels. */
		value /= 2;
	}
	else
	{
		value /= 5 * 2;
	}

	value = (start + value) % range;

	/* There's a 'gap' in the H-counter values, so handle that here. */
	if (value >= jump_from)
		value = (value + (jump_to - jump_from)) % 0x200;

	return value;
}

static cc_bool GetHBlankBit(const ClownMDEmu* const clownmdemu, const CycleMegaDrive target_cycle)
{
	const cc_u16f h_counter = GetHCounterValue(clownmdemu, target_cycle);
	const cc_bool h40 = clownmdemu->vdp.state.h40_enabled;

	/* Before left border or after active display. */
	/* TODO: Use constants for this crap... */
	if (h40)
		return h_counter < 0xD || h_counter > 0x159;
	else
		return h_counter < 0xB || h_counter > 0x117;
}

static cc_bool MegaCDEnabled(const ClownMDEmu* const clownmdemu)
{
	return clownmdemu->state.mega_cd.cd_inserted || clownmdemu->configuration.cd_add_on_enabled;
}

static cc_u16f GetDMATransferBytesPerScanline(ClownMDEmu* const clownmdemu)
{
	/* TODO: Does this actually count the part between the final rendered scanline (224) and V-Int as 'display off'? */
	if (clownmdemu->vdp.state.currently_in_vblank || !clownmdemu->vdp.state.display_enabled)
	{
		/* Blanking */
		if (clownmdemu->vdp.state.h40_enabled)
			return VDP_H40_DMA_BYTES_PER_LINE_DISPLAY_OFF;
		else
			return VDP_H32_DMA_BYTES_PER_LINE_DISPLAY_OFF;
	}
	else
	{
		/* Active display */
		if (clownmdemu->vdp.state.h40_enabled)
			return VDP_H40_DMA_BYTES_PER_LINE_DISPLAY_ON;
		else
			return VDP_H32_DMA_BYTES_PER_LINE_DISPLAY_ON;
	}
}

static void VDPDMATransferBeginCallback(void *const user_data, const cc_u32f total_reads, const cc_u32f target_cycle)
{
	CPUCallbackUserData* const callback_user_data = (CPUCallbackUserData*)user_data;
	ClownMDEmu* const clownmdemu = callback_user_data->clownmdemu;
	const CycleMegaDrive cycles_per_scanline = GetMegaDriveCyclesPerScanline(clownmdemu);

	/* Make the 68k emulator loop bail as soon as possible, so that the CPU will freeze at a near-accurate time. */
	*callback_user_data->m68k_terminate_early = cc_true;

	/* Bring the Z80 up-to-date, before we lock its bus. */
	SyncZ80(clownmdemu, callback_user_data, MakeCycleMegaDrive(target_cycle));

	/* For the duration of the DMA transfer, the 68k's bus is in use by the VDP. This freezes the CPU. */
	clownmdemu->state.vdp_dma_transfer_countdown = cycles_per_scanline.cycle * total_reads / GetDMATransferBytesPerScanline(clownmdemu);
	clownmdemu->state.m68k.frozen_by_dma_transfer = cc_true;
}

static cc_u16f VDPReadCallback(void* const user_data, const cc_u32f address, const cc_u32f target_cycle)
{
	return M68kReadCallbackWithCycleWithDMA(user_data, address / 2, cc_true, cc_true, NULL, MakeCycleMegaDrive(target_cycle), cc_true);
}

static void VDPKDebugCallback(void* const user_data, const char* const string)
{
	(void)user_data;

	LogMessage("KDEBUG: %s", string);
}

void M68kInterruptAcknowledgeCallback(const void* const user_data)
{
	CPUCallbackUserData* const other_state = (CPUCallbackUserData*)user_data;
	ClownMDEmu* const clownmdemu = other_state->clownmdemu;
	ClownMDEmu_State* const state = &clownmdemu->state;

	/* The 68000 does not report which interrupt it is acknowledging, leading to a
	   bug where if H-Int and V-Int are enabled in quick succession, the Mega Drive
	   will think the 68000 acknowledged the V-Int instead of the H-Int, causing
	   V-Int to be missed and H-Int to be raised twice. */
	if (state->m68k.v_int_pending && clownmdemu->vdp.state.v_int_enabled)
		state->m68k.v_int_pending = cc_false;
	else if (state->m68k.h_int_pending && clownmdemu->vdp.state.h_int_enabled)
		state->m68k.h_int_pending = cc_false;

	Clown68000_Interrupt(&clownmdemu->m68k, state->m68k.h_int_pending && clownmdemu->vdp.state.h_int_enabled ? 4 : 0);
}

static cc_u32f SyncM68kCallbackIterate(CPUCallbackUserData* const other_state, const cc_u32f total_cycles)
{
	ClownMDEmu* const clownmdemu = other_state->clownmdemu;

	/* To simulate the CPU being frozen and unfrozen by DMA transfers, we hijack this function. */
	if (clownmdemu->state.m68k.frozen_by_dma_transfer)
	{
		const cc_u32f cycles_to_do = CC_MIN(total_cycles, clownmdemu->state.vdp_dma_transfer_countdown);

		clownmdemu->state.vdp_dma_transfer_countdown -= cycles_to_do;

		if (clownmdemu->state.vdp_dma_transfer_countdown == 0)
		{
			/* Update the Z80 to this point in time. */
			SyncZ80(clownmdemu, other_state, MakeCycleMegaDrive(other_state->sync.m68k.current_cycle + cycles_to_do));

			/* Stop hogging the CPU bus. */
			clownmdemu->state.m68k.frozen_by_dma_transfer = cc_false;
			clownmdemu->state.z80.frozen_by_dma_transfer = cc_false;
		}

		return cycles_to_do;
	}
	else
	{
		Clown68000_ReadWriteCallbacks m68k_read_write_callbacks;

		m68k_read_write_callbacks.read_callback = M68kReadCallback;
		m68k_read_write_callbacks.write_callback = M68kWriteCallback;
		m68k_read_write_callbacks.interrupt_acknowledge_callback = M68kInterruptAcknowledgeCallback;
		m68k_read_write_callbacks.user_data = other_state;

		return Clown68000_DoCycles(&clownmdemu->m68k, &m68k_read_write_callbacks, CC_DIVIDE_CEILING(total_cycles, CLOWNMDEMU_M68K_CLOCK_DIVIDER)) * CLOWNMDEMU_M68K_CLOCK_DIVIDER;
	}
}

static cc_u32f SyncM68kCallback(void* const user_data, const cc_u32f total_cycles)
{
	CPUCallbackUserData* const other_state = (CPUCallbackUserData*)user_data;

	cc_u32f total_cycles_done = 0;

	do
	{
		const cc_u32f cycles_done = SyncM68kCallbackIterate(other_state, total_cycles - total_cycles_done);

		total_cycles_done += cycles_done;
		other_state->sync.m68k.current_cycle += cycles_done;
	}
	while (total_cycles_done < total_cycles);

	return total_cycles_done;
}

void SyncM68k(ClownMDEmu* const clownmdemu, CPUCallbackUserData* const other_state, const CycleMegaDrive target_cycle)
{
	Sync_Update(&clownmdemu->state.sync.m68k, &other_state->sync.m68k, target_cycle.cycle, SyncM68kCallback, other_state);
}

static cc_u32f GetBankedCartridgeAddress(const ClownMDEmu* const clownmdemu, const cc_u32f address)
{
	const cc_u32f masked_address = address & 0x3FFFFF;
	const cc_u32f bank_size = 512 * 1024; /* 512KiB */
	const cc_u32f bank_index = masked_address / bank_size;
	const cc_u32f bank_offset = masked_address % bank_size;
	return clownmdemu->state.cartridge_bankswitch[bank_index] * bank_size + bank_offset;
}

static cc_bool FrontendControllerCallback(void* const user_data, const cc_u8f controller_index, const Controller_Button button)
{
	ClownMDEmu_Button frontend_button;

	const ClownMDEmu_Callbacks* const frontend_callbacks = (const ClownMDEmu_Callbacks*)user_data;

	switch (button)
	{
		case CONTROLLER_BUTTON_UP:
			frontend_button = CLOWNMDEMU_BUTTON_UP;
			break;

		case CONTROLLER_BUTTON_DOWN:
			frontend_button = CLOWNMDEMU_BUTTON_DOWN;
			break;

		case CONTROLLER_BUTTON_LEFT:
			frontend_button = CLOWNMDEMU_BUTTON_LEFT;
			break;

		case CONTROLLER_BUTTON_RIGHT:
			frontend_button = CLOWNMDEMU_BUTTON_RIGHT;
			break;

		case CONTROLLER_BUTTON_A:
			frontend_button = CLOWNMDEMU_BUTTON_A;
			break;

		case CONTROLLER_BUTTON_B:
			frontend_button = CLOWNMDEMU_BUTTON_B;
			break;

		case CONTROLLER_BUTTON_C:
			frontend_button = CLOWNMDEMU_BUTTON_C;
			break;

		case CONTROLLER_BUTTON_X:
			frontend_button = CLOWNMDEMU_BUTTON_X;
			break;

		case CONTROLLER_BUTTON_Y:
			frontend_button = CLOWNMDEMU_BUTTON_Y;
			break;

		case CONTROLLER_BUTTON_Z:
			frontend_button = CLOWNMDEMU_BUTTON_Z;
			break;

		case CONTROLLER_BUTTON_START:
			frontend_button = CLOWNMDEMU_BUTTON_START;
			break;

		case CONTROLLER_BUTTON_MODE:
			frontend_button = CLOWNMDEMU_BUTTON_MODE;
			break;

		default:
			assert(cc_false);
			return cc_false;
	}

	return frontend_callbacks->input_requested((void*)frontend_callbacks->user_data, controller_index, frontend_button);
}

static cc_u8f IOPortToController_ReadCallback(void* const user_data, const cc_u16f cycles)
{
	const IOPortToController_Parameters *parameters = (const IOPortToController_Parameters*)user_data;
	ClownMDEmu* const clownmdemu = parameters->clownmdemu;

	return ControllerManager_Read(&clownmdemu->controller_manager, parameters->joypad_index, cycles, FrontendControllerCallback, clownmdemu->callbacks);
}

static void IOPortToController_WriteCallback(void* const user_data, const cc_u8f value, const cc_u16f cycles)
{
	const IOPortToController_Parameters *parameters = (const IOPortToController_Parameters*)user_data;
	ClownMDEmu* const clownmdemu = parameters->clownmdemu;

	ControllerManager_Write(&clownmdemu->controller_manager, parameters->joypad_index, cycles, value);
}

cc_u8f SyncIOPortAndRead(CPUCallbackUserData* const callback_user_data, const CycleMegaDrive target_cycle, const cc_u16f joypad_index)
{
	IOPortToController_Parameters parameters;

	ClownMDEmu* const clownmdemu = callback_user_data->clownmdemu;
	const IOPort_ReadCallback read_callback = joypad_index < 2 ? IOPortToController_ReadCallback : NULL;

	parameters.clownmdemu = clownmdemu;
	parameters.joypad_index = joypad_index;

	return IOPort_ReadData(&clownmdemu->state.io_ports[joypad_index], SyncCommon(&callback_user_data->sync.io_ports[joypad_index], target_cycle.cycle, CLOWNMDEMU_MASTER_CLOCK_NTSC / 1000000), read_callback, &parameters);
}

void SyncIOPortAndWrite(CPUCallbackUserData* const callback_user_data, const CycleMegaDrive target_cycle, const cc_u16f joypad_index, const cc_u8f value)
{
	IOPortToController_Parameters parameters;

	ClownMDEmu* const clownmdemu = callback_user_data->clownmdemu;
	const IOPort_WriteCallback write_callback = joypad_index < 2 ? IOPortToController_WriteCallback : NULL;

	parameters.clownmdemu = clownmdemu;
	parameters.joypad_index = joypad_index;

	IOPort_WriteData(&clownmdemu->state.io_ports[joypad_index], value, SyncCommon(&callback_user_data->sync.io_ports[joypad_index], target_cycle.cycle, CLOWNMDEMU_MASTER_CLOCK_NTSC / 1000000), write_callback, &parameters);
}

cc_u16f M68kReadCallbackWithCycleWithDMA(const void* const user_data, const cc_u32f address_word, const cc_bool do_high_byte, const cc_bool do_low_byte, cc_bool* const terminate_early, const CycleMegaDrive target_cycle, const cc_bool is_vdp_dma)
{
	CPUCallbackUserData* const callback_user_data = (CPUCallbackUserData*)user_data;
	ClownMDEmu* const clownmdemu = callback_user_data->clownmdemu;
	const cc_u32f address = address_word * 2;

	/* TODO: Check if this is the correct value. */
	cc_u16f value = 0;

	callback_user_data->m68k_terminate_early = terminate_early;

	switch (address / 0x200000)
	{
		case 0x000000 / 0x200000:
		case 0x200000 / 0x200000:
		case 0x400000 / 0x200000:
		case 0x600000 / 0x200000:
			/* Cartridge, Mega CD. */
			if (((address & 0x400000) != 0) != clownmdemu->state.cartridge_inserted)
			{
				if ((address & 0x200000) != 0 && clownmdemu->state.external_ram.mapped_in)
				{
					/* External RAM */
					const cc_u32f index = address & 0x1FFFFF;

					if (index >= clownmdemu->state.external_ram.size)
					{
						/* TODO: According to Genesis Plus GX, SRAM is actually mirrored past its end. */
						value = 0xFFFF;
						LOG_MAIN_CPU_BUS_ERROR_2("Attempted to read past the end of external RAM (0x%" CC_PRIXFAST32 " when the external RAM ends at 0x%" CC_PRIXLEAST32 ")", index, clownmdemu->state.external_ram.size);
					}
					else
					{
						value |= clownmdemu->state.external_ram.buffer[index + 0] << 8;
						value |= clownmdemu->state.external_ram.buffer[index + 1] << 0;
					}
				}
				else
				{
					/* Cartridge */
					const cc_u32f cartridge_address = GetBankedCartridgeAddress(clownmdemu, address);
					const cc_u32f cartridge_address_word = cartridge_address / 2;

					if (cartridge_address_word >= clownmdemu->cartridge_buffer_length)
					{
						LOG_MAIN_CPU_BUS_ERROR_1("MAIN-CPU attempted to read from beyond the end of the cartridge (offset 0x%" CC_PRIXFAST32 ")", cartridge_address);
					}
					else
					{
						value = clownmdemu->cartridge_buffer[cartridge_address_word];
					}
				}
			}
			else if (MegaCDEnabled(clownmdemu))
			{
				if ((address & 0x200000) != 0)
				{
					/* WORD-RAM */
					if (clownmdemu->state.mega_cd.word_ram.in_1m_mode)
					{
						if ((address & 0x20000) != 0)
						{
							/* TODO */
							LOG_MAIN_CPU_BUS_ERROR_0("MAIN-CPU attempted to read from that weird half of 1M WORD-RAM");
						}
						else
						{
							value = clownmdemu->state.mega_cd.word_ram.buffer[(address_word & 0xFFFF) * 2 + clownmdemu->state.mega_cd.word_ram.ret];
						}
					}
					else
					{
						if (!clownmdemu->state.mega_cd.word_ram.ret)
						{
							LOG_MAIN_CPU_BUS_ERROR_0("MAIN-CPU attempted to read from WORD-RAM while SUB-CPU has it");
						}
						else
						{
							value = clownmdemu->state.mega_cd.word_ram.buffer[address_word & 0x1FFFF];
						}
					}

					if (is_vdp_dma)
					{
						/* Delay WORD-RAM DMA transfers. This is a real bug on the Mega CD that games have to work around. */
						/* This can easily be seen in Sonic CD's FMVs. */
						const cc_u16f delayed_value = value;

						value = clownmdemu->state.mega_cd.delayed_dma_word;
						clownmdemu->state.mega_cd.delayed_dma_word = delayed_value;
					}
				}
				else if ((address & 0x20000) == 0)
				{
					/* Mega CD BIOS */
					if ((address & 0x1FFFF) == 0x72)
					{
						/* The Mega CD has this strange hack in its bug logic, which allows
						   the H-Int interrupt address to be overridden with a register. */
						value = clownmdemu->state.mega_cd.hblank_address;
					}
					else
					{
						value = megacd_boot_rom[address_word & 0xFFFF];
					}
				}
				else
				{
					/* PRG-RAM */
					if (!clownmdemu->state.mega_cd.m68k.bus_requested)
					{
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from PRG-RAM while SUB-CPU has it");
					}
					else
					{
						value = clownmdemu->state.mega_cd.prg_ram.buffer[0x10000 * clownmdemu->state.mega_cd.prg_ram.bank + (address_word & 0xFFFF)];
					}
				}
			}

			break;

		case 0x800000 / 0x200000:
			/* 32X? */
			LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid 68k address 0x%" CC_PRIXFAST32, address);
			break;

		case 0xA00000 / 0x200000:
			/* IO region. */
			switch (address / 0x1000)
			{
				case 0xA00000 / 0x1000:
				case 0xA01000 / 0x1000:
				case 0xA02000 / 0x1000:
				case 0xA03000 / 0x1000:
				case 0xA04000 / 0x1000:
				case 0xA05000 / 0x1000:
				case 0xA06000 / 0x1000:
				case 0xA07000 / 0x1000:
				case 0xA08000 / 0x1000:
				case 0xA09000 / 0x1000:
				case 0xA0A000 / 0x1000:
				case 0xA0B000 / 0x1000:
				case 0xA0C000 / 0x1000:
				case 0xA0D000 / 0x1000:
				case 0xA0E000 / 0x1000:
				case 0xA0F000 / 0x1000:
					/* Z80 RAM and YM2612 */
					if (!clownmdemu->state.z80.bus_requested)
					{
						LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to read Z80 memory/YM2612 ports without Z80 bus");
					}
					else if (clownmdemu->state.z80.reset_held)
					{
						/* TODO: Does this actually bother real hardware? */
						/* TODO: According to Devon, yes it does. */
						LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to read Z80 memory/YM2612 ports while Z80 reset request was active");
					}
					else
					{
						/* This is unnecessary, as the Z80 bus will have to have been requested, causing a sync. */
						/*SyncZ80(clownmdemu, callback_user_data, target_cycle);*/

						if (do_high_byte && do_low_byte)
							LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to perform word-sized read of Z80 memory/YM2612 ports; the read word will only contain the first byte repeated");

						value = Z80ReadCallbackWithCycle(user_data, (address + (do_high_byte ? 0 : 1)) & 0x7FFF, target_cycle);
						value = value << 8 | value;

						/* TODO: This should delay the 68k by a cycle. */
						/* https://gendev.spritesmind.net/forum/viewtopic.php?p=29929&sid=7c86823ea17db0dca9238bb3fe32c93f#p29929 */
					}

					break;

				case 0xA10000 / 0x1000:
					/* I/O AREA */
					/* TODO: The missing ports. */
					/* TODO: Detect when this is accessed without obtaining the Z80 bus and log a warning. */
					/* TODO: According to 'gen-hw.txt', these can be accessed by their high bytes too. */
					switch (address)
					{
						case 0xA10000:
							if (do_low_byte)
								value |= ((clownmdemu->configuration.region == CLOWNMDEMU_REGION_OVERSEAS) << 7) | ((clownmdemu->configuration.tv_standard == CLOWNMDEMU_TV_STANDARD_PAL) << 6) | (!MegaCDEnabled(clownmdemu) << 5);

							break;

						case 0xA10002:
						case 0xA10004:
						case 0xA10006:
							/* TODO: 'genhw.txt' mentions that even addresses should have valid data too? */
							if (do_low_byte)
								value = SyncIOPortAndRead(callback_user_data, target_cycle, (address - 0xA10002) / 2);

							break;

						case 0xA10008:
						case 0xA1000A:
						case 0xA1000C:
							if (do_low_byte)
							{
								const cc_u16f joypad_index = (address - 0xA10008) / 2;

								value = IOPort_ReadControl(&clownmdemu->state.io_ports[joypad_index]);
							}

							break;

						default:
							LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid IO register address 0x%" CC_PRIXFAST32, address);
							break;
					}

					break;

				case 0xA11000 / 0x1000:
					if (address == 0xA11000)
					{
						/* MEMORY MODE */
						/* TODO */
						/* https://gendev.spritesmind.net/forum/viewtopic.php?p=28843&sid=65d8f210be331ff257a43b4e3dddb7c3#p28843 */
						/* According to this, this flag is only functional on earlier models, and effectively halves the 68k's speed when running from cartridge. */
					}
					else if (address == 0xA11100)
					{
						/* Z80 BUSREQ */
						/* On real hardware, bus requests do not complete if a reset is being held. */
						/* http://gendev.spritesmind.net/forum/viewtopic.php?f=2&t=2195 */
						const cc_bool z80_bus_obtained = clownmdemu->state.z80.bus_requested && !clownmdemu->state.z80.reset_held;

						if (clownmdemu->state.z80.reset_held)
							LOG_MAIN_CPU_BUS_ERROR_0("Z80 bus request will never end as long as the reset is asserted");

						/* TODO: According to Charles MacDonald's gen-hw.txt, the upper byte is actually the upper byte
							of the next instruction and the lower byte is just 0 (and the flag bit, of course). */
						value = 0xFF ^ z80_bus_obtained;
						value = value << 8 | value;
					}
					else if (address == 0xA11200)
					{
						/* Z80 RESET */
						/* TODO: According to Charles MacDonald's gen-hw.txt, the upper byte is actually the upper byte
							of the next instruction and the lower byte is just 0 (and the flag bit, of course). */
						value = 0xFF ^ clownmdemu->state.z80.reset_held;
						value = value << 8 | value;
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid IO register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				case 0xA12000 / 0x1000:
					/* Mega CD registers. */
					if (!MegaCDEnabled(clownmdemu))
						break;

					if (address == 0xA12000)
					{
						/* RESET, HALT */
						value = ((cc_u16f)clownmdemu->state.mega_cd.irq.enabled[1] << 15) |
							((cc_u16f)clownmdemu->state.mega_cd.m68k.bus_requested << 1) |
							((cc_u16f)!clownmdemu->state.mega_cd.m68k.reset_held << 0);
					}
					else if (address == 0xA12002)
					{
						/* Memory mode / Write protect */
						value = ((cc_u16f)clownmdemu->state.mega_cd.prg_ram.write_protect << 8) | ((cc_u16f)clownmdemu->state.mega_cd.prg_ram.bank << 6) | ((cc_u16f)clownmdemu->state.mega_cd.word_ram.in_1m_mode << 2) | ((cc_u16f)clownmdemu->state.mega_cd.word_ram.dmna << 1) | ((cc_u16f)clownmdemu->state.mega_cd.word_ram.ret << 0);
					}
					else if (address == 0xA12004)
					{
						/* CDC mode */
						value = CDC_Mode(&clownmdemu->mega_cd.cdc, cc_false);
					}
					else if (address == 0xA12006)
					{
						/* H-INT vector */
						value = clownmdemu->state.mega_cd.hblank_address;
					}
					else if (address == 0xA12008)
					{
						/* CDC host data */
						value = CDC_HostData(&clownmdemu->mega_cd.cdc, cc_false);
					}
					else if (address == 0xA1200C)
					{
						/* Stop watch */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from stop watch register");
					}
					else if (address == 0xA1200E)
					{
						/* Communication flag */
						SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
						value = clownmdemu->state.mega_cd.communication.flag;
					}
					else if (address >= 0xA12010 && address < 0xA12020)
					{
						/* Communication command */
						SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
						value = clownmdemu->state.mega_cd.communication.command[(address - 0xA12010) / 2];
					}
					else if (address >= 0xA12020 && address < 0xA12030)
					{
						/* Communication status */
						SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
						value = clownmdemu->state.mega_cd.communication.status[(address - 0xA12020) / 2];
					}
					else if (address == 0xA12030)
					{
						/* Timer W/INT3 */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from Timer W/INT3 register");
					}
					else if (address == 0xA12032)
					{
						/* Interrupt mask control */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from interrupt mask control register");
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid Mega CD register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				case 0xA13000 / 0x1000:
					/* Cartridge registers. */
					if (address == 0xA130F0)
					{
						/* External RAM control */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from external RAM control register");
					}
					else if (address >= 0xA130F2 && address <= 0xA13100)
					{
						/* Cartridge bankswitching */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from cartridge bankswitch register");
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid cartridge register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				default:
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid IO address 0x%" CC_PRIXFAST32, address);
					break;
			}

			break;

		case 0xC00000 / 0x200000:
			/* VDP. */
			/* TODO: According to Charles MacDonald's gen-hw.txt, the VDP stuff is mirrored in the following pattern:
			MSB                       LSB
			110n n000 nnnn nnnn 000m mmmm

			'1' - This bit must be 1.
			'0' - This bit must be 0.
			'n' - This bit can have any value.
			'm' - VDP addresses (00-1Fh) */
			switch (address_word - 0xC00000 / 2)
			{
				case 0 / 2:
				case 2 / 2:
					/* VDP data port */
					/* TODO: Reading from the data port causes real Mega Drives to crash (if the VDP isn't in read mode). */
					value = VDP_ReadData(&clownmdemu->vdp);
					break;

				case 4 / 2:
				case 6 / 2:
					/* VDP control port */
					value = VDP_ReadControl(&clownmdemu->vdp);

					/* Temporary stupid hack: shove the PAL bit in here. */
					/* TODO: This should be moved to the VDP core once it becomes sensitive to PAL mode differences. */
					value |= (clownmdemu->configuration.tv_standard == CLOWNMDEMU_TV_STANDARD_PAL);

					/* Temporary stupid hack: approximate the H-blank bit timing. */
					/* TODO: This should be moved to the VDP core once it becomes slot-based. */
					value |= GetHBlankBit(clownmdemu, target_cycle) << 2;

					break;

				case 0x8 / 2:
				case 0xA / 2:
				case 0xC / 2:
				case 0xE / 2:
				{
					/* H/V COUNTER */
					const cc_u8f h_counter = GetHCounterValue(clownmdemu, target_cycle) >> 1;
					const cc_u8f v_counter_raw = clownmdemu->state.current_scanline;

					/* TODO: Apparently, in interlace mode 1, the lowest bit of the V-counter is set to the hidden ninth bit. */
					const cc_u8f v_counter = clownmdemu->vdp.state.double_resolution_enabled
						? ((v_counter_raw & 0x7F) << 1) | ((v_counter_raw & 0x80) >> 7)
						: (v_counter_raw & 0xFF);

					value = v_counter << 8 | h_counter;
					break;
				}

				case 0x10 / 2:
				case 0x12 / 2:
				case 0x14 / 2:
				case 0x16 / 2:
					/* PSG */
					/* TODO: What's supposed to happen here, if you read from the PSG? */
					/* TODO: It freezes the 68k, that's what:
						https://forums.sonicretro.org/index.php?posts/1066059/ */
					LOG_MAIN_CPU_BUS_ERROR_0("Attempted to read from PSG; this will freeze a real Mega Drive");
					break;

				default:
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to read invalid 68k address 0x%" CC_PRIXFAST32, address);
					break;
			}

			break;

		case 0xE00000 / 0x200000:
			/* WORK-RAM. */
			value = clownmdemu->state.m68k.ram[address_word % CC_COUNT_OF(clownmdemu->state.m68k.ram)];
			break;
	}

	return value;
}

cc_u16f M68kReadCallbackWithCycle(const void* const user_data, const cc_u32f address, const cc_bool do_high_byte, const cc_bool do_low_byte, cc_bool* const terminate_early, const CycleMegaDrive target_cycle)
{
	return M68kReadCallbackWithCycleWithDMA(user_data, address, do_high_byte, do_low_byte, terminate_early, target_cycle, cc_false);
}

cc_u16f M68kReadCallback(const void* const user_data, const cc_u32f address, const cc_bool do_high_byte, const cc_bool do_low_byte, const cc_u32f current_cycle, cc_bool* const terminate_early)
{
	CPUCallbackUserData* const callback_user_data = (CPUCallbackUserData*)user_data;

	return M68kReadCallbackWithCycleWithDMA(user_data, address, do_high_byte, do_low_byte, terminate_early, MakeCycleMegaDrive(callback_user_data->sync.m68k.current_cycle + current_cycle * CLOWNMDEMU_M68K_CLOCK_DIVIDER), cc_false);
}

void M68kWriteCallbackWithCycle(const void* const user_data, const cc_u32f address_word, const cc_bool do_high_byte, const cc_bool do_low_byte, cc_bool* const terminate_early, const cc_u16f value, const CycleMegaDrive target_cycle)
{
	CPUCallbackUserData* const callback_user_data = (CPUCallbackUserData*)user_data;
	ClownMDEmu* const clownmdemu = callback_user_data->clownmdemu;
	const ClownMDEmu_Callbacks* const frontend_callbacks = clownmdemu->callbacks;
	const cc_u32f address = address_word * 2;

	const cc_u16f high_byte = (value >> 8) & 0xFF;
	const cc_u16f low_byte = (value >> 0) & 0xFF;

	cc_u16f mask = 0;

	if (do_high_byte)
		mask |= 0xFF00;
	if (do_low_byte)
		mask |= 0x00FF;

	callback_user_data->m68k_terminate_early = terminate_early;

	switch (address / 0x200000)
	{
		case 0x000000 / 0x200000:
		case 0x200000 / 0x200000:
		case 0x400000 / 0x200000:
		case 0x600000 / 0x200000:
			/* Cartridge, Mega CD. */
			if (((address & 0x400000) != 0) != clownmdemu->state.cartridge_inserted)
			{
				if ((address & 0x200000) != 0 && clownmdemu->state.external_ram.mapped_in)
				{
					/* External RAM */
					const cc_u32f index = address & 0x1FFFFF;

					if (index >= clownmdemu->state.external_ram.size)
					{
						/* TODO: According to Genesis Plus GX, SRAM is actually mirrored past its end. */
						LOG_MAIN_CPU_BUS_ERROR_2("Attempted to write past the end of external RAM (0x%" CC_PRIXFAST32 " when the external RAM ends at 0x%" CC_PRIXLEAST32 ")", index, clownmdemu->state.external_ram.size);
					}
					else
					{
						switch (clownmdemu->state.external_ram.data_size)
						{
							case 0:
							case 2:
								if (do_high_byte)
									clownmdemu->state.external_ram.buffer[index + 0] = high_byte;
								break;
						}

						switch (clownmdemu->state.external_ram.data_size)
						{
							case 0:
							case 3:
								if (do_low_byte)
									clownmdemu->state.external_ram.buffer[index + 1] = low_byte;
								break;
						}
					}
				}
				else
				{
					/* Cartridge */
					const cc_u32f cartridge_address = GetBankedCartridgeAddress(clownmdemu, address);

					/* TODO: This is temporary, just to catch possible bugs in the 68k emulator */
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write to ROM address 0x%" CC_PRIXFAST32, cartridge_address);
				}
			}
			else if (MegaCDEnabled(clownmdemu))
			{
				if ((address & 0x200000) != 0)
				{
					/* WORD-RAM */
					if (clownmdemu->state.mega_cd.word_ram.in_1m_mode)
					{
						if ((address & 0x20000) != 0)
						{
							/* TODO */
							LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to that weird half of 1M WORD-RAM");
						}
						else
						{
							clownmdemu->state.mega_cd.word_ram.buffer[(address_word & 0xFFFF) * 2 + clownmdemu->state.mega_cd.word_ram.ret] &= ~mask;
							clownmdemu->state.mega_cd.word_ram.buffer[(address_word & 0xFFFF) * 2 + clownmdemu->state.mega_cd.word_ram.ret] |= value & mask;
						}
					}
					else
					{
						if (!clownmdemu->state.mega_cd.word_ram.ret)
						{
							LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to WORD-RAM while SUB-CPU has it");
						}
						else
						{
							clownmdemu->state.mega_cd.word_ram.buffer[address_word & 0x1FFFF] &= ~mask;
							clownmdemu->state.mega_cd.word_ram.buffer[address_word & 0x1FFFF] |= value & mask;
						}
					}
				}
				else if ((address & 0x20000) == 0)
				{
					/* Mega CD BIOS */
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write to BIOS (0x%" CC_PRIXFAST32 ")", address);
				}
				else
				{
					/* PRG-RAM */
					const cc_u32f prg_ram_index = 0x10000 * clownmdemu->state.mega_cd.prg_ram.bank + (address_word & 0xFFFF);

					if (!clownmdemu->state.mega_cd.m68k.bus_requested)
					{
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to PRG-RAM while SUB-CPU has it");
					}
					else if (prg_ram_index < (cc_u32f)clownmdemu->state.mega_cd.prg_ram.write_protect * 0x200)
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write to write-protected portion of PRG-RAM (0x%" CC_PRIXFAST32 ")", prg_ram_index);
					}
					else
					{
						clownmdemu->state.mega_cd.prg_ram.buffer[prg_ram_index] &= ~mask;
						clownmdemu->state.mega_cd.prg_ram.buffer[prg_ram_index] |= value & mask;
					}
				}
			}

			break;

		case 0x800000 / 0x200000:
			/* 32X? */
			LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid 68k address 0x%" CC_PRIXFAST32, address);
			break;

		case 0xA00000 / 0x200000:
			/* IO region. */
			switch (address / 0x1000)
			{
				case 0xA00000 / 0x1000:
				case 0xA01000 / 0x1000:
				case 0xA02000 / 0x1000:
				case 0xA03000 / 0x1000:
				case 0xA04000 / 0x1000:
				case 0xA05000 / 0x1000:
				case 0xA06000 / 0x1000:
				case 0xA07000 / 0x1000:
				case 0xA08000 / 0x1000:
				case 0xA09000 / 0x1000:
				case 0xA0A000 / 0x1000:
				case 0xA0B000 / 0x1000:
				case 0xA0C000 / 0x1000:
				case 0xA0D000 / 0x1000:
				case 0xA0E000 / 0x1000:
				case 0xA0F000 / 0x1000:
					/* Z80 RAM and YM2612 */
					if (!clownmdemu->state.z80.bus_requested)
					{
						LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to write Z80 memory/YM2612 ports without Z80 bus");
					}
					else if (clownmdemu->state.z80.reset_held)
					{
						/* TODO: Does this actually bother real hardware? */
						/* TODO: According to Devon, yes it does. */
						LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to write Z80 memory/YM2612 ports while Z80 reset request was active");
					}
					else
					{
						/* This is unnecessary, as the Z80 bus will have to have been requested, causing a sync. */
						/*SyncZ80(clownmdemu, callback_user_data, target_cycle);*/

						if (do_high_byte && do_low_byte)
							LOG_MAIN_CPU_BUS_ERROR_0("68k attempted to perform word-sized write of Z80 memory/YM2612 ports; only the top byte will be written");

						if (do_high_byte)
							Z80WriteCallbackWithCycle(user_data, (address + 0) & 0x7FFF, high_byte, target_cycle);
						else /*if (do_low_byte)*/
							Z80WriteCallbackWithCycle(user_data, (address + 1) & 0x7FFF, low_byte, target_cycle);

						/* TODO: This should delay the 68k by a cycle. */
						/* https://gendev.spritesmind.net/forum/viewtopic.php?p=29929&sid=7c86823ea17db0dca9238bb3fe32c93f#p29929 */
					}

					break;

				case 0xA10000 / 0x1000:
					/* I/O AREA */
					/* TODO */
					switch (address)
					{
						case 0xA10002:
						case 0xA10004:
						case 0xA10006:
							if (do_low_byte)
								SyncIOPortAndWrite(callback_user_data, target_cycle, (address - 0xA10002) / 2, low_byte);

							break;

						case 0xA10008:
						case 0xA1000A:
						case 0xA1000C:
							if (do_low_byte)
							{
								const cc_u16f joypad_index = (address - 0xA10008) / 2;

								IOPort_WriteControl(&clownmdemu->state.io_ports[joypad_index], low_byte);
							}

							break;

						default:
							LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid IO register address 0x%" CC_PRIXFAST32, address);
							break;
					}

					break;

				case 0xA11000 / 0x1000:
					if (address == 0xA11000)
					{
						/* MEMORY MODE */
						/* TODO: Make setting this to DRAM mode make the cartridge writeable. */
					}
					else if (address == 0xA11100)
					{
						/* Z80 BUSREQ */
						if (do_high_byte)
						{
							const cc_bool bus_request = (high_byte & 1) != 0;

							if (clownmdemu->state.z80.bus_requested != bus_request)
								SyncZ80(clownmdemu, callback_user_data, target_cycle);

							clownmdemu->state.z80.bus_requested = bus_request;
						}
					}
					else if (address == 0xA11200)
					{
						/* Z80 RESET */
						if (do_high_byte)
						{
							const cc_bool new_reset_held = (high_byte & 1) == 0;

							if (clownmdemu->state.z80.reset_held && !new_reset_held)
							{
								SyncZ80(clownmdemu, callback_user_data, target_cycle);
								ClownZ80_Reset(&clownmdemu->z80);
								/* TODO: Add a proper reset function? */
								FM_Initialise(&clownmdemu->fm);
							}

							clownmdemu->state.z80.reset_held = new_reset_held;
						}
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid IO register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				case 0xA12000 / 0x1000:
					/* Mega CD registers. */
					if (!MegaCDEnabled(clownmdemu))
						break;

					if (address == 0xA12000)
					{
						/* RESET, HALT */
						Clown68000_ReadWriteCallbacks m68k_read_write_callbacks;

						const cc_bool interrupt = (high_byte & (1 << 0)) != 0;
						const cc_bool bus_request = (low_byte & (1 << 1)) != 0;
						const cc_bool reset = (low_byte & (1 << 0)) == 0;

						m68k_read_write_callbacks.read_callback = MCDM68kReadCallback;
						m68k_read_write_callbacks.write_callback = MCDM68kWriteCallback;
						m68k_read_write_callbacks.user_data = callback_user_data;

						if (clownmdemu->state.mega_cd.m68k.bus_requested != bus_request)
							SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));

						if (clownmdemu->state.mega_cd.m68k.reset_held && !reset)
						{
							SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
							Clown68000_Reset(&clownmdemu->mega_cd.m68k, &m68k_read_write_callbacks);
						}

						if (interrupt && clownmdemu->state.mega_cd.irq.enabled[1])
						{
							SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
							Clown68000_Interrupt(&clownmdemu->mega_cd.m68k, 2);
						}

						clownmdemu->state.mega_cd.m68k.bus_requested = bus_request;
						clownmdemu->state.mega_cd.m68k.reset_held = reset;
					}
					else if (address == 0xA12002)
					{
						/* Memory mode / Write protect */
						/* TODO: Exact behaviour of DMNA and RET when toggling between 1M and 2M modes. */
						/* https://gendev.spritesmind.net/forum/viewtopic.php?p=15269#p15269 */
						if (do_high_byte)
							clownmdemu->state.mega_cd.prg_ram.write_protect = high_byte;

						if (do_low_byte)
						{
							const cc_bool dmna = (low_byte & (1 << 1)) != 0;

							/* Contrary to the official documentation, the DMNA bit needs to be set to 0 to request a 1M bank swap. */
							/* https://gendev.spritesmind.net/forum/viewtopic.php?p=16388#p16388 */
							if (dmna != clownmdemu->state.mega_cd.word_ram.in_1m_mode)
							{
								SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));

								clownmdemu->state.mega_cd.word_ram.dmna = cc_true;

								if (!clownmdemu->state.mega_cd.word_ram.in_1m_mode)
									clownmdemu->state.mega_cd.word_ram.ret = cc_false;
							}

							clownmdemu->state.mega_cd.prg_ram.bank = (low_byte >> 6) & 3;
						}
					}
					else if (address == 0xA12004)
					{
						/* CDC mode */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to CDC mode register");
					}
					else if (address == 0xA12006)
					{
						/* H-INT vector */
						clownmdemu->state.mega_cd.hblank_address &= ~mask;
						clownmdemu->state.mega_cd.hblank_address |= value & mask;
					}
					else if (address == 0xA12008)
					{
						/* CDC host data */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to CDC host data register");
					}
					else if (address == 0xA1200C)
					{
						/* Stop watch */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to stop watch register");
					}
					else if (address == 0xA1200E)
					{
						/* Communication flag */
						if (do_high_byte)
						{
							SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
							clownmdemu->state.mega_cd.communication.flag = (clownmdemu->state.mega_cd.communication.flag & 0x00FF) | (value & 0xFF00);
						}

						if (do_low_byte)
							LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to SUB-CPU's communication flag");
					}
					else if (address >= 0xA12010 && address < 0xA12020)
					{
						/* Communication command */
						SyncMCDM68k(clownmdemu, callback_user_data, CycleMegaDriveToMegaCD(clownmdemu, target_cycle));
						clownmdemu->state.mega_cd.communication.command[(address - 0xA12010) / 2] &= ~mask;
						clownmdemu->state.mega_cd.communication.command[(address - 0xA12010) / 2] |= value & mask;
					}
					else if (address >= 0xA12020 && address < 0xA12030)
					{
						/* Communication status */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to SUB-CPU's communication status");
					}
					else if (address == 0xA12030)
					{
						/* Timer W/INT3 */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to Timer W/INT3 register");
					}
					else if (address == 0xA12032)
					{
						/* Interrupt mask control */
						LOG_MAIN_CPU_BUS_ERROR_0("Attempted to write to interrupt mask control register");
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid Mega CD register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				case 0xA13000 / 0x1000:
					/* Cartridge registers. */
					if (address == 0xA130F0)
					{
						/* External RAM control */
						/* TODO: Apparently this is actually two bit-packed flags! */
						/* https://forums.sonicretro.org/index.php?posts/622087/ */
						/* https://web.archive.org/web/20130731104452/http://emudocs.org/Genesis/ssf2.txt */
						/* TODO: Actually, the second bit only exists on devcarts? */
						/* https://forums.sonicretro.org/index.php?posts/1096788/ */
						if (do_low_byte && clownmdemu->state.external_ram.size != 0)
							clownmdemu->state.external_ram.mapped_in = low_byte != 0;
					}
					else if (address >= 0xA130F2 && address <= 0xA13100)
					{
						/* Cartridge bankswitching */
						if (do_low_byte)
							clownmdemu->state.cartridge_bankswitch[(address - 0xA130F0) / 2] = low_byte; /* We deliberately make index 0 inaccessible, as bank 0 is always set to 0 on real hardware. */
					}
					else
					{
						LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid cartridge register address 0x%" CC_PRIXFAST32, address);
					}

					break;

				default:
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid IO register address 0x%" CC_PRIXFAST32, address);
					break;
			}

			break;

		case 0xC00000 / 0x200000:
			/* VDP. */
			switch (address_word - 0xC00000 / 2)
			{
				case 0 / 2:
				case 2 / 2:
					/* VDP data port */
					VDP_WriteData(&clownmdemu->vdp, value, frontend_callbacks->colour_updated, frontend_callbacks->user_data);
					break;

				case 4 / 2:
				case 6 / 2:
					/* VDP control port */
					VDP_WriteControl(&clownmdemu->vdp, value, frontend_callbacks->colour_updated, frontend_callbacks->user_data, VDPDMATransferBeginCallback, VDPReadCallback, callback_user_data, VDPKDebugCallback, NULL, target_cycle.cycle);

					/* TODO: This should be done more faithfully once the CPU interpreters are bus-event-oriented. */
					RaiseInterruptIfNeeded(clownmdemu);
					break;

				case 8 / 2:
					/* H/V COUNTER */
					/* TODO */
					break;

				case 0x10 / 2:
				case 0x12 / 2:
				case 0x14 / 2:
				case 0x16 / 2:
					/* PSG */
					if (do_low_byte)
					{
						SyncPSG(callback_user_data, target_cycle);

						/* Alter the PSG's state */
						PSG_DoCommand(&clownmdemu->psg, low_byte);

						/* Notify the frontend of the write. */
						if (frontend_callbacks->sound_chip_written != NULL)
							frontend_callbacks->sound_chip_written((void*)frontend_callbacks->user_data, CLOWNMDEMU_SOUND_CHIP_PSG, 0, low_byte, target_cycle.cycle);
					}
					break;

				case 0x18 / 2:
					VDP_WriteDebugControl(&clownmdemu->vdp, value);
					break;

				case 0x1C / 2:
					VDP_WriteDebugData(&clownmdemu->vdp, value);
					break;

				default:
					LOG_MAIN_CPU_BUS_ERROR_1("Attempted to write invalid 68k address 0x%" CC_PRIXFAST32, address);
					break;
			}

			break;

		case 0xE00000 / 0x200000:
			/* WORK-RAM. */
			clownmdemu->state.m68k.ram[address_word % CC_COUNT_OF(clownmdemu->state.m68k.ram)] &= ~mask;
			clownmdemu->state.m68k.ram[address_word % CC_COUNT_OF(clownmdemu->state.m68k.ram)] |= value & mask;
			break;
	}
}

void M68kWriteCallback(const void* const user_data, const cc_u32f address, const cc_bool do_high_byte, const cc_bool do_low_byte, const cc_u32f current_cycle, cc_bool* const terminate_early, const cc_u16f value)
{
	CPUCallbackUserData* const callback_user_data = (CPUCallbackUserData*)user_data;

	M68kWriteCallbackWithCycle(user_data, address, do_high_byte, do_low_byte, terminate_early, value, MakeCycleMegaDrive(callback_user_data->sync.m68k.current_cycle + current_cycle * CLOWNMDEMU_M68K_CLOCK_DIVIDER));
}
