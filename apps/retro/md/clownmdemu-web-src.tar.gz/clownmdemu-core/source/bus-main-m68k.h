#ifndef BUS_MAIN_M68K_H
#define BUS_MAIN_M68K_H

#include "bus-common.h"

void M68kInterruptAcknowledgeCallback(const void *user_data);
void SyncM68k(ClownMDEmu *clownmdemu, CPUCallbackUserData *other_state, CycleMegaDrive target_cycle);
cc_u8f SyncIOPortAndRead(CPUCallbackUserData *callback_user_data, CycleMegaDrive target_cycle, cc_u16f joypad_index);
void SyncIOPortAndWrite(CPUCallbackUserData *callback_user_data, CycleMegaDrive target_cycle, cc_u16f joypad_index, cc_u8f value);
#define SyncIOPort(callback_user_data, target_cycle, joypad_index) (void)SyncIOPortAndRead(callback_user_data, target_cycle, joypad_index)
cc_u16f M68kReadCallbackWithCycleWithDMA(const void *user_data, cc_u32f address, cc_bool do_high_byte, cc_bool do_low_byte, cc_bool* const terminate_early, CycleMegaDrive target_cycle, cc_bool is_vdp_dma);
cc_u16f M68kReadCallbackWithCycle(const void *user_data, cc_u32f address, cc_bool do_high_byte, cc_bool do_low_byte, cc_bool* const terminate_early, CycleMegaDrive target_cycle);
cc_u16f M68kReadCallback(const void *user_data, cc_u32f address, cc_bool do_high_byte, cc_bool do_low_byte, cc_u32f current_cycle, cc_bool* const terminate_early);
void M68kWriteCallbackWithCycle(const void *user_data, cc_u32f address, cc_bool do_high_byte, cc_bool do_low_byte, cc_bool* const terminate_early, cc_u16f value, CycleMegaDrive target_cycle);
void M68kWriteCallback(const void *user_data, cc_u32f address, cc_bool do_high_byte, cc_bool do_low_byte, cc_u32f current_cycle, cc_bool* const terminate_early, cc_u16f value);

#endif /* BUS_MAIN_M68K_H */
